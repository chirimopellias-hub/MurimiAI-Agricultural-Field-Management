
from pydantic import BaseModel
from typing import Optional

class SignUpData(BaseModel):
    name: str
    email: str
    phone: str
    password: str
    language: str = "en"
    farm: dict

class SignInData(BaseModel):
    identifier: str
    password: str

class UpdateUserData(BaseModel):
    name: str
    email: str
    phone: str = ""
    language: str = "en"

class ChangePasswordData(BaseModel):
    old_password: str
    new_password: str
    confirm_password: str
