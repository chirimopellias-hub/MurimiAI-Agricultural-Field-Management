from pydantic import BaseModel, Field
from typing import List, Optional

class Location(BaseModel):
    latitude: float = Field(..., alias='lat')
    longitude: float = Field(..., alias='lng')
    accuracy: float
    timestamp: int

    class Config:
        allow_population_by_field_name = True

class FieldSoilData(BaseModel):
    texture: Optional[str] = None
    ph_level: Optional[float] = None
    nitrogen: Optional[float] = None
    phosphorus: Optional[float] = None
    potassium: Optional[float] = None
    organic_matter: Optional[float] = None
    moisture: Optional[float] = None
    cec: Optional[float] = None

class FieldData(BaseModel):
    field_id: Optional[str] = None
    farm_id: str
    name: str
    crop_name: str
    crop_variety: str
    sowing_date: str
    irrigation_type: str
    growth_stage: Optional[str] = None
    field_coordinates: List[List[float]]
    hectares: float
    location: Optional[Location] = None
    soil_data: Optional[FieldSoilData] = None