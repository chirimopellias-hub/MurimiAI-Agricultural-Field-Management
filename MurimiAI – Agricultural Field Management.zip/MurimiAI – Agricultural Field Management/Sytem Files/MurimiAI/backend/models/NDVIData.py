# models/NDVIData.py
from pydantic import BaseModel
from typing import Optional

class NDVIData(BaseModel):
    field_id: str
    date: str
    ndvi: float
    evi: float
    ndwi: float