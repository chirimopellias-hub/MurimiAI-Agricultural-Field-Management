from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime

class ChatMessage(BaseModel):
    id: str
    text: str
    sender: str  # "user" or "bot"
    timestamp: datetime
    conversation_id: Optional[str] = None

class Conversation(BaseModel):
    id: str
    title: str
    last_message: str
    timestamp: datetime
    message_count: int
    messages: List[ChatMessage] = []

class ChatRequest(BaseModel):
    message: str
    conversation_id: Optional[str] = None
    history: Optional[List[dict]] = None

class ChatResponse(BaseModel):
    id: str
    text: str
    sender: str = "bot"
    timestamp: datetime
    conversation_id: str
    is_agriculture_related: bool = True

class SaveConversationRequest(BaseModel):
    conversation_id: str
    title: str
    messages: List[dict]

class ConversationResponse(BaseModel):
    id: str
    title: str
    last_message: str
    timestamp: datetime
    message_count: int