import uuid
from datetime import datetime
from typing import Dict, List, Optional

from database import supabase


class SupabaseChatService:
    def __init__(self):
        self.client = supabase

    async def list_conversations(self, user_id: str) -> List[Dict]:
        try:
            response = self.client.table("conversations").select("*").eq("user_id", user_id).order("updated_at", desc=True).execute()
            return response.data or []
        except Exception as exc:
            print(f"Error listing conversations: {exc}")
            return []

    async def get_conversation(self, conversation_id: str, user_id: str) -> Optional[Dict]:
        try:
            response = self.client.table("conversations").select("*").eq("id", conversation_id).eq("user_id", user_id).execute()
            return (response.data or [None])[0]
        except Exception as exc:
            print(f"Error getting conversation: {exc}")
            return None

    async def get_messages(self, conversation_id: str, user_id: str) -> List[Dict]:
        try:
            conv = await self.get_conversation(conversation_id, user_id)
            if not conv:
                return []

            response = self.client.table("messages").select("*").eq("conversation_id", conversation_id).order("sequence_number", desc=False).order("created_at", desc=False).execute()
            return response.data or []
        except Exception as exc:
            print(f"Error getting messages: {exc}")
            return []

    async def create_conversation(self, user_id: str, title: str) -> Dict:
        try:
            conversation_id = str(uuid.uuid4())
            now = datetime.utcnow().isoformat()
            response = self.client.table("conversations").insert({
                "id": conversation_id,
                "user_id": user_id,
                "title": title,
                "last_message": "",
                "message_count": 0,
                "created_at": now,
                "updated_at": now,
            }).execute()
            return (response.data or [{}])[0]
        except Exception as exc:
            print(f"Error creating conversation: {exc}")
            return {}

    async def save_message(self, conversation_id: str, user_id: str, text: str, sender: str) -> Dict:
        try:
            conv = await self.get_conversation(conversation_id, user_id)
            if not conv:
                return {}

            max_seq = self.client.table("messages").select("sequence_number").eq("conversation_id", conversation_id).order("sequence_number", desc=True).limit(1).execute()
            next_seq = 1
            if max_seq.data:
                next_seq = int(max_seq.data[0].get("sequence_number", 0)) + 1

            now = datetime.utcnow().isoformat()
            response = self.client.table("messages").insert({
                "id": str(uuid.uuid4()),
                "conversation_id": conversation_id,
                "content": text,
                "sender": sender,
                "sequence_number": next_seq,
                "created_at": now,
            }).execute()

            message_count = int(conv.get("message_count", 0)) + 1
            last_message = text[:100]
            self.client.table("conversations").update({
                "message_count": message_count,
                "last_message": last_message,
                "updated_at": now,
            }).eq("id", conversation_id).execute()

            return (response.data or [{}])[0]
        except Exception as exc:
            print(f"Error saving message: {exc}")
            return {}

    async def save_conversation(self, user_id: str, conversation_id: str, title: str, messages: List[Dict]) -> Dict:
        try:
            conv = await self.get_conversation(conversation_id, user_id)
            if not conv:
                conv = await self.create_conversation(user_id, title)
                conversation_id = conv.get("id")

            now = datetime.utcnow().isoformat()
            if not conv:
                return {}

            existing_messages = await self.get_messages(conversation_id, user_id)
            if existing_messages:
                self.client.table("messages").delete().eq("conversation_id", conversation_id).execute()

            prepared = []
            for index, msg in enumerate(messages, start=1):
                prepared.append({
                    "id": str(uuid.uuid4()),
                    "conversation_id": conversation_id,
                    "content": msg.get("text", ""),
                    "sender": msg.get("sender", "user"),
                    "sequence_number": index,
                    "created_at": msg.get("timestamp") or now,
                })

            if prepared:
                self.client.table("messages").insert(prepared).execute()

            self.client.table("conversations").update({
                "title": title,
                "message_count": len(prepared),
                "last_message": (prepared[-1].get("content") or "")[:100],
                "updated_at": now,
            }).eq("id", conversation_id).execute()

            return {"id": conversation_id, "title": title, "message_count": len(prepared)}
        except Exception as exc:
            print(f"Error saving conversation: {exc}")
            return {}

    async def delete_conversation(self, conversation_id: str, user_id: str) -> bool:
        try:
            self.client.table("messages").delete().eq("conversation_id", conversation_id).execute()
            response = self.client.table("conversations").delete().eq("id", conversation_id).eq("user_id", user_id).execute()
            return bool(response.data)
        except Exception as exc:
            print(f"Error deleting conversation: {exc}")
            return False


supabase_chat_service = SupabaseChatService()
