# routes.py
import sys
from pathlib import Path
from fastapi import APIRouter, HTTPException, Request

# Add backend directory to path
backend_dir = Path(__file__).parent.parent
if str(backend_dir) not in sys.path:
    sys.path.insert(0, str(backend_dir))

from pages.Sign.sign import SignInData, SignUpData, signin, signup
from pages.Account.account import ChangePasswordData, UpdateUserData, change_user_password, get_current_user, update_user_profile
from pages.Disease.DiseaseDetection import router as disease_router
from models.FieldData import FieldData
from pages.AddField.addfield import add_field
from pages.SmartAdvisory.smartadvisory import router as smart_advisory_router
from pages.SoilAnalysis.FieldSpecificAnalysis import router as soil_analysis_router
from pages.Analytics.analytics import router as analytics_router
from pages.SoilData.soil_data import router as soil_data_router
from pages.MyFarm.farm import router as myfarm_router

router = APIRouter()

router.include_router(disease_router)
router.include_router(smart_advisory_router)
router.include_router(soil_analysis_router)
router.include_router(analytics_router)
router.include_router(soil_data_router)
router.include_router(myfarm_router)

@router.get("/")
def read_root():
    return {"Server Online"}

# Authentication routes
@router.post("/api/auth/signup")
async def signup_route(data: SignUpData):
    return signup(data)

@router.post("/api/auth/signin")
async def signin_route(data: SignInData):
    return signin(data)

@router.get("/api/auth/user")
async def current_user_route(request: Request):
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing authorization token")
    token = auth_header.split(" ", 1)[1]
    return get_current_user(token)

@router.patch("/api/auth/user")
async def update_user_route(request: Request, data: UpdateUserData):
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing authorization token")
    token = auth_header.split(" ", 1)[1]
    return update_user_profile(token, data)

@router.post("/api/auth/user/password")
async def change_password_route(request: Request, data: ChangePasswordData):
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing authorization token")
    token = auth_header.split(" ", 1)[1]
    return change_user_password(token, data)

@router.post("/api/add-field")
async def add_field_route(request: Request, data: FieldData):
    farm_id = data.farm_id.strip() if data.farm_id else ''
    if not farm_id or farm_id == 'Farm ID not set':
        auth_header = request.headers.get('Authorization')
        if auth_header and auth_header.startswith('Bearer '):
            token = auth_header.split(' ', 1)[1]
            current_user = get_current_user(token)
            if current_user.get('farm_id'):
                data.farm_id = current_user['farm_id']
                farm_id = data.farm_id
        if not farm_id or farm_id == 'Farm ID not set':
            raise HTTPException(status_code=400, detail='Missing valid farm_id for field creation')
    return await add_field(data)


