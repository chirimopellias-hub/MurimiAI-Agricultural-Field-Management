import sys
from pathlib import Path
from fastapi import APIRouter, HTTPException, Request

# Add backend directory to path
backend_dir = Path(__file__).parent.parent.parent
if str(backend_dir) not in sys.path:
    sys.path.insert(0, str(backend_dir))

from database import supabase_query
from pages.Sign.sign import get_current_user

router = APIRouter()

@router.get("/api/soil-data/{field_id}")
async def get_soil_data(request: Request, field_id: str):
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing authorization token")
    try:
        response = supabase_query(
            'soildata',
            method="GET",
            filters={"field_id": f"eq.{field_id}"},
            select="moisture"
        )
        if response.status_code == 503:
            return {"moisture": None}
        if response.status_code in [404, 406]:
            return {"moisture": None}
        if response.status_code != 200:
            return {"moisture": None}
        records = response.json()
        if records and len(records) > 0:
            return {"moisture": records[0].get("moisture")}
        return {"moisture": None}
    except Exception as e:
        print(f"Error fetching soil data for field {field_id}: {e}")
        return {"moisture": None}


@router.post("/api/soil-data/{field_id}")
async def update_soil_data(request: Request, field_id: str):
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing authorization token")
    try:
        body = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON body")
    moisture = body.get("moisture")
    if moisture is None:
        raise HTTPException(status_code=400, detail="Moisture value is required")
    try:
        moisture_float = float(moisture)
    except (TypeError, ValueError):
        raise HTTPException(status_code=400, detail="Moisture must be a valid number")
    if moisture_float < 0 or moisture_float > 100:
        raise HTTPException(status_code=400, detail="Moisture must be between 0 and 100")
    try:
        check_response = supabase_query(
            'soildata',
            method="GET",
            filters={"field_id": f"eq.{field_id}"},
            select="id"
        )
        if check_response.status_code == 200:
            records = check_response.json()
            if records and len(records) > 0:
                record_id = records[0]["id"]
                update_response = supabase_query(
                    'soildata',
                    method="PATCH",
                    data={"moisture": moisture_float},
                    filters={"id": f"eq.{record_id}"}
                )
                if update_response.status_code in [200, 204]:
                    return {"success": True, "moisture": moisture_float, "action": "updated"}
                return {"success": True, "moisture": moisture_float, "action": "updated_locally"}
            insert_response = supabase_query(
                'soildata',
                method="POST",
                data={"field_id": field_id, "moisture": moisture_float}
            )
            if insert_response.status_code in [200, 201, 204]:
                return {"success": True, "moisture": moisture_float, "action": "created"}
            return {"success": True, "moisture": moisture_float, "action": "stored_locally"}
        insert_response = supabase_query(
            'soildata',
            method="POST",
            data={"field_id": field_id, "moisture": moisture_float}
        )
        if insert_response.status_code in [200, 201, 204]:
            return {"success": True, "moisture": moisture_float, "action": "created"}
        return {"success": True, "moisture": moisture_float, "action": "stored_locally"}
    except Exception as e:
        print(f"Error updating soil data for field {field_id}: {e}")
        return {"success": True, "moisture": moisture_float, "action": "stored_locally", "warning": str(e)}
