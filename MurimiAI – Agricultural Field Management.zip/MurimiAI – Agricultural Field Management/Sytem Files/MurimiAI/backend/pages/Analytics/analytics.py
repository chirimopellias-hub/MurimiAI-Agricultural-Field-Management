import json
import datetime
import os
import sys
from pathlib import Path
from fastapi import APIRouter, HTTPException, Request
import urllib.parse

try:
    from openai import OpenAI
except ImportError:
    OpenAI = None

# Add backend directory to path
backend_dir = Path(__file__).parent.parent.parent
if str(backend_dir) not in sys.path:
    sys.path.insert(0, str(backend_dir))

from pages.Sign.sign import get_current_user
from database import supabase_query
import earth_engine_session

router = APIRouter()


def _get_deepseek_recommendation(status, average_ndvi, crop_name, growth_stage):
    api_key = os.environ.get("DEEPSEEK_API_KEY")
    if not api_key or OpenAI is None:
        return None

    client = OpenAI(api_key=api_key, base_url="https://api.deepseek.com")
    prompt = (
        f"Provide concise actionable farm advisory text based on the following field summary:\n"
        f"Crop name: {crop_name or 'Unknown'}\n"
        f"Growth stage: {growth_stage or 'Unknown'}\n"
        f"NDVI status: {status}\n"
        f"Average NDVI: {average_ndvi if average_ndvi is not None else 'unknown'}\n"
        "Include irrigation, nutrient management, pest inspection, and monitoring recommendations."
    )

    try:
        response = client.chat.completions.create(
            model="deepseek-v4-pro",
            messages=[
                {"role": "system", "content": "You are a helpful agricultural advisor."},
                {"role": "user", "content": prompt},
            ],
            stream=False,
            reasoning_effort="high",
            extra_body={"thinking": {"type": "enabled"}},
        )
        choice = response.choices[0]
        message = getattr(choice, "message", None) or (choice.get("message") if isinstance(choice, dict) else None)
        content = None
        if isinstance(message, dict):
            content = message.get("content")
        else:
            content = getattr(message, "content", None)
        return content.strip() if content else None
    except Exception:
        return None


def _build_field_geometry(field_coordinates):
    if not field_coordinates or len(field_coordinates) < 3:
        raise ValueError("Invalid field coordinates")

    ee = earth_engine_session.get()
    if not ee:
        raise RuntimeError("Earth Engine not initialized. Start the application to initialize.")

    ring = []
    for point in field_coordinates:
        if isinstance(point, dict):
            lat = float(point.get("latitude", point.get("lat")))
            lng = float(point.get("longitude", point.get("lng")))
        elif isinstance(point, (list, tuple)) and len(point) >= 2:
            lat = float(point[0])
            lng = float(point[1])
        else:
            raise ValueError("Unexpected coordinate format for field boundary")
        ring.append([lng, lat])

    if ring[0] != ring[-1]:
        ring.append(ring[0])

    return ee.Geometry.Polygon([ring])


def _parse_sowing_date(sowing_date):
    if not sowing_date:
        return None
    if isinstance(sowing_date, str):
        sowing_date = sowing_date.strip()
        for fmt in ("%Y-%m-%d", "%d-%m-%Y", "%m/%d/%Y", "%Y/%m/%d"):
            try:
                return datetime.datetime.strptime(sowing_date, fmt).date()
            except ValueError:
                continue
    return None


def _build_tile_url(map_id_response):
    if isinstance(map_id_response, dict):
        map_id = map_id_response.get("mapid") or map_id_response.get("mapId")
        token = map_id_response.get("token")
    else:
        map_id = getattr(map_id_response, "mapid", None) or getattr(map_id_response, "mapId", None)
        token = getattr(map_id_response, "token", None)

    if not map_id:
        raise RuntimeError("Unable to build Earth Engine tile URL from map response")

    url = f"https://earthengine.googleapis.com/v1alpha/projects/earthengine-legacy/maps/{map_id}/tiles/{{z}}/{{x}}/{{y}}"
    if token:
        # Ensure token is safely included in the query string
        token_q = urllib.parse.quote_plus(str(token))
        return f"{url}?token={token_q}"
    return url


def _get_ndvi_analysis(field_coordinates, sowing_date=None, crop_name=None, growth_stage=None):
    ee = earth_engine_session.get()
    if not ee:
        return {
            "average": None,
            "status": "Unavailable",
            "color": "#9ca3af",
            "ndvi_tile_url": None,
            "sentinel_tile_url": None,
            "history": [],
            "alerts": ["Earth Engine not initialized. NDVI analysis unavailable."],
            "recommendation": None,
        }
    
    geometry = _build_field_geometry(field_coordinates)

    end_date = datetime.date.today()
    start_date = end_date - datetime.timedelta(days=365)
    parsed_sowing = _parse_sowing_date(sowing_date)
    if parsed_sowing and parsed_sowing < end_date:
        start_date = parsed_sowing

    collection = (
        ee.ImageCollection("COPERNICUS/S2_SR")
        .filterBounds(geometry)
        .filterDate(start_date.isoformat(), end_date.isoformat())
        .filter(ee.Filter.lt("CLOUDY_PIXEL_PERCENTAGE", 30))
    )

    image_count = int(collection.size().getInfo() or 0)
    if image_count == 0:
        return {
            "average": None,
            "status": "No imagery",
            "color": "#9ca3af",
            "ndvi_tile_url": None,
            "sentinel_tile_url": None,
            "history": [],
            "alerts": ["No Sentinel-2 imagery available for this field boundary."],
        }

    image = collection.sort("CLOUDY_PIXEL_PERCENTAGE").first()

    ndvi_image = image.normalizedDifference(["B8", "B4"]).rename("NDVI").clip(geometry)
    rgb_image = image.select(["B4", "B3", "B2"]).clip(geometry)

    mean_ndvi = ndvi_image.reduceRegion(
        reducer=ee.Reducer.mean(),
        geometry=geometry,
        scale=10,
        maxPixels=1e12,
    ).get("NDVI")
    average_ndvi_value = mean_ndvi.getInfo()
    average_ndvi = float(average_ndvi_value) if average_ndvi_value is not None else None

    history_collection = collection.sort("system:time_start", False).limit(8)

    def image_to_feature(image):
        mean_val = image.normalizedDifference(["B8", "B4"]).rename("NDVI").reduceRegion(
            reducer=ee.Reducer.mean(),
            geometry=geometry,
            scale=10,
            maxPixels=1e12,
        ).get("NDVI")

        return ee.Feature(
            None,
            {
                "date": ee.Date(image.get("system:time_start")).format("YYYY-MM-dd"),
                "ndvi": mean_val,
            },
        )

    history_features = history_collection.map(image_to_feature)
    history_info = history_features.getInfo().get("features", [])
    ndvi_history = []
    for feature in history_info:
        props = feature.get("properties", {})
        ndvi_value = props.get("ndvi")
        ndvi_history.append({
            "date": props.get("date") or "unknown",
            "ndvi": float(ndvi_value) if ndvi_value is not None else 0.0,
        })

    ndvi_history.sort(key=lambda item: item["date"])

    ndvi_tile_url = _build_tile_url(
        ndvi_image.getMapId({
            "min": 0,
            "max": 1,
            "palette": ["#d73027", "#fc8d59", "#fee08b", "#d9ef8b", "#91cf60", "#1a9850"],
        })
    )
    sentinel_tile_url = _build_tile_url(rgb_image.getMapId({"min": 0, "max": 3000}))

    if average_ndvi is None:
        health_status = "Unknown"
        health_color = "#9ca3af"
        alerts = ["Unable to calculate NDVI from available imagery."]
    elif average_ndvi >= 0.7:
        health_status = "Excellent"
        health_color = "#10b981"
        alerts = ["Vegetation health is excellent. Continue current management and monitor regularly."]
    elif average_ndvi >= 0.5:
        health_status = "Good"
        health_color = "#f59e0b"
        alerts = ["Crop health is good. Consider minor irrigation or nutrient adjustments."]
    elif average_ndvi >= 0.3:
        health_status = "Moderate"
        health_color = "#ef4444"
        alerts = ["Vegetation health is below optimal. Inspect the field for stress factors."]
    else:
        health_status = "Poor"
        health_color = "#b91c1c"
        alerts = ["Critical vegetation stress detected. Investigate pests, disease, or irrigation issues immediately."]

    recommendation_text = _get_deepseek_recommendation(
        status=health_status,
        average_ndvi=average_ndvi,
        crop_name=crop_name,
        growth_stage=growth_stage,
    )
    if not recommendation_text:
        if average_ndvi is None:
            recommendation_text = (
                "No recommendation available because the NDVI could not be calculated from imagery."
            )
        else:
            recommendation_text = (
                f"{health_status} vegetation detected for "
                f"{crop_name or 'this field'} with an average NDVI of {average_ndvi:.2f}. "
                "Review irrigation, nutrient management, pest scouting, and monitoring plans."
            )

    return {
        "average": average_ndvi,
        "status": health_status,
        "color": health_color,
        "ndvi_tile_url": ndvi_tile_url,
        "sentinel_tile_url": sentinel_tile_url,
        "history": ndvi_history,
        "alerts": alerts,
        "recommendation": recommendation_text,
    }


@router.get("/api/fields")
async def get_fields_route(request: Request):
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing authorization token")
    token = auth_header.split(" ", 1)[1]
    current_user = get_current_user(token)
    if not current_user or not current_user.get('farm_id'):
        raise HTTPException(status_code=404, detail="No farm found")
    farm_id = current_user['farm_id']

    response = supabase_query(
        'Field',
        filters={"farm_id": f"eq.{farm_id}"},
        select="field_id,name,location,crop_name,growth_stage,hectares,field_coordinates"
    )
    if response.status_code == 503:
        raise HTTPException(status_code=503, detail="Supabase connection failed")
    if response.status_code != 200:
        raise HTTPException(status_code=500, detail="Failed to fetch fields")

    records = response.json() or []
    fields = []
    for r in records:
        loc = r.get('location') or {}
        lat = float(loc.get('latitude')) if isinstance(loc, dict) and loc.get('latitude') is not None else None
        lng = float(loc.get('longitude')) if isinstance(loc, dict) and loc.get('longitude') is not None else None
        fields.append({
            "id": r['field_id'],
            "name": r['name'],
            "latitude": lat,
            "longitude": lng,
            "crop_name": r.get('crop_name'),
            "growth_stage": r.get('growth_stage'),
            "hectares": r.get('hectares'),
            "field_coordinates": r.get('field_coordinates')
        })
    return fields


@router.get("/api/field-detail/{field_id}")
async def get_field_detail(request: Request, field_id: str):
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing authorization token")
    token = auth_header.split(" ", 1)[1]
    current_user = get_current_user(token)
    if not current_user or not current_user.get('farm_id'):
        raise HTTPException(status_code=403, detail="No farm associated with user")

    field_resp = supabase_query(
        'Field',
        filters={
            "field_id": f"eq.{field_id}",
            "farm_id": f"eq.{current_user['farm_id']}"
        },
        select="field_id,name,crop_name,crop_variety,hectares,sowing_date,growth_stage,field_coordinates,location"
    )
    if field_resp.status_code == 503:
        raise HTTPException(status_code=503, detail="Database connection failed")
    if field_resp.status_code != 200:
        raise HTTPException(status_code=500, detail="Failed to fetch field data")

    field_records = field_resp.json()
    if not field_records:
        raise HTTPException(status_code=404, detail="Field not found")

    field_data = field_records[0]

    soil_resp = supabase_query(
        'soildata',
        filters={"field_id": f"eq.{field_id}"},
        select="nitrogen,phosphorus,potassium,ph_level,organic_matter"
    )
    soil_data = None
    if soil_resp.status_code == 200:
        soil_records = soil_resp.json()
        if soil_records:
            soil_data = soil_records[0]

    ndvi_data = None
    try:
        ndvi_data = _get_ndvi_analysis(
            field_data.get("field_coordinates") or [],
            field_data.get("sowing_date"),
            field_data.get("crop_name"),
            field_data.get("growth_stage"),
        )
    except Exception as exc:
        ndvi_data = {
            "average": None,
            "status": "Unavailable",
            "color": "#9ca3af",
            "ndvi_tile_url": None,
            "sentinel_tile_url": None,
            "history": [],
            "alerts": [str(exc)],
            "recommendation": None,
        }

    return {
        "field": {
            "field_id": field_data.get("field_id"),
            "name": field_data.get("name"),
            "crop_name": field_data.get("crop_name"),
            "crop_variety": field_data.get("crop_variety"),
            "hectares": field_data.get("hectares"),
            "sowing_date": field_data.get("sowing_date"),
            "growth_stage": field_data.get("growth_stage"),
            "field_coordinates": field_data.get("field_coordinates"),
            "location": field_data.get("location")
        },
        "soil": {
            "nitrogen": soil_data.get("nitrogen") if soil_data else None,
            "phosphorus": soil_data.get("phosphorus") if soil_data else None,
            "potassium": soil_data.get("potassium") if soil_data else None,
            "ph_level": soil_data.get("ph_level") if soil_data else None,
            "organic_matter": soil_data.get("organic_matter") if soil_data else None
        },
        "ndvi": ndvi_data,
    }

