from fastapi import APIRouter, HTTPException, Request
import os
import json
import re
import logging
from pydantic import BaseModel
from openai import OpenAI

from database import supabase_query
from pages.Sign.sign import get_current_user

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/soil-analysis", tags=["soil-analysis"])


@router.get("/fields")
async def get_user_fields(request: Request):
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing authorization token")

    token = auth_header.split(" ", 1)[1]
    current_user = get_current_user(token)
    farm_id = current_user.get("farm_id") if isinstance(current_user, dict) else None

    if not farm_id:
        raise HTTPException(status_code=404, detail="No farm found for the current user")

    response = supabase_query(
        "Field",
        filters={"farm_id": f"eq.{farm_id}"},
        select="field_id,name",
    )

    if response.status_code == 503:
        return []

    if response.status_code != 200:
        raise HTTPException(status_code=500, detail="Failed to fetch farm fields")

    records = response.json() or []
    fields = []

    for record in records:
        fields.append(
            {
                "id": record.get("field_id"),
                "name": record.get("name") or "Unnamed Field"
            }
        )

    return fields


class AnalyzeRequest(BaseModel):
    field_id: str
    ph: float | None = None
    nitrogen: float | None = None
    phosphorus: float | None = None
    potassium: float | None = None
    organicMatter: float | None = None
    texture: str | None = None
    moisture: float | None = None
    cationExchangeCapacity: float | None = None


@router.post("/analyze")
async def analyze_field(request: Request, payload: AnalyzeRequest):
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing authorization token")

    token = auth_header.split(" ", 1)[1]
    current_user = get_current_user(token)
    farm_id = current_user.get("farm_id") if isinstance(current_user, dict) else None
    if not farm_id:
        raise HTTPException(status_code=403, detail="User has no farm context")

    # Optionally fetch the field meta for context
    field_resp = supabase_query(
        "Field",
        filters={"field_id": f"eq.{payload.field_id}", "farm_id": f"eq.{farm_id}"},
        select="field_id,name,location,crop_name,soil_type,growth_stage",
    )
    field_meta = None
    if field_resp.status_code == 200:
        records = field_resp.json() or []
        if records:
            field_meta = records[0]

    system_msg = (
        "You are an expert agronomist. Given field metadata and soil measurements, "
        "produce a JSON object with keys: analysis (array of strings), recommendations (array of strings), "
        "suitableCrops (array of strings), fertilizerRecommendations (object with baseDressing, topDressing, organicOptions), "
        "and irrigationAdvice (object with frequency, amount, bestTime, method). Return ONLY valid JSON, nothing else."
    )

    user_payload = {
        "field_meta": field_meta,
        "measurements": payload.dict(),
    }

    try:
        client = OpenAI(
            api_key=os.environ.get("DEEPSEEK_API_KEY"),
            base_url=os.environ.get("DEEPSEEK_BASE_URL", "https://api.deepseek.com"),
        )
        resp = client.chat.completions.create(
            model=os.environ.get("DEEPSEEK_MODEL", "deepseek-v4-flash"),
            messages=[
                {"role": "system", "content": system_msg},
                {"role": "user", "content": json.dumps(user_payload)},
            ],
            stream=False,
            reasoning_effort="high",
        )
    except Exception as exc:
        logger.error(f"DeepSeek request failed: {exc}")
        raise HTTPException(status_code=502, detail=f"DeepSeek request failed: {exc}")

    # Extract text from response
    text = resp.choices[0].message.content
    logger.info(f"DeepSeek raw response: {text[:500]}")

    # Try to parse JSON, handling markdown code blocks
    result = _parse_deepseek_response(text)
    if not result:
        logger.error(f"Failed to parse DeepSeek response: {text}")
        raise HTTPException(status_code=502, detail="Failed to parse DeepSeek response as JSON")

    logger.info(f"Normalized result: {json.dumps(result, indent=2)[:500]}")
    return result


def _parse_deepseek_response(text: str) -> dict | None:
    """Parse DeepSeek response, handling markdown code blocks and various formats."""
    text = text.strip()

    # Try to extract JSON from markdown code block (```json ... ```)
    json_match = re.search(r"```(?:json)?\s*({.*?})\s*```", text, re.DOTALL)
    if json_match:
        text = json_match.group(1)

    # Try direct JSON parse
    try:
        data = json.loads(text)
        return _normalize_analysis_result(data)
    except json.JSONDecodeError:
        pass

    # Try to extract JSON object if it's buried in text
    json_match = re.search(r"({.*})", text, re.DOTALL)
    if json_match:
        try:
            data = json.loads(json_match.group(1))
            return _normalize_analysis_result(data)
        except json.JSONDecodeError:
            pass

    return None


def _normalize_analysis_result(data: dict) -> dict:
    """Ensure the analysis result has all expected keys with sensible defaults."""
    normalized = {
        "analysis": _ensure_array(data.get("analysis", [])),
        "recommendations": _ensure_array(data.get("recommendations", [])),
        "suitableCrops": _ensure_array(data.get("suitableCrops", [])),
        "fertilizerRecommendations": _ensure_fertilizer(
            data.get("fertilizerRecommendations", None)
            or data.get("fertilizer_recommendations", None)
        ),
        "irrigationAdvice": _ensure_irrigation(
            data.get("irrigationAdvice", None)
            or data.get("irrigation_advice", None)
        ),
    }
    return normalized


def _ensure_dict(val) -> dict:
    """Coerce non-dict values into an empty dict."""
    return val if isinstance(val, dict) else {}


def _ensure_array(val) -> list:
    """Coerce value to array."""
    if isinstance(val, list):
        return val
    if isinstance(val, str):
        return [val]
    return []


def _ensure_fertilizer(val) -> dict | None:
    """Coerce fertilizer data to expected structure."""
    if not isinstance(val, dict) or not val:
        return None

    base_dressing = _get_nested_dict(val, ["baseDressing", "base_dressing"])
    top_dressing = _get_nested_dict(val, ["topDressing", "top_dressing"])

    return {
        "baseDressing": {
            "type": str(_safe_nested_value(base_dressing, ["type", "Type"], "-")),
            "amount": str(_safe_nested_value(base_dressing, ["amount", "Amount"], "-")),
            "timing": str(_safe_nested_value(base_dressing, ["timing", "Timing"], "-")),
        },
        "topDressing": {
            "type": str(_safe_nested_value(top_dressing, ["type", "Type"], "-")),
            "amount": str(_safe_nested_value(top_dressing, ["amount", "Amount"], "-")),
            "timing": str(_safe_nested_value(top_dressing, ["timing", "Timing"], "-")),
        },
        "organicOptions": _ensure_array(
            val.get("organicOptions", [])
            or val.get("organic_options", [])
        ),
    }


def _get_nested_dict(source: dict, keys: list[str]) -> dict:
    for key in keys:
        candidate = source.get(key)
        if isinstance(candidate, dict):
            return candidate
    return {}


def _safe_nested_value(val, keys: list[str], default=None):
    if isinstance(val, dict):
        for key in keys:
            if key in val:
                return val.get(key)
    return default


def _ensure_irrigation(val) -> dict | None:
    """Coerce irrigation data to expected structure."""
    if not isinstance(val, dict) or not val:
        return None
    return {
        "frequency": str(val.get("frequency", "-")),
        "amount": str(val.get("amount", "-")),
        "bestTime": str(val.get("bestTime", "-")),
        "method": str(val.get("method", "-")),
    }


class SaveSoilDataRequest(BaseModel):
    field_id: str
    ph: float | None = None
    nitrogen: float | None = None
    phosphorus: float | None = None
    potassium: float | None = None
    organicMatter: float | None = None
    texture: str | None = None
    moisture: float | None = None
    cationExchangeCapacity: float | None = None


@router.post("/save")
async def save_soil_data(request: Request, payload: SaveSoilDataRequest):
    """Save soil measurement data to the SoilData table."""
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing authorization token")

    token = auth_header.split(" ", 1)[1]
    current_user = get_current_user(token)
    farm_id = current_user.get("farm_id") if isinstance(current_user, dict) else None
    if not farm_id:
        raise HTTPException(status_code=403, detail="User has no farm context")

    try:
        insert_data = {
            "farm_id": farm_id,
            "field_id": payload.field_id,
            "ph_level": payload.ph,
            "nitrogen": payload.nitrogen,
            "phosphorus": payload.phosphorus,
            "potassium": payload.potassium,
            "organic_matter": payload.organicMatter,
            "texture": payload.texture,
            "moisture": payload.moisture,
            "cec": payload.cationExchangeCapacity,
        }

        # Insert the soil data record using correct 'data' parameter
        resp = supabase_query(
            "soildata",
            method="POST",
            data=insert_data,
        )

        if resp.status_code not in [200, 201]:
            logger.error(f"Failed to save soil data: {resp.status_code} {resp.text}")
            raise HTTPException(
                status_code=500,
                detail="Failed to save soil data to database"
            )

        try:
            result = resp.json() or {}
        except ValueError:
            # Supabase may return an empty body for successful inserts
            result = {}

        logger.info(f"Soil data saved successfully: {result}")
        return {"success": True, "message": "Soil data saved successfully"}

    except Exception as exc:
        logger.error(f"Error saving soil data: {exc}")
        raise HTTPException(status_code=500, detail=f"Error saving soil data: {exc}")
