import os
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from openai import OpenAI

from models.chat import ChatRequest, SaveConversationRequest
from pages.Sign.sign import get_current_user
from services.supabase_chat_service import supabase_chat_service
from pages.SmartAdvisory.constants import AGRICULTURE_KEYWORDS

router = APIRouter(prefix="/api/smart-advisory", tags=["Smart Advisory"])


def _is_agriculture_related(message: str) -> bool:
    text = (message or "").lower()
    return any(keyword in text for keyword in AGRICULTURE_KEYWORDS)


def _fallback_reply() -> str:
    return (
        "I'm here to help with your agriculture questions!\n\n"
        "You can ask me about:\n"
        "• Crop farming\n"
        "• Soil health and testing \n"
        "• Irrigation and water management\n"
        "• Fertilizer recommendations for  soils\n"
        "• Pest and disease control in \n"
        "• Weather patterns and seasonal farming\n"
        "• Sustainable farming practices adapted \n"
        "• Post-harvest handling and storage\n"
        "• Livestock management \n\n"
        "What would you like to learn about?"
    )


def _build_prompt(history: Optional[List[dict]] = None) -> list:
    history_messages = []
    if history:
        for entry in history[-8:]:
            role = entry.get("role") or entry.get("sender") or "user"
            text = entry.get("text") or entry.get("content") or ""
            if not text:
                continue
            if role == "bot":
                history_messages.append({"role": "assistant", "content": text})
            else:
                history_messages.append({"role": "user", "content": text})

    return [
        {
            "role": "system",
            "content": (
                "You are MurimiAI, a practical agriculture assistant specialized in Zimbabwe farming practices and agriculture. "
            ),
        },
        *history_messages,
    ]


def generate_chat_reply(message: str, history: Optional[List[dict]] = None) -> str:
    if not _is_agriculture_related(message):
        return _fallback_reply()

    api_key = os.getenv("DEEPSEEK_API_KEY")
    if not api_key:
        return "DeepSeek API key is not configured. Please set DEEPSEEK_API_KEY in your environment."

    try:
        client = OpenAI(api_key=api_key, base_url="https://api.deepseek.com")
        messages = _build_prompt(history)
        messages.append({"role": "user", "content": message})

        response = client.chat.completions.create(
            model=os.getenv("DEEPSEEK_MODEL", "deepseek-chat"),
            messages=messages,
            temperature=0.4,
            stream=False,
        )

        content = response.choices[0].message.content
        return (content or _fallback_reply()).strip()
    except Exception as exc:
        return f"Sorry, I could not reach DeepSeek right now: {exc}"


@router.get("/conversations")
async def list_smart_conversations(request: Request):
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing authorization token")

    user = get_current_user(auth_header.split(" ", 1)[1])
    conversations = await supabase_chat_service.list_conversations(user["user_id"])

    return [
        {
            "id": item["id"],
            "title": item.get("title") or "Conversation",
            "lastMessage": item.get("last_message") or "",
            "timestamp": item.get("updated_at") or item.get("created_at"),
            "messageCount": item.get("message_count", 0),
            "messages": [],
        }
        for item in conversations
    ]


@router.get("/conversations/{conversation_id}")
async def get_smart_conversation(conversation_id: str, request: Request):
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing authorization token")

    user = get_current_user(auth_header.split(" ", 1)[1])
    conversation = await supabase_chat_service.get_conversation(conversation_id, user["user_id"])
    if not conversation:
        raise HTTPException(status_code=404, detail="Conversation not found")

    messages = await supabase_chat_service.get_messages(conversation_id, user["user_id"])
    return {
        "id": conversation["id"],
        "title": conversation.get("title") or "Conversation",
        "lastMessage": conversation.get("last_message") or "",
        "timestamp": conversation.get("updated_at") or conversation.get("created_at"),
        "messageCount": conversation.get("message_count", 0),
        "messages": [
            {
                "id": msg["id"],
                "text": msg.get("content") or "",
                "sender": msg.get("sender", "user"),
                "timestamp": msg.get("created_at"),
            }
            for msg in messages
        ],
    }


@router.delete("/conversations/{conversation_id}")
async def delete_smart_conversation(conversation_id: str, request: Request):
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing authorization token")

    user = get_current_user(auth_header.split(" ", 1)[1])
    deleted = await supabase_chat_service.delete_conversation(conversation_id, user["user_id"])

    if not deleted:
        raise HTTPException(status_code=404, detail="Conversation not found")

    return {"success": True, "conversation_id": conversation_id}


@router.post("/conversations/save")
async def save_smart_conversation(payload: SaveConversationRequest, request: Request):
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing authorization token")

    user = get_current_user(auth_header.split(" ", 1)[1])
    saved = await supabase_chat_service.save_conversation(
        user_id=user["user_id"],
        conversation_id=payload.conversation_id,
        title=payload.title,
        messages=payload.messages,
    )

    if not saved:
        raise HTTPException(status_code=500, detail="Failed to save conversation")

    return saved


@router.post("/chat")
async def chat_with_smart_advisory(payload: ChatRequest):
    if not payload.message or not payload.message.strip():
        raise HTTPException(status_code=400, detail="Message cannot be empty")

    reply = generate_chat_reply(payload.message, payload.history)
    return {
        "reply": reply,
        "is_agriculture_related": _is_agriculture_related(payload.message),
        "conversation_id": payload.conversation_id or "default",
    }
