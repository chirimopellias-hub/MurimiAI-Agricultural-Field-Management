import uuid

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field
from typing import Optional, Any
from pages.Account.account import get_current_user
from database import supabase_query

router = APIRouter()


class SoilDataModel(BaseModel):
    texture: Optional[str] = ""
    ph: Optional[float] = 7.0
    nitrogen: Optional[float] = 0.0
    phosphorus: Optional[float] = 0.0
    potassium: Optional[float] = 0.0
    organicMatter: Optional[float] = 0.0
    moisture: Optional[float] = 0.0
    cec: Optional[float] = 0.0


class FieldModel(BaseModel):
    fieldId: Optional[str]
    fieldName: str
    size: float
    cropType: Optional[str]
    plantingDate: Optional[str]
    irrigationType: Optional[str]
    growthStage: Optional[str]
    soilData: Optional[SoilDataModel] = Field(default_factory=SoilDataModel)
    
class FieldUpdateModel(BaseModel):
    fieldId: Optional[str] = None
    fieldName: Optional[str] = None
    size: Optional[float] = None
    cropType: Optional[str] = None
    plantingDate: Optional[str] = None
    irrigationType: Optional[str] = None
    growthStage: Optional[str] = None
    soilData: Optional[SoilDataModel] = None


class FarmUpdateModel(BaseModel):
    farmName: Optional[str]
    farmSize: Optional[float]
    district: Optional[str]
    province: Optional[str]
    farmingType: Optional[str]


def _parse_response(resp) -> Any:
    try:
        return resp.json()
    except Exception:
        return None


@router.get('/api/farm')
async def get_farm(request: Request):
    auth_header = request.headers.get('Authorization')
    if not auth_header or not auth_header.startswith('Bearer '):
        raise HTTPException(status_code=401, detail='Missing authorization token')
    token = auth_header.split(' ', 1)[1]
    user = get_current_user(token)
    user_id = user.get('user_id')
    if not user_id:
        raise HTTPException(status_code=400, detail='User has no user_id')

    resp = supabase_query('Farm', filters={'user_id': f'eq.{user_id}'}, select='farm_id,name,hecters,district,province,type')
    data = _parse_response(resp)
    if getattr(resp, 'status_code', 200) >= 400:
        raise HTTPException(status_code=500, detail=f'Failed to fetch farm: {getattr(resp, "text", "")}')
    if not data:
        return {'farmId': '', 'farmName': '', 'farmSize': 0, 'district': '', 'province': '', 'farmingType': ''}
    farm = data[0]
    return {
        'farmId': farm.get('farm_id') or '',
        'farmName': farm.get('name') or '',
        'farmSize': float(farm.get('hecters') or 0),
        'district': farm.get('district') or '',
        'province': farm.get('province') or '',
        'farmingType': farm.get('type') or '',
    }


@router.patch('/api/farm')
async def update_farm(request: Request, data: FarmUpdateModel):
    auth_header = request.headers.get('Authorization')
    if not auth_header or not auth_header.startswith('Bearer '):
        raise HTTPException(status_code=401, detail='Missing authorization token')
    token = auth_header.split(' ', 1)[1]
    user = get_current_user(token)
    user_id = user.get('user_id')
    if not user_id:
        raise HTTPException(status_code=400, detail='User has no user_id')

    resp = supabase_query('Farm', filters={'user_id': f'eq.{user_id}'}, select='farm_id')
    farms = _parse_response(resp)
    if getattr(resp, 'status_code', 200) >= 400:
        raise HTTPException(status_code=500, detail=f'Failed to fetch farm: {getattr(resp, "text", "")}')
    if not farms:
        raise HTTPException(status_code=404, detail='Farm not found for user')
    farm_id = farms[0].get('farm_id')

    update_payload = {}
    if data.farmName is not None:
        update_payload['name'] = data.farmName
    if data.farmSize is not None:
        update_payload['hecters'] = data.farmSize
    if data.district is not None:
        update_payload['district'] = data.district
    if data.province is not None:
        update_payload['province'] = data.province
    if data.farmingType is not None:
        update_payload['type'] = data.farmingType

    if not update_payload:
        raise HTTPException(status_code=400, detail='No fields to update')

    resp2 = supabase_query('Farm', method='PATCH', data=update_payload, filters={'farm_id': f'eq.{farm_id}'})
    if getattr(resp2, 'status_code', 200) >= 400:
        raise HTTPException(status_code=500, detail=f'Failed to update farm: {getattr(resp2, "text", "")}')
    return {'success': True}


@router.get('/api/farm/fields')
async def list_fields(request: Request):
    auth_header = request.headers.get('Authorization')
    if not auth_header or not auth_header.startswith('Bearer '):
        raise HTTPException(status_code=401, detail='Missing authorization token')
    token = auth_header.split(' ', 1)[1]
    user = get_current_user(token)
    user_id = user.get('user_id')
    if not user_id:
        raise HTTPException(status_code=400, detail='User has no user_id')

    resp2 = supabase_query('Farm', filters={'user_id': f'eq.{user_id}'}, select='farm_id')
    farms = _parse_response(resp2)
    if getattr(resp2, 'status_code', 200) >= 400:
        raise HTTPException(status_code=500, detail=f'Failed to fetch farm: {getattr(resp2, "text", "")}')
    if not farms:
        return []
    farm_id = farms[0].get('farm_id')

    resp2 = supabase_query('Field', filters={'farm_id': f'eq.{farm_id}'})
    fields = _parse_response(resp2) or []
    if getattr(resp2, 'status_code', 200) >= 400:
        raise HTTPException(status_code=500, detail=f'Failed to fetch fields: {getattr(resp2, "text", "")}')

    results = []
    for f in fields:
        field_id = f.get('field_id')
        soil_data = {
            'texture': 'None',
            'ph': 7.0,
            'nitrogen': 0.0,
            'phosphorus': 0.0,
            'potassium': 0.0,
            'organicMatter': 0.0,
            'moisture': 0.0,
            'cec': 0.0,
        }
        if field_id:
            resp_soil = supabase_query('soildata', filters={'field_id': f'eq.{field_id}'})
            soil_rows = _parse_response(resp_soil) or []
            if soil_rows:
                soil_row = soil_rows[0]
                soil_data = {
                    'texture': soil_row.get('texture') or 'None',
                    'ph': float(soil_row.get('ph_level') or 0),
                    'nitrogen': float(soil_row.get('nitrogen') or 0),
                    'phosphorus': float(soil_row.get('phosphorus') or 0),
                    'potassium': float(soil_row.get('potassium') or 0),
                    'organicMatter': float(soil_row.get('organic_matter') or 0),
                    'moisture': float(soil_row.get('moisture') or 0),
                    'cec': float(soil_row.get('cec') or 0),
                }
        f_out = {
            'fieldId': f.get('field_id'),
            'fieldName': f.get('name') or f.get('field_name') or f.get('fieldName'),
            'size': f.get('hectares') or f.get('size') or 0,
            'cropType': f.get('crop_name') or f.get('cropType'),
            'plantingDate': f.get('sowing_date') or f.get('planting_date') or f.get('plantingDate'),
            'irrigationType': f.get('irrigation_type') or f.get('irrigationType'),
            'growthStage': f.get('growth_stage') or f.get('growthStage'),
            'soilData': soil_data,
        }
        results.append(f_out)

    return results


@router.post('/api/farm/fields')
async def add_field_route(request: Request, payload: FieldModel):
    auth_header = request.headers.get('Authorization')
    if not auth_header or not auth_header.startswith('Bearer '):
        raise HTTPException(status_code=401, detail='Missing authorization token')
    token = auth_header.split(' ', 1)[1]
    user = get_current_user(token)
    user_id = user.get('user_id')
    if not user_id:
        raise HTTPException(status_code=400, detail='User has no user_id')

    resp = supabase_query('Farm', filters={'user_id': f'eq.{user_id}'}, select='farm_id')
    farms = _parse_response(resp)
    if getattr(resp, 'status_code', 200) >= 400:
        raise HTTPException(status_code=500, detail=f'Failed to fetch farm: {getattr(resp, "text", "")}')
    if not farms:
        raise HTTPException(status_code=404, detail='Farm not found for user')
    farm_id = farms[0].get('farm_id')

    field_payload = {
        'field_id': str(uuid.uuid4()),
        'farm_id': farm_id,
        'name': payload.fieldName,
        'crop_name': payload.cropType,
        'sowing_date': payload.plantingDate,
        'irrigation_type': payload.irrigationType,
        'growth_stage': payload.growthStage,
        'hectares': payload.size,
    }
    resp_field = supabase_query('Field', method='POST', data=field_payload)
    if getattr(resp_field, 'status_code', 200) >= 400:
        raise HTTPException(status_code=500, detail=f'Failed to create field: {getattr(resp_field, "text", "")}')
    created = _parse_response(resp_field)
    created_id = None
    if created and isinstance(created, list) and created:
        created_id = created[0].get('field_id') or created[0].get('id')

    if payload.soilData and created_id:
        soil_payload = {
            'farm_id': farm_id,
            'field_id': created_id,
            'texture': payload.soilData.texture,
            'ph_level': payload.soilData.ph,
            'nitrogen': payload.soilData.nitrogen,
            'phosphorus': payload.soilData.phosphorus,
            'potassium': payload.soilData.potassium,
            'organic_matter': payload.soilData.organicMatter,
            'moisture': payload.soilData.moisture,
            'cec': payload.soilData.cec,
        }
        resp_soil = supabase_query('soildata', method='POST', data=soil_payload)
        if getattr(resp_soil, 'status_code', 200) >= 400:
            raise HTTPException(status_code=500, detail=f'Field created but failed to save soil data: {getattr(resp_soil, "text", "")}')

    return {'success': True}


@router.patch('/api/farm/fields/{field_id}')
async def update_field_route(request: Request, field_id: str, payload: FieldUpdateModel):
    auth_header = request.headers.get('Authorization')
    if not auth_header or not auth_header.startswith('Bearer '):
        raise HTTPException(status_code=401, detail='Missing authorization token')
    token = auth_header.split(' ', 1)[1]
    user = get_current_user(token)
    user_id = user.get('user_id')
    if not user_id:
        raise HTTPException(status_code=400, detail='User has no user_id')

    update_payload = {}
    if getattr(payload, 'fieldName', None) is not None:
        update_payload['name'] = payload.fieldName
    if getattr(payload, 'size', None) is not None:
        update_payload['hectares'] = payload.size
    if getattr(payload, 'cropType', None) is not None:
        update_payload['crop_name'] = payload.cropType
    if getattr(payload, 'plantingDate', None) is not None:
        update_payload['sowing_date'] = payload.plantingDate
    if getattr(payload, 'irrigationType', None) is not None:
        update_payload['irrigation_type'] = payload.irrigationType
    if getattr(payload, 'growthStage', None) is not None:
        update_payload['growth_stage'] = payload.growthStage

    if update_payload:
        resp = supabase_query('Field', method='PATCH', data=update_payload, filters={'field_id': f'eq.{field_id}'})
        if getattr(resp, 'status_code', 200) >= 400:
            raise HTTPException(status_code=500, detail=f'Failed to update field: {getattr(resp, "text", "")}')

    if payload.soilData is not None:
        soil_payload = {
            'texture': payload.soilData.texture,
            'ph_level': payload.soilData.ph,
            'nitrogen': payload.soilData.nitrogen,
            'phosphorus': payload.soilData.phosphorus,
            'potassium': payload.soilData.potassium,
            'organic_matter': payload.soilData.organicMatter,
            'moisture': payload.soilData.moisture,
            'cec': payload.soilData.cec,
        }
        resp_check = supabase_query('soildata', filters={'field_id': f'eq.{field_id}'})
        soil_rows = _parse_response(resp_check) or []
        if getattr(resp_check, 'status_code', 200) >= 400:
            raise HTTPException(status_code=500, detail=f'Failed to query soil data: {getattr(resp_check, "text", "")}')
        if soil_rows:
            resp_upd = supabase_query('soildata', method='PATCH', data=soil_payload, filters={'field_id': f'eq.{field_id}'})
            if getattr(resp_upd, 'status_code', 200) >= 400:
                raise HTTPException(status_code=500, detail=f'Failed to update soil data: {getattr(resp_upd, "text", "")}')
        else:
            soil_payload['field_id'] = field_id
            # Ensure we include farm_id when creating a new soil data row
            resp_field = supabase_query('Field', filters={'field_id': f'eq.{field_id}'}, select='farm_id')
            field_rows = _parse_response(resp_field) or []
            farm_id = None
            if field_rows and isinstance(field_rows, list):
                farm_id = field_rows[0].get('farm_id')
            if not farm_id:
                raise HTTPException(status_code=500, detail='Failed to find farm_id for field when creating soil data')
            soil_payload['farm_id'] = farm_id
            resp_create = supabase_query('soildata', method='POST', data=soil_payload)
            if getattr(resp_create, 'status_code', 200) >= 400:
                raise HTTPException(status_code=500, detail=f'Failed to create soil data: {getattr(resp_create, "text", "")}')

    return {'success': True}


@router.delete('/api/farm/fields/{field_id}')
async def delete_field_route(request: Request, field_id: str):
    auth_header = request.headers.get('Authorization')
    if not auth_header or not auth_header.startswith('Bearer '):
        raise HTTPException(status_code=401, detail='Missing authorization token')
    token = auth_header.split(' ', 1)[1]
    user = get_current_user(token)
    user_id = user.get('user_id')
    if not user_id:
        raise HTTPException(status_code=400, detail='User has no user_id')

    resp_soil = supabase_query('soildata', method='DELETE', filters={'field_id': f'eq.{field_id}'})
    if getattr(resp_soil, 'status_code', 200) >= 400:
        raise HTTPException(status_code=500, detail=f'Failed to delete soil data: {getattr(resp_soil, "text", "")}')

    resp_field = supabase_query('Field', method='DELETE', filters={'field_id': f'eq.{field_id}'})
    if getattr(resp_field, 'status_code', 200) >= 400:
        raise HTTPException(status_code=500, detail=f'Failed to delete field: {getattr(resp_field, "text", "")}')

    return {'success': True}
