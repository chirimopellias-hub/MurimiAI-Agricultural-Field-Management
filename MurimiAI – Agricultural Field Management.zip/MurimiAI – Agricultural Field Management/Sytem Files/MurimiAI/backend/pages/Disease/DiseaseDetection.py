from fastapi import APIRouter, File, UploadFile, HTTPException
import logging
import os
from io import BytesIO
from typing import Dict, Any

# Reduce TensorFlow log noise and optionally disable oneDNN to avoid nondeterministic ops
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")
os.environ.setdefault("TF_ENABLE_ONEDNN_OPTS", "0")

import numpy as np
from PIL import Image, UnidentifiedImageError
import tensorflow as tf

# Logging only; app creation and CORS are handled in backend/main.py
logging.basicConfig(level=logging.INFO)

router = APIRouter()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODELS_DIR = os.path.join(BASE_DIR, "models")

# Default model file or model directory paths (supports nested model folders)
CROP_MODEL_KEY = "crop"
CROP_LABELS = ["tomato", "potato", "corn"]

MODEL_FILES = {
    "tomato": os.getenv("TOMATO_MODEL") or os.path.join(MODELS_DIR, "Tomato_Model1.keras"),
    "potato": os.getenv("POTATO_MODEL") or os.path.join(MODELS_DIR, "Potato_Model1.keras"),
    "corn": os.getenv("CORN_MODEL") or os.path.join(MODELS_DIR, "Corn_Model1.keras"),
    CROP_MODEL_KEY: os.getenv("CROP_MODEL") or os.path.join(MODELS_DIR, "Crop_Model1.keras"),
}

# Class labels for each model (adjust to match your trained models)
MODEL_CLASSES: Dict[str, list] = {
    "tomato": ['Tomato - Bacterial Spot',
               'Tomato - Early Blight',
               'Tomato - Healthy',
               'Tomato - Late Blight',
               'Tomato - Septoria Leaf Spot',
               'Tomato - Yellow Leaf Curl Virus'],
    
    "potato": ['Potato - Early Blight', 
               'Potato - Healthy', 
               'Potato - Late Blight'],
    "corn": ['Corn (Maize) - Cercospora Leaf Spot',
             'Corn (Maize) - Common Rust',
             'Corn (Maize) - Healthy',
             'Corn (Maize) - Northern Leaf Blight'],
    CROP_MODEL_KEY: CROP_LABELS,
}

MODELS: Dict[str, Any] = {}

def _expand_model_candidates(path: str) -> list[str]:
    candidates = []
    if os.path.isdir(path):
        # Only treat a directory itself as a model if it contains a SavedModel format.
        if os.path.exists(os.path.join(path, "saved_model.pb")):
            candidates.append(path)
        for root, _, files in os.walk(path):
            for filename in files:
                if filename.lower().endswith((".keras", ".h5", ".hdf5")):
                    candidates.append(os.path.join(root, filename))
    else:
        candidates.append(path)
    return candidates


def load_models():
    for key, path in MODEL_FILES.items():
        if not path:
            logging.warning("No path configured for model %s", key)
            continue

        candidates = []
        candidates.extend(_expand_model_candidates(path))

        try:
            basename = os.path.basename(path)
            candidates.extend(_expand_model_candidates(os.path.join(MODELS_DIR, basename)))
        except Exception:
            pass

        model_subdir = os.path.join(MODELS_DIR, basename if path else key)
        if os.path.isdir(model_subdir):
            candidates.extend(_expand_model_candidates(model_subdir))

        seen = set()
        resolved = None
        for candidate in candidates:
            if candidate in seen:
                continue
            seen.add(candidate)
            if os.path.exists(candidate):
                resolved = candidate
                break

        if not resolved and os.path.isdir(path):
            # Fallback: if the configured model path is a directory, try loading
            # the first supported model file found within it.
            for root, _, files in os.walk(path):
                for filename in files:
                    if filename.lower().endswith((".keras", ".h5", ".hdf5")):
                        candidate = os.path.join(root, filename)
                        if candidate not in seen and os.path.exists(candidate):
                            resolved = candidate
                            break
                if resolved:
                    break

        if not resolved:
            logging.warning("Model file for %s not found at any of: %s", key, candidates)
            continue

        if key in MODELS:
            continue

        try:
            MODELS[key] = tf.keras.models.load_model(resolved)
            logging.info("Loaded model '%s' from %s", key, resolved)
        except Exception:
            logging.exception("Failed loading model '%s' from %s", key, resolved)

    if not MODELS:
        available = []
        if os.path.isdir(MODELS_DIR):
            available = sorted(os.listdir(MODELS_DIR))
        raise RuntimeError(f"No models loaded. Check MODEL_FILES or place models in {MODELS_DIR}. Available: {available}")


async def load_uploaded_image(file: UploadFile) -> Image.Image:
    if not file.content_type or not file.content_type.startswith("image"):
        raise HTTPException(status_code=400, detail="Uploaded file must be an image")

    try:
        contents = await file.read()
        return Image.open(BytesIO(contents)).convert("RGB")
    except UnidentifiedImageError:
        raise HTTPException(status_code=400, detail="Uploaded file is not a valid image")
    except Exception as e:
        logging.exception("Error reading uploaded image: %s", e)
        raise HTTPException(status_code=400, detail="Unable to read uploaded image")


def preprocess_image(image: Image.Image, target_size=(256, 256)) -> np.ndarray:
    image = image.convert("RGB").resize(target_size)
    arr = np.array(image).astype(np.float32) / 255.0
    return np.expand_dims(arr, axis=0)


def predict_from_model(model_key: str, x: np.ndarray) -> tuple[str, float, np.ndarray]:
    model = MODELS[model_key]
    preds = model.predict(x)
    top_scores = np.asarray(preds[0])
    idx = int(np.argmax(top_scores))
    labels = MODEL_CLASSES.get(model_key, [str(i) for i in range(len(top_scores))])
    label = labels[idx] if idx < len(labels) else str(idx)
    return label, float(top_scores[idx]), top_scores


def classify_crop(x: np.ndarray) -> tuple[str, float, Dict[str, float]]:
    if CROP_MODEL_KEY in MODELS:
        label, confidence, _ = predict_from_model(CROP_MODEL_KEY, x)
        return label, confidence, {CROP_MODEL_KEY: confidence}
    # No crop classifier available — require explicit crop classifier model
    raise RuntimeError(
        "No crop classifier model (CROP_MODEL) available; configure the CROP_MODEL or disable crop validation."
    )


@router.get("/predict/health")
def health():
    return {"status": "ok", "loaded_models": list(MODELS.keys())}


@router.post("/predict/crop")
async def predict_crop(file: UploadFile = File(...)):
    if CROP_MODEL_KEY not in MODELS:
        raise HTTPException(status_code=501, detail="Crop classifier not available on server. Configure CROP_MODEL to enable crop detection.")

    image = await load_uploaded_image(file)
    x = preprocess_image(image)
    crop_label, crop_confidence, crop_confidences = classify_crop(x)
    return {
        "predicted_crop": crop_label,
        "confidence": crop_confidence,
        "crop_confidences": crop_confidences,
    }


@router.post("/predict/auto")
async def predict_auto(file: UploadFile = File(...)):
    if CROP_MODEL_KEY not in MODELS:
        raise HTTPException(status_code=501, detail="Crop classifier not available on server. Configure CROP_MODEL to enable auto prediction.")

    image = await load_uploaded_image(file)
    x = preprocess_image(image)
    predicted_crop, crop_confidence, crop_confidences = classify_crop(x)
    if predicted_crop not in MODELS or predicted_crop == CROP_MODEL_KEY:
        raise HTTPException(status_code=500, detail="Unable to map crop prediction to a disease model")

    label, confidence, _ = predict_from_model(predicted_crop, x)
    return {
        "predicted_crop": predicted_crop,
        "crop_confidence": crop_confidence,
        "crop_confidences": crop_confidences,
        "class": label,
        "confidence": confidence,
        "model_confidences": {predicted_crop: confidence},
    }


@router.post("/predict/{model_id}")
async def predict(model_id: str, file: UploadFile = File(...)):
    if model_id not in MODELS:
        raise HTTPException(status_code=404, detail=f"Model '{model_id}' not found or failed to load")

    if model_id == CROP_MODEL_KEY:
        return await predict_crop(file)

    image = await load_uploaded_image(file)
    x = preprocess_image(image)

    # If a crop classifier is available, validate the uploaded image's crop.
    if CROP_MODEL_KEY in MODELS:
        predicted_crop, _, crop_confidences = classify_crop(x)
        if predicted_crop != model_id:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"Uploaded image appears to be '{predicted_crop}', not '{model_id}'. "
                    f"Predicted crop confidences: {crop_confidences}"
                ),
            )

    label, confidence, _ = predict_from_model(model_id, x)
    return {"class": label, "confidence": confidence, "model_confidences": {model_id: confidence}}


