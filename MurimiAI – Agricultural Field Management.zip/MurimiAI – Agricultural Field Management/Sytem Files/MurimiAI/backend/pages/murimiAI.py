import sys
from pathlib import Path
from fastapi import HTTPException

# Add backend directory to path so we can import database helper
backend_dir = Path(__file__).parent.parent
if str(backend_dir) not in sys.path:
    sys.path.insert(0, str(backend_dir))

from database import supabase, supabase_query


def get_farm_by_user_id(user_id: str) -> dict:
    """Retrieve Farm record details for the given user_id."""
    if not user_id or not user_id.strip():
        raise HTTPException(status_code=400, detail="Missing or invalid user_id")
    
    print(f"=== DEBUG: Searching for farm with user_id: '{user_id}' ===")
    
    response = supabase_query("Farm", filters={"user_id": f"eq.{user_id}"}, select="farm_id,name")

    if getattr(response, 'error', None):
        raise HTTPException(
            status_code=500,
            detail=f"Failed to query Farm for user_id '{user_id}': {response.error}"
        )

    farms = getattr(response, 'data', None)
    if not farms:
        return {
            "farm_id": "",
            "name": ""
        }

    farm = farms[0]
    return {
        "farm_id": farm.get("farm_id", ""),
        "name": farm.get("name", "")
    }


def get_farm_id_and_name_for_user(user: dict) -> dict:
    """Retrieve farm id and name from a user payload containing the user_id."""
    user_id = user.get("user_id") if isinstance(user, dict) else None
    if not user_id or not isinstance(user_id, str) or not user_id.strip():
        raise HTTPException(status_code=400, detail="User payload must include a valid user_id")

    return get_farm_by_user_id(user_id.strip())
