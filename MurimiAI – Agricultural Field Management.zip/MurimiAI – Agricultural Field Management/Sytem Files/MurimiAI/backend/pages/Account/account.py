from fastapi import HTTPException
import jwt
import os
import bcrypt
import sys
from pathlib import Path

# Add backend directory to path
backend_dir = Path(__file__).parent.parent.parent
if str(backend_dir) not in sys.path:
    sys.path.insert(0, str(backend_dir))

from database import supabase_query
from models.Sign import ChangePasswordData, UpdateUserData

SECRET_KEY = os.getenv("SECRET_KEY")

def _normalize_password_hash(password):
    if password is None:
        return ""
    if isinstance(password, (bytes, bytearray)):
        password = password.decode("utf-8", errors="ignore")
    if not isinstance(password, str):
        password = str(password)
    password = password.strip()
    if (password.startswith("b'") and password.endswith("'")) or (password.startswith('b"') and password.endswith('"')):
        password = password[2:-1]
    return password


def _response_error(response, action: str):
    try:
        body = response.json()
    except Exception:
        body = response.text
    return f"{action} failed: status={response.status_code}, body={body}"


def _decode_token(token: str):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")


def get_current_user(token: str):
    payload = _decode_token(token)
    user_id = payload.get("user_id")
    if not user_id:
        raise HTTPException(status_code=401, detail="Invalid token payload")

    response = supabase_query("User", filters={"user_id": f"eq.{user_id}"})
    if response.status_code != 200:
        raise HTTPException(status_code=500, detail=_response_error(response, "Fetch user"))

    users = response.json()
    if not users:
        raise HTTPException(status_code=404, detail="User not found")

    user = users[0]
    farm_id = ""
    farm_name = ""
    farm_response = supabase_query("Farm", filters={"user_id": f"eq.{user_id}"})
    if farm_response.status_code == 200:
        farms = farm_response.json()
        if farms:
            farm_id = farms[0].get("farm_id", "")
            farm_name = farms[0].get("name", "")

    return {
        "user_id": user.get("user_id", ""),
        "email": user.get("email", ""),
        "name": user.get("name", ""),
        "phone": user.get("phone", ""),
        "language": user.get("language", ""),
        "farm_id": farm_id,
        "farm_name": farm_name,
    }


def update_user_profile(token: str, data: UpdateUserData):
    payload = _decode_token(token)
    user_id = payload.get("user_id")
    if not user_id:
        raise HTTPException(status_code=401, detail="Invalid token payload")

    response = supabase_query("User", filters={"user_id": f"eq.{user_id}"})
    if response.status_code != 200:
        raise HTTPException(status_code=500, detail=_response_error(response, "Fetch user"))

    users = response.json()
    if not users:
        raise HTTPException(status_code=404, detail="User not found")

    update_data = {
        "name": data.name.strip(),
        "email": data.email.strip(),
        "phone": data.phone.strip() if data.phone else "",
        "language": data.language.strip() if data.language else "",
    }

    patch_response = supabase_query("User", "PATCH", update_data, filters={"user_id": f"eq.{user_id}"})
    if patch_response.status_code not in (200, 204):
        raise HTTPException(status_code=500, detail=_response_error(patch_response, "Update user profile"))

    return {"success": True}


def change_user_password(token: str, data: ChangePasswordData):
    payload = _decode_token(token)
    user_id = payload.get("user_id")
    if not user_id:
        raise HTTPException(status_code=401, detail="Invalid token payload")

    if data.new_password != data.confirm_password:
        raise HTTPException(status_code=400, detail="New password and confirmation do not match")

    if len(data.new_password) < 6:
        raise HTTPException(status_code=400, detail="Password must be at least 6 characters long")

    response = supabase_query("User", filters={"user_id": f"eq.{user_id}"})
    if response.status_code != 200:
        raise HTTPException(status_code=500, detail=_response_error(response, "Fetch user"))

    users = response.json()
    if not users:
        raise HTTPException(status_code=404, detail="User not found")

    user = users[0]
    stored_password = _normalize_password_hash(user.get("password"))
    if not stored_password or not stored_password.startswith("$2"):
        raise HTTPException(status_code=400, detail="Invalid credentials")

    try:
        if not bcrypt.checkpw(data.old_password.encode("utf-8"), stored_password.encode("utf-8")):
            raise HTTPException(status_code=400, detail="Current password is incorrect")
    except (ValueError, TypeError):
        raise HTTPException(status_code=400, detail="Current password is incorrect")

    hashed_password = bcrypt.hashpw(data.new_password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")
    patch_response = supabase_query("User", "PATCH", {"password": hashed_password}, filters={"user_id": f"eq.{user_id}"})
    if patch_response.status_code not in (200, 204):
        raise HTTPException(status_code=500, detail=_response_error(patch_response, "Change password"))

    return {"success": True}
