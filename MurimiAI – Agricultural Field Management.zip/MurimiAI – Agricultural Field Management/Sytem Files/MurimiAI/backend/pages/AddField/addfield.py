from datetime import datetime
import secrets
from fastapi import HTTPException
from fastapi.responses import JSONResponse

from database import supabase, supabase_query
from models.FieldData import FieldData

def _generate_unique_id(prefix: str, suffix: str, table: str, field: str, digits: int = 3):
    for _ in range(20):
        candidate = f"{prefix}{secrets.randbelow(10 ** digits):0{digits}d}{suffix}"
        response = supabase.table(table).select(field).eq(field, candidate).execute()
        if getattr(response, 'error', None):
            raise HTTPException(status_code=500, detail=f"Check {table} ID uniqueness failed: {response.error}")
        if not response.data:
            return candidate
    raise HTTPException(status_code=500, detail=f"Unable to generate unique {field} after multiple attempts")


def get_new_field_id() -> str:
    current_datetime = datetime.now()
    year_suffix = str(current_datetime.year)[-1:]
    month_suffix = str(current_datetime.month)[-1:]
    prefix = f"MRA{year_suffix}{month_suffix}"
    return _generate_unique_id(prefix, "D", "Field", "field_id")

async def add_field(field: FieldData):
    try:
        # Generate a unique ID for the field
        current_datetime = datetime.now()
        year_suffix = str(current_datetime.year)[-1:]
        month_suffix = str(current_datetime.month)[-1:]
        prefix = f"MRA{year_suffix}{month_suffix}"
        field_id = _generate_unique_id(prefix, "D", "Field", "field_id")
        
        # Get current timestamp
        created_at = datetime.now().isoformat()
        
        # Prepare data for insertion into Field table
        field_record = {
            "field_id": field_id,
            "farm_id": field.farm_id,
            "name": field.name,
            "crop_name": field.crop_name,
            "crop_variety": field.crop_variety,
            "sowing_date": field.sowing_date,
            "irrigation_type": field.irrigation_type,
            "growth_stage": field.growth_stage,
            "field_coordinates": field.field_coordinates,
            "hectares": field.hectares,
            "location": field.location.dict() if field.location else None,
            "created_at": created_at,
        }
        
        result = supabase.table("Field").insert(field_record).execute()

        if not getattr(result, "data", None):
            raise HTTPException(status_code=500, detail="Failed to insert field data")

        # Save soil data separately to soildata table if provided
        if field.soil_data is not None:
            soil_values = [
                field.soil_data.texture,
                field.soil_data.ph_level,
                field.soil_data.nitrogen,
                field.soil_data.phosphorus,
                field.soil_data.potassium,
                field.soil_data.organic_matter,
                field.soil_data.moisture,
                field.soil_data.cec,
            ]
            if any(value is not None for value in soil_values):
                soil_record = {
                    "farm_id": field.farm_id,
                    "field_id": field_id,
                    "texture": field.soil_data.texture,
                    "ph_level": field.soil_data.ph_level,
                    "nitrogen": field.soil_data.nitrogen,
                    "phosphorus": field.soil_data.phosphorus,
                    "potassium": field.soil_data.potassium,
                    "organic_matter": field.soil_data.organic_matter,
                    "moisture": field.soil_data.moisture,
                    "cec": field.soil_data.cec,
                }
                soil_result = supabase.table("soildata").insert(soil_record).execute()
                if getattr(soil_result, "error", None):
                    raise HTTPException(
                        status_code=500,
                        detail=f"Field created but failed to save soil data: {soil_result.error}",
                    )

        return JSONResponse(
            status_code=201,
            content={
                "message": "Field added successfully",
                "field_id": field_id,
                "data": result.data[0],
            },
        )

    except Exception as e:
        print(f"Error adding field: {e}")
        raise HTTPException(status_code=500, detail=f"Server error: {e}")
