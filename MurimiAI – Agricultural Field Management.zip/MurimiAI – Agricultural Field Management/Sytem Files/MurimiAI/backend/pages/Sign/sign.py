from fastapi import HTTPException
import jwt
import datetime
import os
import bcrypt
import secrets
import sys
from pathlib import Path

# Add backend directory to path
backend_dir = Path(__file__).parent.parent.parent
if str(backend_dir) not in sys.path:
    sys.path.insert(0, str(backend_dir))

from database import supabase_query
from models.Sign import SignInData, SignUpData
from pages.Account.account import get_current_user, update_user_profile, change_user_password

SECRET_KEY = os.getenv("SECRET_KEY")

def _normalize_password_hash(password):
    if password is None:
        return ""
    if isinstance(password, (bytes, bytearray)):
        password = password.decode("utf-8", errors="ignore")
    if not isinstance(password, str):
        password = str(password)
    password = password.strip()
    if (password.startswith("b'") and password.endswith("'")) or (password.startswith('b"') and password.endswith('"')):
        password = password[2:-1]
    return password

def _response_error(response, action: str):
    try:
        body = response.json()
    except Exception:
        body = response.text
    return f"{action} failed: status={response.status_code}, body={body}"

def _generate_unique_id(prefix: str, suffix: str, table: str, field: str, digits: int = 3):
    for _ in range(20):
        candidate = f"{prefix}{secrets.randbelow(10 ** digits):0{digits}d}{suffix}"
        response = supabase_query(table, filters={field: f"eq.{candidate}"})
        if response.status_code != 200:
            raise HTTPException(status_code=500, detail=_response_error(response, f"Check {table} ID uniqueness"))
        if not response.json():
            return candidate
    raise HTTPException(status_code=500, detail=f"Unable to generate unique {field} after multiple attempts")



def signup(data: SignUpData):
    try:
        # Debug: log incoming signup payload (avoid printing raw password)
        try:
            farm_preview = {k: v for k, v in (data.farm or {}).items()}
        except Exception:
            farm_preview = str(data.farm)
        print(f"Signup request: name={data.name!r}, email={data.email!r}, phone={data.phone!r}, language={data.language!r}, farm={farm_preview}")

        # Check if user already exists
        response = supabase_query("User", filters={"email": f"eq.{data.email}"})
        if response.status_code != 200:
            print(f"User existence check failed: status={response.status_code}, text={getattr(response, 'text', '')}")
            raise HTTPException(status_code=500, detail=_response_error(response, "User existence check"))
        if response.json():
            raise HTTPException(status_code=400, detail="User already exists")

        # Generate user ID and farm ID using a unique random suffix
        current_datetime = datetime.datetime.now()
        year_suffix = str(current_datetime.year)[-1:]
        month_suffix = str(current_datetime.month)[-1:]
        prefix = f"MRA{year_suffix}{month_suffix}"
        user_id = _generate_unique_id(prefix, "U", "User", "user_id")
        farm_id = _generate_unique_id(prefix, "F", "Farm", "farm_id")

        # Hash password
        hashed_password = bcrypt.hashpw(data.password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

        # Insert user
        user_data = {
            "user_id": user_id,
            "name": data.name,
            "email": data.email,
            "phone": data.phone,
            "password": hashed_password,
            "language": data.language
        }
        user_response = supabase_query("User", "POST", user_data)
        print(f"Create user response: status={user_response.status_code}, text={getattr(user_response, 'text', '')}")
        if user_response.status_code != 201:
            raise HTTPException(status_code=400, detail=_response_error(user_response, "Create user"))

        # Insert farm
        # Ensure farm values are simple types (strings) to avoid PostgREST type issues
        farm_data = (data.farm or {}).copy()
        for k, v in list(farm_data.items()):
            if isinstance(v, (int, float, bool)):
                farm_data[k] = str(v)
            elif v is None:
                farm_data[k] = None

        # Strip unknown/removed columns from the farm payload to match DB schema
        allowed_keys = {"name", "hecters", "district", "province", "type"}
        for k in list(farm_data.keys()):
            if k not in allowed_keys:
                farm_data.pop(k, None)

        farm_data["farm_id"] = farm_id
        farm_data["user_id"] = user_id
        farm_response = supabase_query("Farm", "POST", farm_data)
        print(f"Create farm response: status={farm_response.status_code}, text={getattr(farm_response, 'text', '')}")
        if farm_response.status_code != 201:
            raise HTTPException(status_code=400, detail=_response_error(farm_response, "Create farm"))

        return {
            "message": "Account and farm created successfully.",
            "user_id": user_id,
            "farm_id": farm_id,
            "farm_name": farm_data.get("name", "")
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

def signin(data: SignInData):
    try:
        identifier = (data.identifier or "").strip()

        # Debug logging to help diagnose signin issues
        print(f"Signin attempt for identifier: '{identifier}'")

        # Try first by user_id
        response = supabase_query(
            "User",
            filters={"user_id": f"eq.{identifier}"}
        )
        if response.status_code != 200:
            # treat as server error rather than silent invalid credentials
            print(f"User lookup (by user_id) returned status {response.status_code}: {getattr(response, 'text', '')}")
            raise HTTPException(status_code=500, detail=_response_error(response, "User lookup by user_id"))

        users = response.json()
        # If not found by user_id, try lookup by email (case-insensitive attempt)
        if not users:
            print(f"No user with user_id={identifier}; trying email lookup")
            # try exact email
            response = supabase_query(
                "User",
                filters={"email": f"eq.{identifier}"}
            )
            if response.status_code != 200:
                print(f"User lookup (by email exact) returned status {response.status_code}: {getattr(response, 'text', '')}")
                raise HTTPException(status_code=500, detail=_response_error(response, "User lookup by email"))

            users = response.json()

        # If still not found, try lowercased email match (some DBs store lowercase)
        if not users and identifier:
            resp2 = supabase_query(
                "User",
                filters={"email": f"eq.{identifier.lower()}"}
            )
            if resp2.status_code == 200:
                users = resp2.json()
            else:
                print(f"User lookup (by email lower) returned status {resp2.status_code}: {getattr(resp2, 'text', '')}")

        if not users:
            print("Signin failed: no matching user found")
            raise HTTPException(status_code=400, detail="Invalid credentials")

        user = users[0]
        stored_password = _normalize_password_hash(user.get("password"))
        if not stored_password or not stored_password.startswith("$2"):
            raise HTTPException(status_code=400, detail="Invalid credentials")

        try:
            if not bcrypt.checkpw(data.password.encode('utf-8'), stored_password.encode('utf-8')):
                raise HTTPException(status_code=400, detail="Invalid credentials")
        except (ValueError, TypeError):
            raise HTTPException(status_code=400, detail="Invalid credentials")

        farm_id = None
        farm_name = ""
        farm_response = supabase_query("Farm", filters={"user_id": f"eq.{user['user_id']}"})
        if farm_response.status_code == 200:
            farms = farm_response.json()
            if farms:
                farm_id = farms[0].get("farm_id")
                farm_name = farms[0].get("name", "")

        # Generate token
        token = jwt.encode({
            "user_id": user["user_id"],
            "exp": datetime.datetime.utcnow() + datetime.timedelta(hours=24)
        }, SECRET_KEY, algorithm="HS256")

        return {
            "token": token,
            "user_id": user["user_id"],
            "email": user["email"],
            "name": user.get("name", ""),
            "farm_id": farm_id or "",
            "farm_name": farm_name
        }
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(status_code=500, detail="Internal server error")