import os
import requests
from dotenv import load_dotenv
from supabase import create_client, Client

# Load environment variables from .env file in the backend directory
load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), '.env'))

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")
SUPABASE_ANON_KEY = os.getenv("SUPABASE_ANON_KEY")
SUPABASE_BUCKET_NAME = os.getenv("SUPABASE_BUCKET_NAME")

if not SUPABASE_URL or not SUPABASE_ANON_KEY:
    raise ValueError("Missing Supabase configuration in .env file")

# Choose an AUTH_KEY that is a valid JWT-like key (service role or anon).
# Some projects may accidentally set a publishable token in SUPABASE_KEY which is
# not a valid JWT and will cause PostgREST errors like 'JWT cryptographic operation failed'.
def _clean(k: str | None) -> str | None:
    if not k:
        return None
    return k.strip().strip('"').strip("'")

_supabase_key = _clean(SUPABASE_KEY)
_supabase_anon = _clean(SUPABASE_ANON_KEY)

# Heuristic: a JWT typically starts with 'eyJ' and contains two dots.
def _looks_like_jwt(val: str | None) -> bool:
    return bool(val and val.startswith("eyJ") and val.count('.') == 2)

AUTH_KEY = None
if _looks_like_jwt(_supabase_key):
    AUTH_KEY = _supabase_key
elif _looks_like_jwt(_supabase_anon):
    AUTH_KEY = _supabase_anon
else:
    # Fallback: prefer anon key if available, else raw supabase_key
    AUTH_KEY = _supabase_anon or _supabase_key
    print("Warning: Supabase keys do not look like JWTs. If you see 'PGRST301' errors, check .env keys.")

# API key header (prefer anon key for 'apikey' header)
API_KEY = _supabase_anon or _supabase_key

# Headers for Supabase API requests
headers = {
    "apikey": API_KEY,
    "Authorization": f"Bearer {AUTH_KEY}" if AUTH_KEY else "",
    "Content-Type": "application/json",
    "Accept": "application/json"
}

supabase: Client = create_client(SUPABASE_URL, AUTH_KEY)
session = requests.Session()
session.headers.update(headers)


def supabase_query(table, method="GET", data=None, filters=None, select=None):
    """Helper function to make requests to Supabase REST API."""
    url = f"{SUPABASE_URL.rstrip('/')}/rest/v1/{table}"
    params = {}
    if filters:
        params.update(filters)
    if select:
        params["select"] = select

    try:
        if method == "GET":
            response = session.get(url, params=params, timeout=30)
        elif method == "POST":
            response = session.post(url, json=data, timeout=30)
        elif method == "PATCH":
            response = session.patch(url, params=params, json=data, timeout=30)
        elif method == "DELETE":
            response = session.delete(url, params=params, timeout=30)
        elif method == "HEAD":
            response = session.head(url, params=params, timeout=30)
        else:
            raise ValueError(f"Unsupported method: {method}")

        return response
    except requests.exceptions.RequestException as e:
        class MockResponse:
            def __init__(self, status_code=503, text="Service Unavailable"):
                self.status_code = status_code
                self._text = text

            def json(self):
                return []

            @property
            def text(self):
                return self._text

        print(f"Supabase connection error: {e}")
        print("Please check your Supabase configuration in .env file")
        print("If you need to set up a new Supabase project, visit: https://supabase.com")
        return MockResponse(503, f"Supabase connection failed: {str(e)}")

