"""
Centralized Earth Engine initialization and session management.
Initialize once on application startup and reuse throughout the system.
"""
import json
from pathlib import Path

ee = None
_initialized = False


def initialize():
    """
    Initialize Earth Engine with service account credentials.
    Call this once on application startup.
    """
    global ee, _initialized
    
    if _initialized:
        return ee
    
    try:
        import ee as earth_engine
    except ImportError as exc:
        raise RuntimeError(
            "Earth Engine API is not installed. Install with: pip install earthengine-api"
        ) from exc
    
    service_account_path = Path(__file__).parent / "service-account.json"
    if not service_account_path.exists():
        raise RuntimeError(
            f"Earth Engine service account file missing: {service_account_path}"
        )
    
    with service_account_path.open("r", encoding="utf-8") as f:
        creds = json.load(f)
    
    client_email = creds.get("client_email")
    project_id = creds.get("project_id")
    if not client_email or not project_id:
        raise RuntimeError("Invalid Earth Engine service account credentials.")
    
    credentials = earth_engine.ServiceAccountCredentials(
        client_email, str(service_account_path)
    )
    earth_engine.Initialize(credentials, project=project_id)
    
    ee = earth_engine
    _initialized = True
    return ee


def get():
    """Get the initialized Earth Engine session. Returns None if not initialized."""
    return ee


def is_initialized():
    """Check if Earth Engine has been initialized."""
    return _initialized
