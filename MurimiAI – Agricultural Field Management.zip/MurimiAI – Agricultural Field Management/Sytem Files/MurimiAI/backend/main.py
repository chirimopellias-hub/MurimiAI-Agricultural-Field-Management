from fastapi import FastAPI
import os
import logging
from dotenv import load_dotenv
import sys
from pathlib import Path

# Add backend directory to path for absolute imports
sys.path.insert(0, str(Path(__file__).parent))

from routes.routes import router as routes
from pages.Disease.DiseaseDetection import load_models
import earth_engine_session

# Setup logging
logger = logging.getLogger(__name__)

# Load environment variables from .env file
load_dotenv()

app = FastAPI()

# Add CORS middleware
from fastapi.middleware.cors import CORSMiddleware
frontend_origins = [
    "http://localhost:5173",
    "http://localhost:3000",
]
if os.getenv("FRONTEND_URL"):
    frontend_origins.append(os.getenv("FRONTEND_URL"))

app.add_middleware(
    CORSMiddleware,
    allow_origins=frontend_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def startup_event():
    """Initialize Earth Engine and load models on application startup."""
    try:
        earth_engine_session.initialize()
        logger.info("✓ Earth Engine initialized successfully")
    except Exception as e:
        logger.warning(f"Earth Engine initialization deferred: {e}")
    
    # Uncomment if needed
    # try:
    #     load_models()
    #     logger.info("✓ Disease detection models loaded")
    # except Exception as e:
    #     logger.warning(f"Model loading deferred: {e}")


# Include the router from routes.py
app.include_router(routes)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
