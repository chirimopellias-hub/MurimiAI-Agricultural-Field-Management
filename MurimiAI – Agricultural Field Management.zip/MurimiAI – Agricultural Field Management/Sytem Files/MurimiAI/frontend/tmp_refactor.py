from pathlib import Path

frontend = Path('.')

# Remove the old left-column block from SmartAdvisory.tsx
smart = frontend / 'src/pages/SmartAdvisory/SmartAdvisory.tsx'
text = smart.read_text(encoding='utf-8')
start = text.find('        {/* Left Column - Main Content */}')
end = text.find('        {/* Right Column - MurimiAI Assistant */}')
if start != -1 and end != -1 and end > start:
    text = text[:start] + '        {/* Left Column moved to MurimiAnalytics.tsx */}\n' + text[end:]
    smart.write_text(text, encoding='utf-8')

# Insert the moved left-column component into MurimiAnalytics.tsx
analytics = frontend / 'src/pages/MurimiAI_Analytics/MurimiAnalytics.tsx'
text = analytics.read_text(encoding='utf-8')
if '  MapPin,' not in text:
    text = text.replace('  Map,\n', '  Map,\n  MapPin,\n')
needle = '          {/* Farm Summary */}\n          <FarmSummary farmId={selectedFarm} fieldId={selectedField} />\n\n          {/* Map Section */}'
replacement = '          {/* Farm Summary */}\n          <FarmSummary farmId={selectedFarm} fieldId={selectedField} />\n\n          {/* Left Column moved from SmartAdvisory */}\n          <LeftMainContent\n            selectedFarm={selectedFarm}\n            selectedField={selectedField}\n            onSelectField={setSelectedField}\n          />\n\n          {/* Map Section */}'
if needle in text:
    text = text.replace(needle, replacement)
analytics.write_text(text, encoding='utf-8')
