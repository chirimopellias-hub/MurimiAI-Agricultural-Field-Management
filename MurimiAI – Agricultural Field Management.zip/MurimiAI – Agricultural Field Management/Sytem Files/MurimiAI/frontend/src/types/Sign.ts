
export interface User {
  id?: number;
  name: string;
  phone: string;
  email: string;
  password: string;
  language: string;
}

export interface Farm {
  name: string;
  hecters: number;
  district: string;
  province: string;
  main_crop: string;
  type: string;
}
export interface SignUpData extends User {
  farm: Farm;
}

export interface SignInData {
  identifier: string;
  password: string;
}