// Types
export interface FarmBoundary {
  id: string;
  name: string;
  coordinates: [number, number][];
  area: number;
  cropType?: string;
  plantingDate?: string;
  variety?: string;
  irrigationType?: string;
  farmingType?: string;
}

export interface IndexData {
  ndvi: number;
  ndmi: number;
  mndwi: number;
  ndwi: number;
  date: string;
  farmId: string;
  min?: number;
  max?: number;
  mean?: number;
  std?: number;
}

export interface FarmWithIndices extends FarmBoundary {
  latestIndices?: IndexData;
  indicesHistory?: IndexData[];
}

export interface UserLocation {
  lat: number;
  lng: number;
  accuracy: number;
  timestamp: number;
}

export interface AddFieldProps {
  initialFarms?: FarmWithIndices[];
  onBoundaryChange?: (farm: FarmBoundary) => void;
  onIndicesUpdate?: (farmId: string, indices: IndexData) => void;
  showControls?: boolean;
  editable?: boolean;
  centerOnUser?: boolean;
  sentinelHubInstanceId?: string;
}