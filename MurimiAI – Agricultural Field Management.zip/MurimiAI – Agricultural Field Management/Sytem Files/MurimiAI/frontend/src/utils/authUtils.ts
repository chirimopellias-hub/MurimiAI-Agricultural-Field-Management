/**
 * Authentication utilities for managing user tokens and authentication state
 */

const TOKEN_KEY = 'token';
const USER_ID_KEY = 'user_id';
const EMAIL_KEY = 'email';
const USER_NAME_KEY = 'name';
const FARM_ID_KEY = 'farm_id';
const FARM_NAME_KEY = 'farm_name';

export interface CurrentUser {
  user_id?: string;
  name?: string;
  email?: string;
  phone?: string;
  language?: string;
  farm_id?: string;
  farm_name?: string;
}

export const authUtils = {
  /**
   * Get stored JWT token
   */
  getToken: (): string | null => {
    return localStorage.getItem(TOKEN_KEY);
  },

  /**
   * Get stored user ID
   */
  getUserId: (): string | null => {
    return localStorage.getItem(USER_ID_KEY);
  },

  /**
   * Get stored email
   */
  getEmail: (): string | null => {
    return localStorage.getItem(EMAIL_KEY);
  },

  getName: (): string | null => {
    return localStorage.getItem(USER_NAME_KEY);
  },

  getFarmId: (): string | null => {
    return localStorage.getItem(FARM_ID_KEY);
  },

  getFarmName: (): string | null => {
    return localStorage.getItem(FARM_NAME_KEY);
  },

  /**
   * Check if user is authenticated
   */
  isAuthenticated: (): boolean => {
    return !!localStorage.getItem(TOKEN_KEY);
  },

  /**
   * Save authentication data
   */
  setAuthData: (token: string, userId: string, email: string, name: string = '', farmId: string = '', farmName: string = ''): void => {
    localStorage.setItem(TOKEN_KEY, token);
    localStorage.setItem(USER_ID_KEY, userId);
    localStorage.setItem(EMAIL_KEY, email);
    localStorage.setItem(USER_NAME_KEY, name);
    localStorage.setItem(FARM_ID_KEY, farmId);
    localStorage.setItem(FARM_NAME_KEY, farmName);
  },

  /**
   * Clear all authentication data
   */
  clearAuth: (): void => {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_ID_KEY);
    localStorage.removeItem(EMAIL_KEY);
    localStorage.removeItem(USER_NAME_KEY);
    localStorage.removeItem(FARM_ID_KEY);
    localStorage.removeItem(FARM_NAME_KEY);
  },

  /**
   * Make authenticated API request with token
   */
  authenticatedFetch: async (
    url: string,
    options: RequestInit = {}
  ): Promise<Response> => {
    const token = authUtils.getToken();

    const headers = new Headers(options.headers);
    headers.set('Content-Type', 'application/json');

    if (token) {
      headers.set('Authorization', `Bearer ${token}`);
    }

    return fetch(url, {
      ...options,
      headers,
    });
  },

  /**
   * Get current user data from backend
   */
  getCurrentUser: async (apiBaseUrl: string): Promise<CurrentUser | null> => {
    try {
      const response = await authUtils.authenticatedFetch(
        `${apiBaseUrl}/api/auth/user`
      );

      if (!response.ok) {
        if (response.status === 401) {
          // Token expired, clear auth
          authUtils.clearAuth();
          return null;
        }
        throw new Error('Failed to fetch user data');
      }

      return await response.json() as CurrentUser;
    } catch (error) {
      console.error('Error fetching current user:', error);
      return null;
    }
  },

};

export default authUtils;
