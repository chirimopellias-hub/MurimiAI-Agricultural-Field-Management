// Farm.tsx
import React, { useState, useEffect, useCallback } from "react";
import * as LucideIcons from "lucide-react";
import authUtils from "../../utils/authUtils";
import "./Farm.css";

// Types
interface FarmData {
  farmId: string;
  farmName: string;
  farmSize: number;
  district: string;
  province: string;
  farmingType: string;
}

interface FieldData {
  fieldId: string;
  fieldName: string;
  size: number;
  cropType: string;
  plantingDate: string;
  expectedHarvestDate: string;
  irrigationType: string;
  growthStage: string;
  soilData: SoilData;
}

interface SoilData {
  texture: string;
  ph: number;
  nitrogen: number;
  phosphorus: number;
  potassium: number;
  organicMatter: number;
  moisture: number;
  cec: number;
}

// Default soil data
const defaultSoilData: SoilData = {
  texture: "None",
  ph: 0,
  nitrogen: 0,
  phosphorus: 0,
  potassium: 0,
  organicMatter: 0,
  moisture: 0,
  cec: 0,
};

const irrigationOptions = [
  "Drip Irrigation",
  "Sprinkler System",
  "Flood Irrigation",
  "Center Pivot",
  "Manual Watering",
  "Rain-fed",
];

const soilTypeOptions = [
  "Clay",
  "Loam",
  "Sandy",
  "Silty",
  "Clay Loam",
  "Sandy Loam",
  "Red-brown Clay",
  "Basaltic Clay",
  "Alluvial",
];

const growthStageOptions = ["Initial", "Development", "Mid", "Late", "Harvest"];

const Farm: React.FC = () => {
  // Initialize state empty — load from backend on mount
  const [farmData, setFarmData] = useState<FarmData | null>(null);
  const [fields, setFields] = useState<FieldData[]>([]);
  const [selectedField, setSelectedField] = useState<FieldData | null>(null);
  const [updatingFarm, setUpdatingFarm] = useState<boolean>(false);
  const [showFarmEditForm, setShowFarmEditForm] = useState<boolean>(false);
  const [editingField, setEditingField] = useState<FieldData | null>(null);
  const [showFieldForm, setShowFieldForm] = useState<boolean>(false);
  const [loadingFarm, setLoadingFarm] = useState<boolean>(false);
  const [loadingFields, setLoadingFields] = useState<boolean>(false);
  const [updatingField, setUpdatingField] = useState<boolean>(false);
  const [deletingField, setDeletingField] = useState<boolean>(false);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [notification, setNotification] = useState<{
    type: "success" | "error";
    message: string;
  } | null>(null);

  // Form states for farm update
  const [editFarmForm, setEditFarmForm] = useState<Partial<FarmData>>({});

  // Form states for field add/edit
  const [fieldForm, setFieldForm] = useState<Partial<FieldData>>({
    soilData: { ...defaultSoilData },
  });

  const showNotification = (type: "success" | "error", message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 3000);
  };

  // Reusable helper function to update soil data with proper typing
  const updateSoilData = <K extends keyof SoilData>(
    field: K,
    value: SoilData[K],
  ) => {
    if (editingField) {
      setEditingField({
        ...editingField,
        soilData: {
          ...(editingField.soilData || defaultSoilData),
          [field]: value,
        },
      });
    } else {
      const currentSoilData = fieldForm.soilData || defaultSoilData;
      setFieldForm({
        ...fieldForm,
        soilData: { ...currentSoilData, [field]: value },
      });
    }
  };

  // Reusable helper function to update field form data with proper typing
  const updateFieldForm = <K extends keyof FieldData>(
    fieldName: K,
    value: FieldData[K],
  ) => {
    if (editingField) {
      setEditingField((prev) =>
        prev ? ({ ...prev, [fieldName]: value } as FieldData) : prev,
      );
    } else {
      setFieldForm(
        (prev) =>
          ({ ...(prev || {}), [fieldName]: value }) as Partial<FieldData>,
      );
    }
  };

  const API_BASE_URL =
    import.meta.env.VITE_API_BASE_URL || "http://localhost:8000";

  const loadFarm = useCallback(async () => {
    try {
      setLoadingFarm(true);
      const res = await authUtils.authenticatedFetch(
        `${API_BASE_URL}/api/farm`,
      );
      if (!res.ok) {
        console.error("Failed to load farm", res.status, await res.text());
        setLoadingFarm(false);
        return;
      }
      const data = await res.json();
      setFarmData({
        farmId: data.farmId,
        farmName: data.farmName,
        farmSize: data.farmSize,
        district: data.district,
        province: data.province,
        farmingType: data.farmingType,
      });
      setEditFarmForm({
        farmName: data.farmName,
        farmSize: data.farmSize,
        district: data.district,
        province: data.province,
        farmingType: data.farmingType,
      });
      setLoadingFarm(false);
    } catch (e) {
      console.error(e);
      setLoadingFarm(false);
    }
  }, [API_BASE_URL]);

  const loadFields = useCallback(async () => {
    try {
      setLoadingFields(true);
      const res = await authUtils.authenticatedFetch(
        `${API_BASE_URL}/api/farm/fields`,
      );
      if (!res.ok) {
        console.error("Failed to load fields", res.status, await res.text());
        setLoadingFields(false);
        return;
      }
      const data = await res.json();
      setFields(data || []);
      setSelectedField((prev) => {
        if (data && data.length) return data[0];
        return prev;
      });
      setLoadingFields(false);
    } catch (e) {
      console.error(e);
      setLoadingFields(false);
    }
  }, [API_BASE_URL]);

  useEffect(() => {
    loadFarm();
    loadFields();
  }, [loadFarm, loadFields]);

  const handleUpdateFarm = async () => {
    setUpdatingFarm(true);
    try {
      const res = await authUtils.authenticatedFetch(
        `${API_BASE_URL}/api/farm`,
        {
          method: "PATCH",
          body: JSON.stringify({
            farmName: editFarmForm.farmName,
            farmSize: editFarmForm.farmSize,
            district: editFarmForm.district,
            province: editFarmForm.province,
            farmingType: editFarmForm.farmingType,
          }),
        },
      );
      if (!res.ok) throw new Error("Failed to update farm");
      await loadFarm();
      setShowFarmEditForm(false);
      showNotification("success", "Farm updated successfully");
    } catch (e) {
      console.error(e);
      showNotification("error", "Failed to update farm");
    } finally {
      setUpdatingFarm(false);
    }
  };

  // Adding fields is disabled in this view; only editing existing fields is supported.

  const handleUpdateField = async () => {
    if (!editingField) return;
    setUpdatingField(true);
    try {
      const payload = {
        fieldName: editingField.fieldName,
        size: editingField.size,
        cropType: editingField.cropType,
        plantingDate: editingField.plantingDate,
        irrigationType: editingField.irrigationType,
        growthStage: editingField.growthStage,
        soilData: editingField.soilData,
      };
      console.debug("Updating field payload:", payload);
      const res = await authUtils.authenticatedFetch(
        `${API_BASE_URL}/api/farm/fields/${editingField.fieldId}`,
        {
          method: "PATCH",
          body: JSON.stringify(payload),
        },
      );
      if (!res.ok) {
        const text = await res.text().catch(() => "(no body)");
        console.error("Update field failed:", res.status, text);
        showNotification("error", `Failed to update field: ${res.status}`);
        setUpdatingField(false);
        return;
      }
      await loadFields();
      setEditingField(null);
      setShowFieldForm(false);
      showNotification("success", "Field updated successfully");
    } catch (e) {
      console.error(e);
      showNotification("error", "Failed to update field");
    } finally {
      setUpdatingField(false);
    }
  };

  const handleDeleteField = async (fieldId: string) => {
    setDeletingField(true);
    try {
      if (!fieldId) return;
      const res = await authUtils.authenticatedFetch(
        `${API_BASE_URL}/api/farm/fields/${fieldId}`,
        {
          method: "DELETE",
        },
      );
      if (!res.ok) throw new Error("Failed to delete field");
      await loadFields();
      setDeleteConfirm(null);
      setSelectedField(null);
      showNotification("success", "Field deleted successfully");
    } catch (e) {
      console.error(e);
      showNotification("error", "Failed to delete field");
    } finally {
      setDeletingField(false);
    }
  };

  const getSoilValueClass = (
    value: number,
    thresholds: { low: number; high: number },
  ) => {
    if (value < thresholds.low) return "farm-soil-low";
    if (value > thresholds.high) return "farm-soil-high";
    return "farm-soil-optimal";
  };

  const getSoilStatusMessage = (
    value: number,
    thresholds: { low: number; high: number },
    name: string,
  ) => {
    if (value < thresholds.low)
      return `Low ${name} - Consider adding amendments`;
    if (value > thresholds.high) return `High ${name} - Reduce application`;
    return `Optimal ${name} levels`;
  };

  return (
    <div className="farm-page">
      {(loadingFarm || loadingFields || updatingField || deletingField) && (
        <div className="smart-advisory-overlay">
          <div className="smart-advisory-loading-card">
            <p className="smart-advisory-loading-title">
              {loadingFarm
                ? "Loading farm details…"
                : loadingFields
                  ? "Loading field data…"
                  : updatingField
                    ? "Updating field…"
                    : deletingField
                      ? "Deleting field…"
                      : "Processing…"}
            </p>
            <div className="typing-wrapper smart-advisory-loading-typing">
              <div className="typing-indicator">
                <div className="typing-dot"></div>
                <div className="typing-dot delay-200"></div>
                <div className="typing-dot delay-400"></div>
              </div>
            </div>
          </div>
        </div>
      )}
      {notification && (
        <div
          className={`farm-notification farm-notification-${notification.type}`}
        >
          <span>{notification.message}</span>
          <button onClick={() => setNotification(null)}>×</button>
        </div>
      )}

      {/* Farm Section - Top */}
      <section className="farm-section">
        <div className="farm-section-header">
          <h2 className="farm-section-title">
            <LucideIcons.File size={22} strokeWidth={2} />
            Farm Information
          </h2>
          {!showFarmEditForm && (
            <button
              onClick={() => setShowFarmEditForm(true)}
              className="farm-update-btn"
            >
              <LucideIcons.Edit2 size={16} />
              Update Farm Details
            </button>
          )}
        </div>

        {showFarmEditForm ? (
          <div className="farm-edit-form">
            <div className="farm-form-grid">
              <div className="farm-form-group">
                <label>Farm Name</label>
                <input
                  type="text"
                  value={editFarmForm.farmName || ""}
                  onChange={(e) =>
                    setEditFarmForm({
                      ...editFarmForm,
                      farmName: e.target.value,
                    })
                  }
                />
              </div>
              <div className="farm-form-group">
                <label>Farm Size (hectares)</label>
                <input
                  type="number"
                  value={editFarmForm.farmSize || 0}
                  onChange={(e) =>
                    setEditFarmForm({
                      ...editFarmForm,
                      farmSize: parseFloat(e.target.value),
                    })
                  }
                />
              </div>
              <div className="farm-form-group">
                <label>District</label>
                <input
                  type="text"
                  value={editFarmForm.district || ""}
                  onChange={(e) =>
                    setEditFarmForm({
                      ...editFarmForm,
                      district: e.target.value,
                    })
                  }
                />
              </div>
              <div className="farm-form-group">
                <label>Province</label>
                <input
                  type="text"
                  value={editFarmForm.province || ""}
                  onChange={(e) =>
                    setEditFarmForm({
                      ...editFarmForm,
                      province: e.target.value,
                    })
                  }
                />
              </div>
              <div className="farm-form-group">
                <label>Farming Type</label>
                <input
                  type="text"
                  value={editFarmForm.farmingType || ""}
                  onChange={(e) =>
                    setEditFarmForm({
                      ...editFarmForm,
                      farmingType: e.target.value,
                    })
                  }
                />
              </div>
            </div>
            <div className="farm-form-actions">
              <button
                onClick={() => setShowFarmEditForm(false)}
                className="farm-btn-cancel"
              >
                Cancel
              </button>
              <button
                onClick={handleUpdateFarm}
                disabled={updatingFarm}
                className="farm-btn-save"
              >
                {updatingFarm ? "Saving..." : "Save Changes"}
              </button>
            </div>
          </div>
        ) : (
          <div className="farm-info-grid">
            <div className="farm-info-card">
              <span className="farm-info-label">Farm Name</span>
              <span className="farm-info-value">{farmData?.farmName}</span>
            </div>
            <div className="farm-info-card">
              <span className="farm-info-label">Farm Size</span>
              <span className="farm-info-value">
                {farmData?.farmSize} hectares
              </span>
            </div>
            <div className="farm-info-card">
              <span className="farm-info-label">District</span>
              <span className="farm-info-value">{farmData?.district}</span>
            </div>
            <div className="farm-info-card">
              <span className="farm-info-label">Province</span>
              <span className="farm-info-value">{farmData?.province}</span>
            </div>
            <div className="farm-info-card">
              <span className="farm-info-label">Farming Type</span>
              <span className="farm-info-value">{farmData?.farmingType}</span>
            </div>
          </div>
        )}
      </section>

      {/* Fields Section - Bottom, takes more space */}
      <section className="farm-fields-section">
        <div className="farm-fields-header">
          <h2 className="farm-section-title">
            <LucideIcons.MapPin size={22} strokeWidth={2} />
            Fields Management
          </h2>
          {/* Add Field disabled - editing only */}
          <div className="farm-header-stats">
            <span className="farm-stat-badge">
              <LucideIcons.Files size={14} />
              {fields.length} Fields
            </span>
          </div>
        </div>

        <div className="farm-fields-container">
          {/* Left side - Fields List */}
          <div className="farm-fields-list">
            {fields.length === 0 ? (
              <div className="farm-empty-state">
                <LucideIcons.Files size={48} strokeWidth={1.5} />
                <p>No fields added yet. Add Your First Field</p>
              </div>
            ) : (
              fields.map((field) => (
                <div
                  key={field.fieldId}
                  className={`farm-field-card ${selectedField?.fieldId === field.fieldId ? "farm-field-card-selected" : ""}`}
                  onClick={() => setSelectedField(field)}
                >
                  <div className="farm-field-card-header">
                    <div className="farm-field-name">
                      <LucideIcons.Trees size={18} />
                      <span>{field.fieldName}</span>
                    </div>
                  </div>
                  <div className="farm-field-actions">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setEditingField(field);
                      }}
                      className="farm-field-edit"
                      title="Edit Field"
                    >
                      <LucideIcons.Edit2 size={14} />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setDeleteConfirm(field.fieldId);
                      }}
                      className="farm-field-delete"
                      title="Delete Field"
                    >
                      <LucideIcons.Trash2 size={14} />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Right side - Selected Field Details */}
          <div className="farm-field-detail">
            {selectedField ? (
              <>
                {/* Top part - Field Data */}
                <div className="farm-field-data-section">
                  <div className="farm-detail-header">
                    <h3 className="farm-detail-title">
                      <LucideIcons.Info size={18} />
                      Field Details
                    </h3>
                  </div>
                  <div className="farm-field-info-grid">
                    <div>
                      <label>Field Name</label>
                      <span>{selectedField.fieldName}</span>
                    </div>
                    <div>
                      <label>Field ID</label>
                      <span>{selectedField.fieldId}</span>
                    </div>
                    <div>
                      <label>Size</label>
                      <span>{selectedField.size} hectares</span>
                    </div>
                    <div>
                      <label>Crop Type</label>
                      <span>{selectedField.cropType}</span>
                    </div>
                    <div>
                      <label>Planting Date</label>
                      <span>
                        {new Date(
                          selectedField.plantingDate,
                        ).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Bottom part - Soil Data */}
                <div className="farm-soil-data-section">
                  <h3 className="farm-detail-title">
                    <LucideIcons.Gauge size={18} />
                    Soil Health Analysis
                  </h3>
                  <div className="farm-soil-grid">
                    <div className="farm-soil-param">
                      <span className="farm-soil-param-label">pH Level</span>
                      <span
                        className={`farm-soil-param-value ${getSoilValueClass(selectedField.soilData.ph, { low: 5.5, high: 7.5 })}`}
                      >
                        {selectedField.soilData.ph}
                      </span>
                      <span className="farm-soil-status-msg">
                        {getSoilStatusMessage(
                          selectedField.soilData.ph,
                          { low: 5.5, high: 7.5 },
                          "pH",
                        )}
                      </span>
                    </div>
                    <div className="farm-soil-param">
                      <span className="farm-soil-param-label">
                        Nitrogen (N)
                      </span>
                      <span
                        className={`farm-soil-param-value ${getSoilValueClass(
                          selectedField.soilData.nitrogen,
                          { low: 40, high: 70 },
                        )}`}
                      >
                        {selectedField.soilData.nitrogen} mg/kg
                      </span>
                      <span className="farm-soil-status-msg">
                        {getSoilStatusMessage(
                          selectedField.soilData.nitrogen,
                          { low: 40, high: 70 },
                          "Nitrogen",
                        )}
                      </span>
                    </div>
                    <div className="farm-soil-param">
                      <span className="farm-soil-param-label">
                        Phosphorus (P)
                      </span>
                      <span
                        className={`farm-soil-param-value ${getSoilValueClass(selectedField.soilData.phosphorus, { low: 30, high: 60 })}`}
                      >
                        {selectedField.soilData.phosphorus} mg/kg
                      </span>
                      <span className="farm-soil-status-msg">
                        {getSoilStatusMessage(
                          selectedField.soilData.phosphorus,
                          { low: 30, high: 60 },
                          "Phosphorus",
                        )}
                      </span>
                    </div>
                    <div className="farm-soil-param">
                      <span className="farm-soil-param-label">
                        Potassium (K)
                      </span>
                      <span
                        className={`farm-soil-param-value ${getSoilValueClass(selectedField.soilData.potassium, { low: 40, high: 80 })}`}
                      >
                        {selectedField.soilData.potassium} mg/kg
                      </span>
                      <span className="farm-soil-status-msg">
                        {getSoilStatusMessage(
                          selectedField.soilData.potassium,
                          { low: 40, high: 80 },
                          "Potassium",
                        )}
                      </span>
                    </div>
                    <div className="farm-soil-param">
                      <span className="farm-soil-param-label">
                        Organic Matter
                      </span>
                      <span
                        className={`farm-soil-param-value ${getSoilValueClass(selectedField.soilData.organicMatter, { low: 2, high: 5 })}`}
                      >
                        {selectedField.soilData.organicMatter}%
                      </span>
                      <span className="farm-soil-status-msg">
                        {getSoilStatusMessage(
                          selectedField.soilData.organicMatter,
                          { low: 2, high: 5 },
                          "Organic Matter",
                        )}
                      </span>
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <div className="farm-no-selection">
                <LucideIcons.MapPin size={48} strokeWidth={1.5} />
                <p>Select a field to view details</p>
              </div>
            )}
          </div>
        </div>
      </section>

      {/*Edit Field Modal */}
      {(showFieldForm || editingField) && (
        <div
          className="farm-modal-overlay"
          onClick={() => {
            setShowFieldForm(false);
            setEditingField(null);
          }}
        >
          <div className="farm-modal" onClick={(e) => e.stopPropagation()}>
            <div className="farm-modal-header">
              <h3>{editingField ? "Edit Field" : "Add Field"}</h3>
              <button
                onClick={() => {
                  setShowFieldForm(false);
                  setEditingField(null);
                  setFieldForm({ soilData: { ...defaultSoilData } });
                }}
              >
                ×
              </button>
            </div>
            <div className="farm-modal-body">
              <h4 className="farm-soil-subtitle">Field Data</h4>
              <div className="farm-form-grid">
                <div className="farm-form-group">
                  <label>Field Name</label>
                  <input
                    type="text"
                    placeholder="e.g., North Field, Vegetable Garden"
                    value={
                      editingField
                        ? editingField.fieldName
                        : fieldForm.fieldName || ""
                    }
                    onChange={(e) =>
                      updateFieldForm("fieldName", e.target.value)
                    }
                  />
                </div>
                <div className="farm-form-group">
                  <label>Size (hectares)</label>
                  <input
                    type="number"
                    placeholder="Field size in hectares"
                    value={
                      editingField ? editingField.size : fieldForm.size || ""
                    }
                    onChange={(e) =>
                      updateFieldForm("size", parseFloat(e.target.value))
                    }
                  />
                </div>
                <div className="farm-form-group">
                  <label>Crop Type</label>
                  <input
                    type="text"
                    placeholder="e.g., Maize, Beans, Tomatoes"
                    value={
                      editingField
                        ? editingField.cropType
                        : fieldForm.cropType || ""
                    }
                    onChange={(e) =>
                      updateFieldForm("cropType", e.target.value)
                    }
                  />
                </div>
                <div className="farm-form-group">
                  <label>Variety</label>
                  <input
                    type="text"
                    placeholder="e.g., Maize, Beans, Tomatoes"
                    value={
                      editingField
                        ? editingField.cropType
                        : fieldForm.cropType || ""
                    }
                    onChange={(e) =>
                      updateFieldForm("cropType", e.target.value)
                    }
                  />
                </div>
                <div className="farm-form-group">
                  <label>Planting Date</label>
                  <input
                    type="date"
                    value={
                      editingField
                        ? editingField.plantingDate
                        : fieldForm.plantingDate || ""
                    }
                    onChange={(e) =>
                      updateFieldForm("plantingDate", e.target.value)
                    }
                  />
                </div>
                <div className="farm-form-group">
                  <label>Type of Irrigation</label>
                  <select
                    value={
                      editingField
                        ? editingField.irrigationType || "None"
                        : fieldForm.irrigationType || "None"
                    }
                    onChange={(e) =>
                      updateFieldForm("irrigationType", e.target.value)
                    }
                  >
                    <option value="">Select Irrigation type</option>
                    {irrigationOptions.map((option) => (
                      <option key={option} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="farm-form-group">
                  <label>Growth Stage</label>
                  <select
                    value={
                      editingField
                        ? editingField.growthStage || "active"
                        : fieldForm.growthStage || "active"
                    }
                    onChange={(e) =>
                      updateFieldForm("growthStage", e.target.value)
                    }
                  >
                    <option value="">Select growth Level</option>
                    {growthStageOptions.map((option) => (
                      <option key={option} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <h4 className="farm-soil-subtitle">Soil Analysis Data</h4>
              <div className="farm-form-grid">
                <div className="farm-form-group">
                  <label>Texture</label>
                  <select
                    value={
                      editingField
                        ? editingField.soilData?.texture || ""
                        : fieldForm.soilData?.texture || ""
                    }
                    onChange={(e) => updateSoilData("texture", e.target.value)}
                  >
                    <option value="">Select soil texture</option>
                    {soilTypeOptions.map((option) => (
                      <option key={option} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="farm-form-group">
                  <label>pH Level</label>
                  <input
                    type="number"
                    step="0.1"
                    value={
                      editingField
                        ? editingField.soilData.ph
                        : fieldForm.soilData?.ph || 7
                    }
                    onChange={(e) =>
                      updateSoilData("ph", parseFloat(e.target.value))
                    }
                  />
                </div>
                <div className="farm-form-group">
                  <label>Nitrogen (N)</label>
                  <input
                    type="number"
                    value={
                      editingField
                        ? editingField.soilData.nitrogen
                        : fieldForm.soilData?.nitrogen || 50
                    }
                    onChange={(e) =>
                      updateSoilData("nitrogen", parseFloat(e.target.value))
                    }
                  />
                </div>
                <div className="farm-form-group">
                  <label>Phosphorus (P)</label>
                  <input
                    type="number"
                    value={
                      editingField
                        ? editingField.soilData.phosphorus
                        : fieldForm.soilData?.phosphorus || 50
                    }
                    onChange={(e) =>
                      updateSoilData("phosphorus", parseFloat(e.target.value))
                    }
                  />
                </div>
                <div className="farm-form-group">
                  <label>Potassium (K)</label>
                  <input
                    type="number"
                    value={
                      editingField
                        ? editingField.soilData.potassium
                        : fieldForm.soilData?.potassium || 50
                    }
                    onChange={(e) =>
                      updateSoilData("potassium", parseFloat(e.target.value))
                    }
                  />
                </div>
                <div className="farm-form-group">
                  <label>Organic Matter % </label>
                  <input
                    type="number"
                    step="0.1"
                    value={
                      editingField
                        ? editingField.soilData.organicMatter
                        : fieldForm.soilData?.organicMatter || 2
                    }
                    onChange={(e) =>
                      updateSoilData(
                        "organicMatter",
                        parseFloat(e.target.value),
                      )
                    }
                  />
                </div>
                <div className="farm-form-group">
                  <label>Moisture %</label>
                  <input
                    type="number"
                    value={
                      editingField
                        ? editingField.soilData.moisture
                        : fieldForm.soilData?.moisture || 20
                    }
                    onChange={(e) =>
                      updateSoilData("moisture", parseFloat(e.target.value))
                    }
                  />
                </div>
                <div className="farm-form-group">
                  <label>CEC</label>
                  <input
                    type="number"
                    step="0.1"
                    value={
                      editingField
                        ? editingField.soilData?.cec || 0
                        : fieldForm.soilData?.cec || 0
                    }
                    onChange={(e) =>
                      updateSoilData("cec", parseFloat(e.target.value))
                    }
                  />
                </div>
              </div>
            </div>
            <div className="farm-modal-footer">
              <button
                onClick={() => {
                  setShowFieldForm(false);
                  setEditingField(null);
                  setFieldForm({ soilData: { ...defaultSoilData } });
                }}
                className="farm-btn-cancel"
              >
                Cancel
              </button>
              <button
                onClick={handleUpdateField}
                className="farm-btn-save"
                disabled={!editingField}
              >
                Update Field
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirm && (
        <div
          className="farm-modal-overlay"
          onClick={() => setDeleteConfirm(null)}
        >
          <div
            className="farm-modal farm-modal-small"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="farm-modal-header">
              <h3>Confirm Delete</h3>
              <button onClick={() => setDeleteConfirm(null)}>×</button>
            </div>
            <div className="farm-modal-body">
              <p>Are you sure you want to delete this field?</p>
              <p
                style={{
                  color: "#fca5a5",
                  fontSize: "0.875rem",
                  marginTop: "0.5rem",
                }}
              >
                This action cannot be undone. All data associated with this
                field will be permanently removed.
              </p>
            </div>
            <div className="farm-modal-footer">
              <button
                onClick={() => setDeleteConfirm(null)}
                className="farm-btn-cancel"
              >
                Cancel
              </button>
              <button
                onClick={() => handleDeleteField(deleteConfirm)}
                className="farm-btn-delete"
              >
                Delete Permanently
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Farm;
