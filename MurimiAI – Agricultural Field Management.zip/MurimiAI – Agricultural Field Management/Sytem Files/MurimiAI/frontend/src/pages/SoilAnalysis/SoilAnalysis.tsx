import React, { useEffect, useState } from "react";
import * as LucideIcons from "lucide-react";
import "./SoilAnalysis.css";
import GeneralAnalysis from "./GeneralAnalysis";
import FieldSpecificAnalysis from "./FieldSpecificAnalysis";
import type {
  SoilData,
  SoilAnalysisResult,
  FertilizerRecommendation,
  IrrigationAdvice,
} from "./types.ts";
import authUtils from "../../utils/authUtils";

const ZIMBABWE_REGIONS = [
  {
    id: "region1",
    name: "Natural Region I",
    description:
      "Specialized and diversified farming in the Eastern Highlands.",
    rainfall: ">1000mm",
    crops: ["Tea", "Coffee", "Bananas", "Macadamia", "Timber"],
    soilTypes: ["Red clay loams", "Deep forest soils"],
    icon: <LucideIcons.Coffee className="w-5 h-5" />,
  },
  {
    id: "region2a",
    name: "Natural Region IIa",
    description: "Intensive farming in Mashonaland.",
    rainfall: "750-1000mm",
    crops: ["Maize", "Tobacco", "Cotton", "Soybeans"],
    soilTypes: ["Red-brown clays", "Sandy loams"],
    icon: <LucideIcons.Wheat className="w-5 h-5" />,
  },
  {
    id: "region2b",
    name: "Natural Region IIb",
    description: "Intensive farming in parts of the Midlands.",
    rainfall: "750-1000mm",
    crops: ["Maize", "Tobacco", "Sunflowers"],
    soilTypes: ["Sandy soils", "Red clays"],
    icon: <LucideIcons.Sprout className="w-5 h-5" />,
  },
  {
    id: "region3",
    name: "Natural Region III",
    description: "Semi-intensive farming in mid-altitude areas.",
    rainfall: "650-800mm",
    crops: ["Sorghum", "Millet", "Groundnuts", "Cattle"],
    soilTypes: ["Sandy soils", "Granitic sands"],
    icon: <LucideIcons.Leaf className="w-5 h-5" />,
  },
  {
    id: "region4",
    name: "Natural Region IV",
    description: "Semi-extensive farming in Lowveld areas.",
    rainfall: "450-650mm",
    crops: ["Sorghum", "Millet", "Cotton", "Drought-tolerant maize"],
    soilTypes: ["Sandy soils", "Alluvial soils"],
    icon: <LucideIcons.Sun className="w-5 h-5" />,
  },
  {
    id: "region5",
    name: "Natural Region V",
    description: "Extensive farming in the Zambezi Valley and lowveld.",
    rainfall: "<450mm",
    crops: ["Sorghum", "Millets", "Wild fruits", "Game ranching"],
    soilTypes: ["Sandy soils", "Basaltic clays"],
    icon: <LucideIcons.Wind className="w-5 h-5" />,
  },
];

const MOCK_SOIL_DATA: Record<string, SoilData> = {
  region1: {
    ph: 5.8,
    nitrogen: 48,
    phosphorus: 25,
    potassium: 190,
    organicMatter: 4.2,
    texture: "Clay Loam",
    moisture: 72,
    cationExchangeCapacity: 18.5,
  },
  region2a: {
    ph: 6.4,
    nitrogen: 42,
    phosphorus: 22,
    potassium: 165,
    organicMatter: 3.2,
    texture: "Red-brown Clay",
    moisture: 58,
    cationExchangeCapacity: 16.2,
  },
  region2b: {
    ph: 6.2,
    nitrogen: 38,
    phosphorus: 20,
    potassium: 155,
    organicMatter: 2.8,
    texture: "Sandy Loam",
    moisture: 52,
    cationExchangeCapacity: 12.8,
  },
  region3: {
    ph: 6.5,
    nitrogen: 32,
    phosphorus: 18,
    potassium: 140,
    organicMatter: 2.1,
    texture: "Sandy",
    moisture: 42,
    cationExchangeCapacity: 9.5,
  },
  region4: {
    ph: 7.0,
    nitrogen: 25,
    phosphorus: 15,
    potassium: 120,
    organicMatter: 1.5,
    texture: "Sandy",
    moisture: 28,
    cationExchangeCapacity: 6.8,
  },
  region5: {
    ph: 7.5,
    nitrogen: 18,
    phosphorus: 12,
    potassium: 95,
    organicMatter: 0.9,
    texture: "Sandy",
    moisture: 15,
    cationExchangeCapacity: 5.2,
  },
};

const API_BASE_URL =
  import.meta.env.VITE_API_BASE_URL || "http://localhost:8000";

const createInitialSoilForm = (): SoilData => ({
  ph: null,
  nitrogen: null,
  phosphorus: null,
  potassium: null,
  organicMatter: null,
  texture: "",
  moisture: null,
  cationExchangeCapacity: null,
});

const SoilAnalysisZimbabwe: React.FC = () => {
  const [selectedRegion, setSelectedRegion] = useState<string>("region2a");
  const [fieldRegion, setFieldRegion] = useState<string>("");
  const [activeTab, setActiveTab] = useState<"general" | "field">("general");
  const [inputForm, setInputForm] = useState<SoilData>(createInitialSoilForm());
  const [fieldOptions, setFieldOptions] = useState<
    Array<{
      id: string;
      name: string;
      crop_name?: string | null;
      soil_type?: string | null;
      growth_stage?: string | null;
    }>
  >([]);
  const [loadingFields, setLoadingFields] = useState<boolean>(true);
  const [fieldsError, setFieldsError] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] =
    useState<SoilAnalysisResult | null>(null);
  const [analyzing, setAnalyzing] = useState<boolean>(false);


  useEffect(() => {
    const loadFields = async () => {
      if (!authUtils.getToken()) {
        setFieldsError("Sign in to load your farm fields.");
        setLoadingFields(false);
        return;
      }

      setLoadingFields(true);
      setFieldsError(null);

      try {

        const response = await authUtils.authenticatedFetch(
          `${API_BASE_URL}/api/soil-analysis/fields`,
        );

        if (!response.ok) {
          throw new Error(`Field lookup failed (${response.status})`);
        }

        const fields = await response.json();
        setFieldOptions(Array.isArray(fields) ? fields : []);
      } catch (error) {
        console.error("Failed to load field options:", error);
        setFieldsError("Unable to load your farm fields right now.");
        setFieldOptions([]);
      } finally {
        setLoadingFields(false);
      }
    };

    loadFields();
  }, []);

  const getFertilizerRecommendations = (
    data: SoilData,
  ): FertilizerRecommendation => {
    const baseType = "Compound D (7-14-7)";
    let baseAmount = "250 kg/ha";
    const topType = "Ammonium Nitrate (34.5% N)";
    let topAmount = "200 kg/ha";
    let organicOptions = ["Composted manure", "Cattle manure", "Green manure"];
    const texture = data.texture || "";
    const nitrogen = Number(data.nitrogen ?? 0);

    if (texture.includes("Sandy")) {
      baseAmount = "300 kg/ha (split application)";
      organicOptions = ["Composted kraal manure", "Leaf litter compost"];
    } else if (texture.includes("Clay")) {
      baseAmount = "200 kg/ha";
    }

    if (nitrogen < 25) {
      topAmount = "250 kg/ha (split into two applications)";
    }

    return {
      baseDressing: {
        type: baseType,
        amount: baseAmount,
        timing: "At planting (October-November)",
      },
      topDressing: {
        type: topType,
        amount: topAmount,
        timing: "4-6 weeks after emergence",
      },
      organicOptions,
    };
  };

  const getIrrigationAdvice = (
    data: SoilData,
    regionId: string,
  ): IrrigationAdvice => {
    const region = ZIMBABWE_REGIONS.find((r) => r.id === regionId);
    const moisture = Number(data.moisture ?? 0);
    let frequency = "Every 5-7 days";
    let amount = "25mm per session";
    let bestTime = "Early morning (6-10am)";
    let method = "Drip irrigation preferred";

    if (region?.id === "region4" || region?.id === "region5") {
      frequency = "Every 3-4 days";
      amount = "20mm per session (lighter, more frequent)";
      bestTime = "Early morning (4-8am)";
      method = "Drip or furrow irrigation";
    } else if (region?.id === "region1") {
      frequency = "As needed with rainfall monitoring";
      amount = "Supplementary only";
      bestTime = "Morning";
      method = "Supplemental irrigation only";
    }

    if (moisture < 25) {
      frequency = "Every 2-3 days until moisture improves";
    }

    return { frequency, amount, bestTime, method };
  };

  const analyzeSoilData = (
    data: SoilData,
    regionId: string = selectedRegion,
  ): SoilAnalysisResult => {
    const analysis: string[] = [];
    const recommendations: string[] = [];
    const suitableCrops: string[] = [];
    const region = ZIMBABWE_REGIONS.find((r) => r.id === regionId);
    const ph = Number(data.ph ?? 0);
    const nitrogen = Number(data.nitrogen ?? 0);
    const phosphorus = Number(data.phosphorus ?? 0);
    const potassium = Number(data.potassium ?? 0);
    const organicMatter = Number(data.organicMatter ?? 0);
    const texture = data.texture || "";

    if (ph < 5.5) {
      analysis.push("Soil is highly acidic and needs lime treatment.");
      recommendations.push(
        "Apply agricultural lime 2-3 tons/ha before planting.",
      );
      recommendations.push("Use acid-tolerant varieties for sensitive crops.");
      suitableCrops.push("Tea", "Coffee", "Macadamia", "Pineapples");
    } else if (ph < 6.0) {
      analysis.push("Soil is moderately acidic.");
      recommendations.push("Add lime if planting soybeans or potatoes.");
      recommendations.push("Use dolomitic lime for magnesium boost.");
      suitableCrops.push("Maize", "Tobacco", "Potatoes");
    } else if (ph > 7.5) {
      analysis.push("Soil is alkaline and may need acid-forming fertilizers.");
      recommendations.push("Use Ammonium Sulfate or acidifying fertilizer.");
      recommendations.push("Incorporate organic matter to moderate pH.");
      suitableCrops.push("Cotton", "Sorghum", "Millets", "Cowpeas");
    } else {
      analysis.push("Soil pH is within the optimal range.");
      suitableCrops.push("Maize", "Soybeans", "Groundnuts", "Wheat", "Cotton");
    }

    if (nitrogen < 20) {
      analysis.push("Nitrogen is low - nutrient inputs are needed.");
      recommendations.push("Apply Urea or Ammonium Nitrate as top dressing.");
      recommendations.push("Rotate with nitrogen-fixing legumes.");
      recommendations.push("Apply well-decomposed cattle manure.");
    } else if (nitrogen > 60) {
      analysis.push("Nitrogen is high - reduce fertilizer rates.");
      recommendations.push("Decrease nitrogen application this season.");
    } else {
      analysis.push("Nitrogen levels are adequate for most crops.");
    }

    if (phosphorus < 12) {
      analysis.push("Phosphorus is deficient, which limits root growth.");
      recommendations.push("Apply Compound D or single super phosphate.");
      suitableCrops.push("Finger millet", "Cowpeas");
    } else if (phosphorus < 20) {
      analysis.push("Phosphorus levels are moderate.");
      recommendations.push(
        "Use a maintenance application of phosphate fertilizer.",
      );
    }

    if (potassium < 100) {
      analysis.push("Potassium is low - crops may be drought sensitive.");
      recommendations.push("Apply MOP (Muriate of Potash) at 100 kg/ha.");
    }

    if (organicMatter < 1.0) {
      analysis.push("Organic matter is very low and soil structure is weak.");
      recommendations.push("Apply 20-25 tons/ha of well-rotted manure.");
      recommendations.push("Use cover crops and residue management.");
    } else if (organicMatter < 2.0) {
      analysis.push("Organic matter is below optimal levels.");
      recommendations.push("Maintain crop residues and add compost annually.");
    }

    if (texture.includes("Sandy")) {
      analysis.push("Sandy soils have lower water and nutrient storage.");
      recommendations.push(
        "Use split fertilizer applications to reduce leaching.",
      );
      recommendations.push("Apply organic mulch to conserve moisture.");
    } else if (texture.includes("Clay")) {
      analysis.push("Clay soils retain nutrients well but drain slowly.");
      recommendations.push("Avoid working the soil when it is too wet.");
    }

    if (region) {
      suitableCrops.push(...region.crops);
    }

    return {
      soilData: data,
      analysis,
      recommendations: [...new Set(recommendations)],
      suitableCrops: [...new Set(suitableCrops)],
      fertilizerRecommendations: getFertilizerRecommendations(data),
      irrigationAdvice: getIrrigationAdvice(data, regionId),
    };
  };

  const handleFieldAnalysis = async () => {
    if (!fieldRegion) return;

    setAnalyzing(true);
    try {
      const body = {
        field_id: fieldRegion,
        ph: inputForm.ph,
        nitrogen: inputForm.nitrogen,
        phosphorus: inputForm.phosphorus,
        potassium: inputForm.potassium,
        organicMatter: inputForm.organicMatter,
        texture: inputForm.texture,
        moisture: inputForm.moisture,
        cationExchangeCapacity: inputForm.cationExchangeCapacity,
      };

      console.log("[SoilAnalysis] Sending analyze request:", body);

      const resp = await authUtils.authenticatedFetch(
        `${API_BASE_URL}/api/soil-analysis/analyze`,
        {
          method: "POST",
          body: JSON.stringify(body),
        },
      );

      console.log("[SoilAnalysis] Analyze response status:", resp.status);

      if (!resp.ok) {
        const errText = await resp.text();
        console.error(
          "[SoilAnalysis] Analysis API error",
          resp.status,
          errText,
        );
        setAnalysisResult(analyzeSoilData(inputForm, fieldRegion));
      } else {
        const json = await resp.json();
        console.log("[SoilAnalysis] Analyze result:", json);
        setAnalysisResult(json as SoilAnalysisResult);
      }
    } catch (err) {
      console.error("[SoilAnalysis] Failed to run analysis:", err);
      setAnalysisResult(analyzeSoilData(inputForm, fieldRegion));
    } finally {
      setAnalyzing(false);
    }
  };

  const clearForm = () => {
    setInputForm(createInitialSoilForm());
    setFieldRegion("");
    setAnalysisResult(null);
  };

  const saveFieldAnalysisResult = async () => {
    if (!analysisResult || !fieldRegion) {
      console.warn("Cannot save: no analysis result or field selected");
      return;
    }

    try {
      const payload = {
        field_id: fieldRegion,
        ph: inputForm.ph,
        nitrogen: inputForm.nitrogen,
        phosphorus: inputForm.phosphorus,
        potassium: inputForm.potassium,
        organicMatter: inputForm.organicMatter,
        texture: inputForm.texture,
        moisture: inputForm.moisture,
        cationExchangeCapacity: inputForm.cationExchangeCapacity,
      };

      console.log("[SoilAnalysis] Saving soil data:", payload);

      const resp = await authUtils.authenticatedFetch(
        `${API_BASE_URL}/api/soil-analysis/save`,
        {
          method: "POST",
          body: JSON.stringify(payload),
        },
      );

      if (!resp.ok) {
        const errText = await resp.text();
        console.error("[SoilAnalysis] Save error:", resp.status, errText);
        alert("Failed to save soil data to database");
        return;
      }

      const result = await resp.json();
      console.log("[SoilAnalysis] Save successful:", result);
      alert("Soil data saved successfully!");
    } catch (err) {
      console.error("[SoilAnalysis] Failed to save:", err);
      alert("Error saving soil data");
    }
  };



  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>,
  ) => {
    const { name, value } = e.target;
    setInputForm((prev) => ({
      ...prev,
      [name]: name === "texture" ? value : value === "" ? null : Number(value),
    }));
  };

  const selectedRegionData = MOCK_SOIL_DATA[selectedRegion];

  return (
    <div className="soil-analysis-unique-container">
      <div className="tab-selector">
        <button
          type="button"
          className={`tab-button ${activeTab === "general" ? "active" : ""}`}
          onClick={() => setActiveTab("general")}
        >
          General Analysis
        </button>
        <button
          type="button"
          className={`tab-button ${activeTab === "field" ? "active" : ""}`}
          onClick={() => setActiveTab("field")}
        >
          Field Specific
        </button>
      </div>

      {fieldsError && (
        <p className="form-hint" style={{ color: "#b91c1c" }}>
          {fieldsError}
        </p>
      )}

      <div className="section-grid">
        {activeTab === "general" && (
          <GeneralAnalysis
            selectedRegion={selectedRegion}
            selectedRegionData={selectedRegionData}
            ZIMBABWE_REGIONS={ZIMBABWE_REGIONS}
            onRegionChange={setSelectedRegion}
            onAnalyzeSoilData={analyzeSoilData}
          />
        )}

        {activeTab === "field" && (
          <FieldSpecificAnalysis
            fieldRegion={fieldRegion}
            inputForm={inputForm}
            analysisResult={analysisResult}
            fields={fieldOptions}
            loadingFields={loadingFields}
            analyzing={analyzing}
            onRegionChange={setFieldRegion}
            onInputChange={handleInputChange}
            onAnalyze={handleFieldAnalysis}
            onClear={clearForm}
            onSave={saveFieldAnalysisResult}
          />
        )}
      </div>
    </div>
  );
};

export default SoilAnalysisZimbabwe;
