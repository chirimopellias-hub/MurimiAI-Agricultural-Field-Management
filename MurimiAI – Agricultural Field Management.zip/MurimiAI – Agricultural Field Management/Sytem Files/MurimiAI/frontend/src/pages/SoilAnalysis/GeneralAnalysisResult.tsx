import React from "react";
import * as LucideIcons from "lucide-react";
import type { SoilAnalysisResult } from "./types.ts";

interface GeneralAnalysisResultProps {
  regionName: string | undefined;
  analysisResult: SoilAnalysisResult;
}

const GeneralAnalysisResult: React.FC<GeneralAnalysisResultProps> = ({
  analysisResult,
}) => (
  <div className="general-analysis-result">
    <div className="results-grid">
      <article className="result-card">
        <div className="result-card-heading">
          <LucideIcons.AlertCircle className="result-card-icon" />
          <h3>Regional Insights</h3>
        </div>
        <ul className="result-list">
          {analysisResult.analysis.map((item, index) => (
            <li key={index}>
              <LucideIcons.Info className="result-list-icon" />
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </article>

      <article className="result-card">
        <div className="result-card-heading">
          <LucideIcons.Sprout className="result-card-icon" />
          <h3>Region Recommendations</h3>
        </div>
        <ul className="result-list">
          {analysisResult.recommendations.map((item, index) => (
            <li key={index}>
              <LucideIcons.CheckCircle2 className="result-list-icon" />
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </article>

      <article className="result-card">
        <div className="result-card-heading">
          <LucideIcons.Wheat className="result-card-icon" />
          <h3>Suitable Crops</h3>
        </div>
        <ul className="result-list">
          {analysisResult.suitableCrops.map((crop, index) => (
            <li key={index}>
              <LucideIcons.Sprout className="result-list-icon" />
              <span>{crop}</span>
            </li>
          ))}
        </ul>
      </article>
    </div>

    {analysisResult.fertilizerRecommendations && (
      <div className="insight-card fertilizer-card">
        <div className="insight-heading">
          <LucideIcons.Beaker className="insight-icon" />
          <h3>Fertilizer Guide</h3>
        </div>
        <div className="fertilizer-grid">
          <div className="fertilizer-entry">
            <h4>Base Dressing</h4>
            <p>{analysisResult.fertilizerRecommendations.baseDressing.type}</p>
            <p>
              {analysisResult.fertilizerRecommendations.baseDressing.amount}
            </p>
            <p>
              {analysisResult.fertilizerRecommendations.baseDressing.timing}
            </p>
          </div>
          <div className="fertilizer-entry">
            <h4>Top Dressing</h4>
            <p>{analysisResult.fertilizerRecommendations.topDressing.type}</p>
            <p>{analysisResult.fertilizerRecommendations.topDressing.amount}</p>
            <p>{analysisResult.fertilizerRecommendations.topDressing.timing}</p>
          </div>
          <div className="fertilizer-entry organic-entry">
            <h4>Organic Options</h4>
            <ul>
              {analysisResult.fertilizerRecommendations.organicOptions.map(
                (option, index) => (
                  <li key={index}>{option}</li>
                ),
              )}
            </ul>
          </div>
        </div>
      </div>
    )}

    {analysisResult.irrigationAdvice && (
      <div className="insight-card irrigation-card">
        <div className="insight-heading">
          <LucideIcons.CloudRain className="insight-icon" />
          <h3>Irrigation Overview</h3>
        </div>
        <div className="irrigation-grid">
          <div className="irrigation-entry">
            <span>Frequency</span>
            <strong>{analysisResult.irrigationAdvice.frequency}</strong>
          </div>
          <div className="irrigation-entry">
            <span>Amount</span>
            <strong>{analysisResult.irrigationAdvice.amount}</strong>
          </div>
          <div className="irrigation-entry">
            <span>Best time</span>
            <strong>{analysisResult.irrigationAdvice.bestTime}</strong>
          </div>
          <div className="irrigation-entry">
            <span>Method</span>
            <strong>{analysisResult.irrigationAdvice.method}</strong>
          </div>
        </div>
      </div>
    )}
  </div>
);

export default GeneralAnalysisResult;
