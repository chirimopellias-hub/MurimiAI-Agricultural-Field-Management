export interface SoilData {
  ph: number | null;
  nitrogen: number | null;
  phosphorus: number | null;
  potassium: number | null;
  organicMatter: number | null;
  texture: string;
  moisture: number | null;
  cationExchangeCapacity: number | null;
}

export interface FertilizerRecommendation {
  baseDressing: {
    type: string;
    amount: string;
    timing: string;
  };
  topDressing: {
    type: string;
    amount: string;
    timing: string;
  };
  organicOptions: string[];
}

export interface IrrigationAdvice {
  frequency: string;
  amount: string;
  bestTime: string;
  method: string;
}

export interface SoilAnalysisResult {
  soilData: SoilData;
  analysis: string[];
  recommendations: string[];
  suitableCrops: string[];
  fertilizerRecommendations?: FertilizerRecommendation;
  irrigationAdvice?: IrrigationAdvice;
}
