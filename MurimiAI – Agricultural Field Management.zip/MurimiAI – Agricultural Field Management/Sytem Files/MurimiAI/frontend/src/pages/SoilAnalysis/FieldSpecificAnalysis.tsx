import React, { useState } from "react";
import * as LucideIcons from "lucide-react";
import "./FieldSpecificAnalysis.css";
import type { SoilData, SoilAnalysisResult } from "./types.ts";
import FieldSpecificAnalysisResult from "./FieldSpecificAnalysisResult.tsx";
import authUtils from "../../utils/authUtils";

interface FieldOption {
  id: string;
  name: string;
  crop_name?: string | null;
  soil_type?: string | null;
  growth_stage?: string | null;
}

const soilTypeOptions = [
  "Clay",
  "Loam",
  "Sandy",
  "Silty",
  "Clay Loam",
  "Sandy Loam",
  "Red-brown Clay",
  "Basaltic Clay",
  "Alluvial",
];

interface FieldSpecificAnalysisProps {
  fieldRegion: string;
  inputForm: SoilData;
  analysisResult: SoilAnalysisResult | null;
  fields: FieldOption[];
  loadingFields: boolean;
  analyzing?: boolean;
  onRegionChange: (region: string) => void;
  onInputChange: (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>,
  ) => void;
  onAnalyze: () => void;
  onClear: () => void;
  onSave: () => void;
}

const FieldSpecificAnalysis: React.FC<FieldSpecificAnalysisProps> = ({
  fieldRegion,
  inputForm,
  analysisResult,
  fields,
  loadingFields,
  onRegionChange,
  onInputChange,
  onClear,
  onSave,
}) => {
  const currentField = fields.find((item) => item.id === fieldRegion);
  const isFieldSelected = Boolean(fieldRegion);
  const [localAnalyzing, setLocalAnalyzing] = useState(false);
  const [localUpdating, setLocalUpdating] = useState(false);
  const [notification, setNotification] = useState<{
    type: "success" | "error";
    message: string;
  } | null>(null);
  const [localAnalysisResult, setLocalAnalysisResult] =
    useState<SoilAnalysisResult | null>(analysisResult || null);

  const showNotification = (type: "success" | "error", message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 3000);
  };

  const handleAnalyzeClick = async () => {
    if (!fieldRegion) {
      showNotification("error", "Please select a field first");
      return;
    }

    setLocalAnalyzing(true);
    try {
      const API_BASE_URL =
        import.meta.env.VITE_API_BASE_URL || "http://localhost:8000";
      const payload = {
        field_id: fieldRegion,
        ph: inputForm.ph,
        nitrogen: inputForm.nitrogen,
        phosphorus: inputForm.phosphorus,
        potassium: inputForm.potassium,
        organicMatter: inputForm.organicMatter,
        texture: inputForm.texture,
        moisture: inputForm.moisture,
        cationExchangeCapacity: inputForm.cationExchangeCapacity,
      };

      const res = await authUtils.authenticatedFetch(
        `${API_BASE_URL}/api/soil-analysis/analyze`,
        {
          method: "POST",
          body: JSON.stringify(payload),
        },
      );

      if (!res.ok) {
        const error = await res.text();
        console.error("Analysis failed:", res.status, error);
        showNotification("error", `Analysis failed: ${res.status}`);
        setLocalAnalyzing(false);
        return;
      }

      const result = await res.json();
      setLocalAnalysisResult(result);
      showNotification("success", "Soil analysis completed successfully");
    } catch (e) {
      console.error("Error analyzing soil:", e);
      showNotification("error", "Failed to analyze soil data");
    } finally {
      setLocalAnalyzing(false);
    }
  };

  const handleSaveAnalysis = async () => {
    if (!fieldRegion) {
      showNotification("error", "Please select a field first");
      return;
    }

    setLocalUpdating(true);
    try {
      const API_BASE_URL =
        import.meta.env.VITE_API_BASE_URL || "http://localhost:8000";
      const payload = {
        field_id: fieldRegion,
        ph: inputForm.ph,
        nitrogen: inputForm.nitrogen,
        phosphorus: inputForm.phosphorus,
        potassium: inputForm.potassium,
        organicMatter: inputForm.organicMatter,
        texture: inputForm.texture,
        moisture: inputForm.moisture,
        cationExchangeCapacity: inputForm.cationExchangeCapacity,
      };

      const res = await authUtils.authenticatedFetch(
        `${API_BASE_URL}/api/soil-analysis/save`,
        {
          method: "POST",
          body: JSON.stringify(payload),
        },
      );

      if (!res.ok) {
        const error = await res.text();
        console.error("Save failed:", res.status, error);
        showNotification("error", `Failed to save soil data: ${res.status}`);
        setLocalUpdating(false);
        return;
      }

      showNotification("success", "Soil data saved to database successfully");
      onSave();
    } catch (e) {
      console.error("Error saving soil data:", e);
      showNotification("error", "Failed to save soil data");
    } finally {
      setLocalUpdating(false);
    }
  };

  return (
    <section className="section-card">
      {/* Overlay for analyzing/updating */}
      {(localAnalyzing || localUpdating) && (
        <div className="smart-advisory-overlay">
          <div className="smart-advisory-loading-card">
            <p className="smart-advisory-loading-title">
              {localAnalyzing
                ? "Analyzing soil data…"
                : localUpdating
                  ? "Updating field soil data…"
                  : "Processing…"}
            </p>
            <div className="typing-wrapper smart-advisory-loading-typing">
              <div className="typing-indicator">
                <div className="typing-dot"></div>
                <div className="typing-dot delay-200"></div>
                <div className="typing-dot delay-400"></div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Notification */}
      {notification && (
        <div
          className={`farm-notification farm-notification-${notification.type}`}
          style={{
            position: "fixed",
            top: "20px",
            right: "20px",
            zIndex: 9999,
          }}
        >
          <span>{notification.message}</span>
          <button onClick={() => setNotification(null)}>×</button>
        </div>
      )}

      <div className="section-heading">
        <div className="section-icon">
          <LucideIcons.TestTube className="section-icon-svg" />
        </div>
        <div>
          <h2>Field Specific Soil Analysis</h2>
          <p>
            Enter your measured soil sample values for precise field guidance.
          </p>
        </div>
      </div>

      <div className="card-content">
        <div className="form-grid">
          <div className="form-group">
            <label className="form-label" htmlFor="fieldRegion">
              Field
            </label>
            <select
              id="fieldRegion"
              className="form-select"
              value={fieldRegion}
              onChange={(e) => onRegionChange(e.target.value)}
              disabled={loadingFields}
            >
              <option value="">Select a field</option>
              {fields.map((field) => (
                <option key={field.id} value={field.id}>
                  {field.name}
                </option>
              ))}
            </select>
            {loadingFields && (
              <p className="form-hint">Loading your farm fields…</p>
            )}
            {!loadingFields && fields.length === 0 && (
              <p className="form-hint">
                No fields are available for this farm yet.
              </p>
            )}
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="ph">
              pH level
            </label>
            <input
              id="ph"
              name="ph"
              type="number"
              step="0.1"
              min="0"
              max="14"
              className="form-input"
              value={inputForm.ph ?? ""}
              onChange={onInputChange}
              disabled={!isFieldSelected}
            />
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="nitrogen">
              Nitrogen (N)
            </label>
            <input
              id="nitrogen"
              name="nitrogen"
              type="number"
              className="form-input"
              value={inputForm.nitrogen ?? ""}
              onChange={onInputChange}
              disabled={!isFieldSelected}
            />
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="phosphorus">
              Phosphorus (P)
            </label>
            <input
              id="phosphorus"
              name="phosphorus"
              type="number"
              className="form-input"
              value={inputForm.phosphorus ?? ""}
              onChange={onInputChange}
              disabled={!isFieldSelected}
            />
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="potassium">
              Potassium (K)
            </label>
            <input
              id="potassium"
              name="potassium"
              type="number"
              className="form-input"
              value={inputForm.potassium ?? ""}
              onChange={onInputChange}
              disabled={!isFieldSelected}
            />
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="organicMatter">
              Organic matter (%)
            </label>
            <input
              id="organicMatter"
              name="organicMatter"
              type="number"
              step="0.1"
              className="form-input"
              value={inputForm.organicMatter ?? ""}
              onChange={onInputChange}
              disabled={!isFieldSelected}
            />
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="texture">
              Texture
            </label>
            <select
              id="texture"
              name="texture"
              className="form-select"
              value={inputForm.texture}
              onChange={onInputChange}
              disabled={!isFieldSelected}
            >
              <option value="">Select soil texture</option>
              {soilTypeOptions.map((option) => (
                <option key={option} value={option}>
                  {option}
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="moisture">
              Moisture (%)
            </label>
            <input
              id="moisture"
              name="moisture"
              type="number"
              className="form-input"
              value={inputForm.moisture ?? ""}
              onChange={onInputChange}
              disabled={!isFieldSelected}
            />
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="cationExchangeCapacity">
              CEC (meq/100g)
            </label>
            <input
              id="cationExchangeCapacity"
              name="cationExchangeCapacity"
              type="number"
              step="0.1"
              className="form-input"
              value={inputForm.cationExchangeCapacity ?? ""}
              onChange={onInputChange}
              disabled={!isFieldSelected}
            />
          </div>
        </div>

        <div className="form-actions">
          <button
            className="primary-button"
            onClick={handleAnalyzeClick}
            disabled={!isFieldSelected || localAnalyzing || localUpdating}
          >
            {localAnalyzing ? "Analyzing…" : "Analyze Field Soil"}
          </button>
          <button className="secondary-button" onClick={onClear} type="button">
            Clear Inputs
          </button>
        </div>

        {localAnalysisResult && (
          <div>
            <FieldSpecificAnalysisResult
              fieldRegionName={currentField?.name ?? "Selected field"}
              analysisResult={localAnalysisResult}
              onSave={handleSaveAnalysis}
            />
          </div>
        )}
      </div>
    </section>
  );
};

export default FieldSpecificAnalysis;
