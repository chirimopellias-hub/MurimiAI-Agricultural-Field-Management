import React from "react";
import * as LucideIcons from "lucide-react";
import "./GeneralAnalysis.css";
import type { SoilData, SoilAnalysisResult } from "./types.ts";
import SoilDataDisplay from "./SoilDataDisplay.tsx";
import GeneralAnalysisResult from "./GeneralAnalysisResult.tsx";

interface GeneralAnalysisProps {
  selectedRegion: string;
  selectedRegionData: SoilData;
  ZIMBABWE_REGIONS: Array<{
    id: string;
    name: string;
    description: string;
    rainfall: string;
    crops: string[];
    soilTypes: string[];
    icon: React.ReactNode;
  }>;
  onRegionChange: (region: string) => void;
  onAnalyzeSoilData: (data: SoilData, regionId: string) => SoilAnalysisResult;
}

const GeneralAnalysis: React.FC<GeneralAnalysisProps> = ({
  selectedRegion,
  selectedRegionData,
  ZIMBABWE_REGIONS,
  onRegionChange,
  onAnalyzeSoilData,
}) => {
  const currentRegion = ZIMBABWE_REGIONS.find((r) => r.id === selectedRegion);
  const analysisResult = onAnalyzeSoilData(selectedRegionData, selectedRegion);

  return (
    <section className="section-card general-analysis-card">
      <div className="section-heading general-analysis-heading">
        <div className="section-icon general-analysis-icon">
          <LucideIcons.Map className="section-icon-svg" />
        </div>
        <div>
          <h2>General Soil Analysis</h2>
          <p> This overview shows typical soil conditions, practical
            recommendations, and crop suitability for the selected natural region.</p>
        </div>
      </div>

      <div className="card-content">
        <div className="input-block">
          <label className="form-label" htmlFor="generalRegion">
            Select a region
          </label>
          <select
            id="generalRegion"
            className="form-select"
            value={selectedRegion}
            onChange={(e) => onRegionChange(e.target.value)}
          >
            {ZIMBABWE_REGIONS.map((region) => (
              <option key={region.id} value={region.id}>
                {region.name}
              </option>
            ))}
          </select>
        </div>

        <div className="region-summary">
          <div className="region-badge">Typical {currentRegion?.name}</div>
          <p>{currentRegion?.description}</p>
          <div className="region-metrics">
            <span>Rainfall: {currentRegion?.rainfall}</span>
            <span>Soil types: {currentRegion?.soilTypes.join(", ")}</span>
          </div>
        </div>

        <div className="preview-card">
          <div className="preview-header">
            <LucideIcons.ClipboardList className="preview-icon" />
            <span>Typical region soil profile</span>
          </div>
          <SoilDataDisplay data={selectedRegionData} />
        </div>

        <GeneralAnalysisResult
          regionName={currentRegion?.name}
          analysisResult={analysisResult}
        />
      </div>
    </section>
  );
};

export default GeneralAnalysis;
