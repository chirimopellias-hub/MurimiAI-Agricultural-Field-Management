import React from "react";
import * as LucideIcons from "lucide-react";
import type { SoilAnalysisResult} from "./types.ts";

interface FieldSpecificAnalysisResultProps {
  fieldRegionName: string;
  analysisResult: SoilAnalysisResult;
  onSave: () => void;
}

const FieldSpecificAnalysisResult: React.FC<
  FieldSpecificAnalysisResultProps
> = ({ fieldRegionName, analysisResult, onSave}) =>
  (() => {
    // Log for debugging
    console.log(
      "[FieldSpecificAnalysisResult] Received analysisResult:",
      analysisResult,
    );

    // Defensive defaults in case backend (DeepSeek) returns unexpected shape
    const analysis = Array.isArray(analysisResult?.analysis)
      ? analysisResult.analysis
      : [];
    const recommendations = Array.isArray(analysisResult?.recommendations)
      ? analysisResult.recommendations
      : [];
    const suitableCrops = Array.isArray(analysisResult?.suitableCrops)
      ? analysisResult.suitableCrops
      : [];

    const fertilizer = analysisResult?.fertilizerRecommendations || null;
    const irrigation = analysisResult?.irrigationAdvice || null;

    // Provide safe defaults so UI still renders when backend returns null/malformed data
    const fert = fertilizer || {
      baseDressing: { type: "-", amount: "-", timing: "-" },
      topDressing: { type: "-", amount: "-", timing: "-" },
      organicOptions: [],
    };
    const irrig = irrigation || {
      frequency: "-",
      amount: "-",
      bestTime: "-",
      method: "-",
    };

    console.log(
      "[FieldSpecificAnalysisResult] Parsed analysis length:",
      analysis.length,
    );
    console.log(
      "[FieldSpecificAnalysisResult] Parsed recommendations length:",
      recommendations.length,
    );
    console.log(
      "[FieldSpecificAnalysisResult] Parsed suitableCrops length:",
      suitableCrops.length,
    );

    // If analysisResult contains an error message, show it
    if (
      analysisResult &&
      analysis.length === 0 &&
      recommendations.length === 0 &&
      suitableCrops.length === 0
    ) {
      console.log(
        "[FieldSpecificAnalysisResult] No data found, showing error JSON",
      );
      return (
        <div className="field-specific-analysis-result">
          <div className="field-result-header">
            <div>
              <h3>Field Specific Results for {fieldRegionName}</h3>
              <p>Analysis returned no structured data.</p>
            </div>
          </div>
          <div className="analysis-error">
            <pre style={{ whiteSpace: "pre-wrap", color: "#b91c1c" }}>
              {JSON.stringify(analysisResult, null, 2)}
            </pre>
          </div>
        </div>
      );
    }

    console.log(
      "[FieldSpecificAnalysisResult] Rendering main results with data",
    );
    return (
      <div className="field-specific-analysis-result">
        <div className="field-result-header">
          <div>
            <h3>Field Specific Results for {fieldRegionName}</h3>
          </div>
          <div className="field-result-actions">
            <button className="secondary-button" type="button" onClick={onSave}>
              <LucideIcons.Save className="button-icon" /> Update Soil Data
            </button>
          </div>
        </div>

        <div className="results-grid">
          <article className="result-card">
            <div className="result-card-heading">
              <LucideIcons.AlertTriangle className="result-card-icon" />
              <h3>Soil Condition</h3>
            </div>
            <ul className="result-list">
              {analysis.map((item, index) => (
                <li key={index}>
                  <LucideIcons.Info className="result-list-icon" />
                  <span>{String(item)}</span>
                </li>
              ))}
            </ul>
          </article>

          <article className="result-card">
            <div className="result-card-heading">
              <LucideIcons.CheckCircle2 className="result-card-icon" />
              <h3>Action Plan</h3>
            </div>
            <ul className="result-list">
              {recommendations.map((item, index) => (
                <li key={index}>
                  <LucideIcons.ChevronRight className="result-list-icon" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </article>

          <article className="result-card">
            <div className="result-card-heading">
              <LucideIcons.Wheat className="result-card-icon" />
              <h3>Best Crops</h3>
            </div>
            <ul className="result-list">
              {suitableCrops.map((crop, index) => (
                <li key={index}>
                  <LucideIcons.Sprout className="result-list-icon" />
                  <span>{crop}</span>
                </li>
              ))}
            </ul>
          </article>
        </div>

        <div className="insight-card fertilizer-card">
          <div className="insight-heading">
            <LucideIcons.Beaker className="insight-icon" />
            <h3>Fertilizer Plan</h3>
          </div>
          <div className="fertilizer-grid">
            <div className="fertilizer-entry">
              <h4>Base Dressing</h4>
              <p>{fert.baseDressing?.type ?? "-"}</p>
              <p>{fert.baseDressing?.amount ?? "-"}</p>
              <p>{fert.baseDressing?.timing ?? "-"}</p>
            </div>
            <div className="fertilizer-entry">
              <h4>Top Dressing</h4>
              <p>{fert.topDressing?.type ?? "-"}</p>
              <p>{fert.topDressing?.amount ?? "-"}</p>
              <p>{fert.topDressing?.timing ?? "-"}</p>
            </div>
            <div className="fertilizer-entry organic-entry">
              <h4>Organic</h4>
              <ul>
                {(fert.organicOptions ?? []).map((option, index) => (
                  <li key={index}>{option}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        <div className="insight-card irrigation-card">
          <div className="insight-heading">
            <LucideIcons.CloudRain className="insight-icon" />
            <h3>Irrigation Advice</h3>
          </div>
          <div className="irrigation-grid">
            <div className="irrigation-entry">
              <span>Frequency</span>
              <strong>{irrig.frequency ?? "-"}</strong>
            </div>
            <div className="irrigation-entry">
              <span>Amount</span>
              <strong>{irrig.amount ?? "-"}</strong>
            </div>
            <div className="irrigation-entry">
              <span>Best time</span>
              <strong>{irrig.bestTime ?? "-"}</strong>
            </div>
            <div className="irrigation-entry">
              <span>Method</span>
              <strong>{irrig.method ?? "-"}</strong>
            </div>
          </div>
        </div>


      </div>
    );
  })();

export default FieldSpecificAnalysisResult;
