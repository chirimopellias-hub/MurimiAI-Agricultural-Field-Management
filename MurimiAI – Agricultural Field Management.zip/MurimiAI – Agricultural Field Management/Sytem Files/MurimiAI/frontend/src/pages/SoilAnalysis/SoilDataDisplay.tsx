import React from "react";
import * as LucideIcons from "lucide-react";
import type { SoilData } from "./types.ts";

interface SoilDataDisplayProps {
  data: SoilData;
}

const getNutrientStatusIcon = (value: number, min: number, max: number) => {
  if (value < min)
    return <LucideIcons.ArrowDownCircle className="status-icon low" />;
  if (value > max)
    return <LucideIcons.ArrowUpCircle className="status-icon high" />;
  return <LucideIcons.CheckCircle2 className="status-icon ok" />;
};

const SoilDataDisplay: React.FC<SoilDataDisplayProps> = ({ data }) => (
  <div className="soil-data-grid">
    <div className="soil-data-item">
      <div className="soil-data-header">
        <LucideIcons.FlaskConical className="soil-data-icon" />
        <span className="soil-data-label">pH Level</span>
      </div>
      <span className="soil-data-value">{data.ph}</span>
      <span
        className={`status-badge ${data.ph < 5.5 ? "warning" : data.ph > 7.5 ? "warning" : "success"}`}
      >
        {data.ph < 5.5 ? "Acidic" : data.ph > 7.5 ? "Alkaline" : "Optimal"}
      </span>
    </div>
    <div className="soil-data-item">
      <div className="soil-data-header">
        <LucideIcons.Beaker className="soil-data-icon" />
        <span className="soil-data-label">Nitrogen (N)</span>
      </div>
      <span className="soil-data-value">{data.nitrogen} ppm</span>
      {getNutrientStatusIcon(data.nitrogen, 20, 50)}
    </div>
    <div className="soil-data-item">
      <div className="soil-data-header">
        <LucideIcons.TestTube className="soil-data-icon" />
        <span className="soil-data-label">Phosphorus (P)</span>
      </div>
      <span className="soil-data-value">{data.phosphorus} ppm</span>
      {getNutrientStatusIcon(data.phosphorus, 15, 30)}
    </div>
    <div className="soil-data-item">
      <div className="soil-data-header">
        <LucideIcons.FlaskConical className="soil-data-icon" />
        <span className="soil-data-label">Potassium (K)</span>
      </div>
      <span className="soil-data-value">{data.potassium} ppm</span>
      {getNutrientStatusIcon(data.potassium, 100, 250)}
    </div>
    <div className="soil-data-item">
      <div className="soil-data-header">
        <LucideIcons.Leaf className="soil-data-icon" />
        <span className="soil-data-label">Organic Matter</span>
      </div>
      <span className="soil-data-value">{data.organicMatter}%</span>
      <span
        className={`status-badge ${data.organicMatter < 1.5 ? "warning" : data.organicMatter > 4 ? "success" : "info"}`}
      >
        {data.organicMatter < 1.5
          ? "Low"
          : data.organicMatter > 4
            ? "High"
            : "Moderate"}
      </span>
    </div>
    <div className="soil-data-item">
      <div className="soil-data-header">
        <LucideIcons.LandPlot className="soil-data-icon" />
        <span className="soil-data-label">Texture</span>
      </div>
      <span className="soil-data-value">{data.texture}</span>
    </div>
    <div className="soil-data-item">
      <div className="soil-data-header">
        <LucideIcons.Droplets className="soil-data-icon" />
        <span className="soil-data-label">Moisture</span>
      </div>
      <span className="soil-data-value">{data.moisture}%</span>
      <span
        className={`status-badge ${data.moisture < 20 ? "critical" : data.moisture < 40 ? "warning" : data.moisture > 70 ? "warning" : "success"}`}
      >
        {data.moisture < 20
          ? "Very Low"
          : data.moisture < 40
            ? "Low"
            : data.moisture > 70
              ? "High"
              : "Optimal"}
      </span>
    </div>
    <div className="soil-data-item">
      <div className="soil-data-header">
        <LucideIcons.Gauge className="soil-data-icon" />
        <span className="soil-data-label">CEC</span>
      </div>
      <span className="soil-data-value">
        {data.cationExchangeCapacity} meq/100g
      </span>
    </div>
  </div>
);

export default SoilDataDisplay;
