import jsPDF from "jspdf";
import type { SoilAnalysisResult, SoilData } from "./types.ts";

interface PDFGeneratorOptions {
  farmName: string;
  farmEmail: string;
  fieldName: string;
  analysisResult: SoilAnalysisResult;
  inputForm: SoilData;
}

/**
 * Generate and download a soil analysis PDF report using jsPDF.
 */
export async function generateSoilAnalysisPDF(
  options: PDFGeneratorOptions
): Promise<void> {
  const {
    farmName,
    farmEmail,
    fieldName,
    analysisResult,
    inputForm,
  } = options;

  const pdf = new jsPDF({
    orientation: "portrait",
    unit: "mm",
    format: "a4",
  });

  const pageWidth = pdf.internal.pageSize.getWidth();
  const pageHeight = pdf.internal.pageSize.getHeight();
  const margin = 15;
  const contentWidth = pageWidth - 2 * margin;

  let yPos = margin;

  // ===== HEADER =====
  // Murimi logo/text on the left
  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(18);
  pdf.text("MURIMI", margin, yPos + 10);

  // Farm name in the center
  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(16);
  const farmNameWidth = pdf.getTextWidth(farmName);
  pdf.text(farmName, pageWidth / 2 - farmNameWidth / 2, yPos + 5);

  // Email below farm name in the center
  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(10);
  const emailWidth = pdf.getTextWidth(farmEmail);
  pdf.text(farmEmail, pageWidth / 2 - emailWidth / 2, yPos + 12);

  pdf.setDrawColor(200);
  pdf.line(margin, yPos + 18, pageWidth - margin, yPos + 18);

  yPos += 25;

  // Field name
  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(12);
  pdf.text(`Field: ${fieldName}`, margin, yPos);
  yPos += 8;

  // Timestamp
  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(10);
  const timestamp = new Date().toLocaleDateString();
  pdf.text(`Report Date: ${timestamp}`, margin, yPos);
  yPos += 10;

  // ===== SOIL CONDITION, ACTION PLAN, BEST CROPS =====
  const analysis = Array.isArray(analysisResult?.analysis)
    ? analysisResult.analysis
    : [];
  const recommendations = Array.isArray(analysisResult?.recommendations)
    ? analysisResult.recommendations
    : [];
  const suitableCrops = Array.isArray(analysisResult?.suitableCrops)
    ? analysisResult.suitableCrops
    : [];

  const colWidth = (contentWidth - 4) / 3; // 3 columns with small gaps

  // Draw three columns
  const cardHeight = 50;

  // Column 1: Soil Condition
  drawCard(pdf, margin, yPos, colWidth, cardHeight, "Soil Condition", "#FFE5E5");
  if (analysis.length > 0) {
    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(9);
    const text = analysis[0];
    const lines = pdf.splitTextToSize(text, colWidth - 4);
    pdf.text(lines, margin + 2, yPos + 18);
  }

  // Column 2: Action Plan
  drawCard(
    pdf,
    margin + colWidth + 2,
    yPos,
    colWidth,
    cardHeight,
    "Action Plan",
    "#E5F5E5"
  );
  if (recommendations.length > 0) {
    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(9);
    const text = recommendations[0];
    const lines = pdf.splitTextToSize(text, colWidth - 4);
    pdf.text(lines, margin + colWidth + 4, yPos + 18);
  }

  // Column 3: Best Crops
  drawCard(
    pdf,
    margin + 2 * colWidth + 4,
    yPos,
    colWidth,
    cardHeight,
    "Best Crops",
    "#E5E5FF"
  );
  if (suitableCrops.length > 0) {
    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(9);
    const text = suitableCrops.slice(0, 2).join(", ");
    const lines = pdf.splitTextToSize(text, colWidth - 4);
    pdf.text(lines, margin + 2 * colWidth + 6, yPos + 18);
  }

  yPos += cardHeight + 5;

  // ===== FERTILIZER PLAN =====
  const fertilizer = analysisResult?.fertilizerRecommendations || null;
  if (fertilizer) {
    drawSectionHeader(pdf, margin, yPos, "Fertilizer Plan");
    yPos += 8;

    const fertColWidth = contentWidth / 3;
    const fertHeight = 30;

    // Base Dressing
    drawCard(
      pdf,
      margin,
      yPos,
      fertColWidth,
      fertHeight,
      "Base Dressing",
      "#FFF9E5"
    );
    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(9);
    const baseText = `Type: ${fertilizer.baseDressing?.type ?? "-"}\nAmount: ${fertilizer.baseDressing?.amount ?? "-"}\nTiming: ${fertilizer.baseDressing?.timing ?? "-"}`;
    pdf.text(baseText, margin + 2, yPos + 8);

    // Top Dressing
    drawCard(
      pdf,
      margin + fertColWidth + 1,
      yPos,
      fertColWidth,
      fertHeight,
      "Top Dressing",
      "#FFF0E5"
    );
    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(9);
    const topText = `Type: ${fertilizer.topDressing?.type ?? "-"}\nAmount: ${fertilizer.topDressing?.amount ?? "-"}\nTiming: ${fertilizer.topDressing?.timing ?? "-"}`;
    pdf.text(topText, margin + fertColWidth + 3, yPos + 8);

    // Organic Options
    drawCard(
      pdf,
      margin + 2 * fertColWidth + 2,
      yPos,
      fertColWidth,
      fertHeight,
      "Organic",
      "#F0FFE5"
    );
    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(9);
    const organicText = (fertilizer.organicOptions ?? []).join("\n");
    if (organicText) {
      pdf.text(organicText, margin + 2 * fertColWidth + 4, yPos + 8);
    } else {
      pdf.text("-", margin + 2 * fertColWidth + 4, yPos + 8);
    }

    yPos += fertHeight + 5;
  }

  // ===== IRRIGATION ADVICE =====
  const irrigation = analysisResult?.irrigationAdvice || null;
  if (irrigation) {
    drawSectionHeader(pdf, margin, yPos, "Irrigation Advice");
    yPos += 8;

    const irrigColWidth = contentWidth / 4;
    const irrigHeight = 20;

    // Frequency
    drawCard(pdf, margin, yPos, irrigColWidth, irrigHeight, "Frequency", "#E5F0FF");
    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(9);
    pdf.text(irrigation.frequency ?? "-", margin + 2, yPos + 12);

    // Amount
    drawCard(
      pdf,
      margin + irrigColWidth + 1,
      yPos,
      irrigColWidth,
      irrigHeight,
      "Amount",
      "#F0E5FF"
    );
    pdf.text(irrigation.amount ?? "-", margin + irrigColWidth + 3, yPos + 12);

    // Best Time
    drawCard(
      pdf,
      margin + 2 * irrigColWidth + 2,
      yPos,
      irrigColWidth,
      irrigHeight,
      "Best Time",
      "#E5FFF0"
    );
    pdf.text(irrigation.bestTime ?? "-", margin + 2 * irrigColWidth + 4, yPos + 12);

    // Method
    drawCard(
      pdf,
      margin + 3 * irrigColWidth + 3,
      yPos,
      irrigColWidth,
      irrigHeight,
      "Method",
      "#FFE5F0"
    );
    pdf.text(irrigation.method ?? "-", margin + 3 * irrigColWidth + 5, yPos + 12);

    yPos += irrigHeight + 5;
  }

  // ===== FIELD SOIL DATA =====
  drawSectionHeader(pdf, margin, yPos, "Field Soil Data");
  yPos += 8;

  const dataRows = [
    ["pH Level", inputForm.ph?.toString() ?? "-"],
    ["Nitrogen (ppm)", inputForm.nitrogen?.toString() ?? "-"],
    ["Phosphorus (ppm)", inputForm.phosphorus?.toString() ?? "-"],
    ["Potassium (ppm)", inputForm.potassium?.toString() ?? "-"],
    ["Organic Matter (%)", inputForm.organicMatter?.toString() ?? "-"],
    ["Texture", inputForm.texture || "-"],
    ["Moisture (%)", inputForm.moisture?.toString() ?? "-"],
    ["CEC (meq/100g)", inputForm.cationExchangeCapacity?.toString() ?? "-"],
  ];

  const dataColWidth = contentWidth / 2;
  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(9);

  for (let i = 0; i < dataRows.length; i++) {
    const [label, value] = dataRows[i];
    const col = i % 2;
    const row = Math.floor(i / 2);
    const x = margin + col * dataColWidth;
    const y = yPos + row * 7;

    // Draw background
    if (row % 2 === 0) {
      pdf.setFillColor(240, 240, 240);
    } else {
      pdf.setFillColor(255, 255, 255);
    }
    pdf.rect(x, y, dataColWidth, 6, "F");

    // Draw border
    pdf.setDrawColor(200);
    pdf.rect(x, y, dataColWidth, 6);

    // Draw text
    pdf.setTextColor(0, 0, 0);
    pdf.text(`${label}:`, x + 2, y + 4);
    pdf.text(value, x + dataColWidth - 15, y + 4, { align: "right" });
  }

  // Download
  const filename = `soil-analysis-${fieldName}-${Date.now()}.pdf`;
  pdf.save(filename);
}

/**
 * Draw a colored card/box with a title.
 */
function drawCard(
  pdf: jsPDF,
  x: number,
  y: number,
  width: number,
  height: number,
  title: string,
  backgroundColor: string
): void {
  // Parse color from hex
  const rgb = hexToRgb(backgroundColor);
  pdf.setFillColor(rgb.r, rgb.g, rgb.b);
  pdf.rect(x, y, width, height, "F");

  // Border
  pdf.setDrawColor(100);
  pdf.rect(x, y, width, height);

  // Title
  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(10);
  pdf.setTextColor(0, 0, 0);
  pdf.text(title, x + 2, y + 5);
}

/**
 * Draw a section header with a line.
 */
function drawSectionHeader(
  pdf: jsPDF,
  x: number,
  y: number,
  title: string
): void {
  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(11);
  pdf.setTextColor(0, 0, 0);
  pdf.text(title, x, y);

  const titleWidth = pdf.getTextWidth(title);
  pdf.setDrawColor(0);
  pdf.line(x + titleWidth + 3, y - 2, x + 100, y - 2);
}

/**
 * Convert hex color to RGB.
 */
function hexToRgb(hex: string): { r: number; g: number; b: number } {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result
    ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16),
      }
    : { r: 255, g: 255, b: 255 };
}
