import React, { useState, useRef, useEffect, useCallback } from "react";
import * as Leaflet from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import * as LucideIcons from "lucide-react";
import type {
  AddFieldProps,
  FarmBoundary,
  FarmWithIndices,
  UserLocation,
} from "../../types/AddField";
import axios from "axios";
import authUtils from "../../utils/authUtils";
import PopupMessage from "../../components/PopupMessage";
import type { PopupMessageType } from "../../components/PopupMessage";
import "./AddField.css";

// Fix for Leaflet default icons
const iconDefaultProto = L.Icon.Default.prototype as unknown as {
  _getIconUrl?: string;
};
delete iconDefaultProto._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl:
    "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png",
  iconUrl:
    "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png",
  shadowUrl:
    "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png",
});

// Custom user location icon
const userLocationIcon = new L.Icon({
  iconUrl:
    "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png",
  iconRetinaUrl:
    "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png",
  shadowUrl:
    "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png",
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41],
});

// Map Click Handler Component
const MapClickHandler: React.FC<{
  isDrawing: boolean;
  onPointAdd: (lat: number, lng: number) => void;
}> = ({ isDrawing, onPointAdd }) => {
  Leaflet.useMapEvents({
    click: (e) => {
      if (isDrawing && onPointAdd) {
        onPointAdd(e.latlng.lat, e.latlng.lng);
      }
    },
  });
  return null;
};

// User Location Marker Component
const UserLocationMarker: React.FC<{
  position: [number, number];
  accuracy: number;
}> = ({ position, accuracy }) => {
  const map = Leaflet.useMapEvents({
    locationfound: (e) => {
      if (e && e.latlng && !isNaN(e.latlng.lat) && !isNaN(e.latlng.lng)) {
        map.flyTo(e.latlng, map.getZoom());
      }
    },
  });

  useEffect(() => {
    if (position) {
      const circle = L.circle(position, {
        radius: accuracy,
        color: "#4299e1",
        weight: 2,
        fillColor: "#4299e1",
        fillOpacity: 0.15,
      });
      circle.addTo(map);

      return () => {
        map.removeLayer(circle);
      };
    }
  }, [map, position, accuracy]);

  return position ? (
    <Leaflet.Marker position={position} icon={userLocationIcon}>
      <Leaflet.Popup>
        <div className="p-2" style={{ minWidth: "200px" }}>
          <h3 className="text-base font-semibold mb-2">Your Location</h3>
          <p className="text-sm mb-1">
            <strong>Latitude:</strong> {position[0].toFixed(6)}
          </p>
          <p className="text-sm mb-1">
            <strong>Longitude:</strong> {position[1].toFixed(6)}
          </p>
          <p className="text-sm mb-1">
            <strong>Accuracy:</strong> ±{Math.round(accuracy)} meters
          </p>
          <p className="text-sm">
            <strong>Time:</strong> {new Date().toLocaleTimeString()}
          </p>
        </div>
      </Leaflet.Popup>
    </Leaflet.Marker>
  ) : null;
};

const AddField: React.FC<AddFieldProps> = ({
  initialFarms = [],
  onBoundaryChange,
  onIndicesUpdate,
  showControls = true,
  editable = true,
  centerOnUser = true,
}) => {
  const [farms, setFarms] = useState<FarmWithIndices[]>(initialFarms);
  const [selectedIndex] = useState<"ndvi" | "ndmi" | "mndwi" | "ndwi">("ndvi");
  const [isDrawing, setIsDrawing] = useState(false);
  const [drawingPoints, setDrawingPoints] = useState<[number, number][]>([]);
  const [tempPolyline, setTempPolyline] = useState<[number, number][]>([]);
  const [userLocation, setUserLocation] = useState<UserLocation | null>(null);
  const [locationError, setLocationError] = useState<string | null>(null);
  const [isGettingLocation, setIsGettingLocation] = useState(false);

  // Default to satellite base map so users immediately get Mapbox imagery.
  const [baseMap, setBaseMap] = useState<"osm" | "satellite">("satellite");
  const baseMapMaxZoom = baseMap === "osm" ? 19 : 18;
  const googleMapsKey = import.meta.env.VITE_GOOGLE_MAPS_KEY as string;

  // Use Google Maps Satellite tiles (latest imagery) via the tile API.
  // NOTE: This uses the public Google tile endpoint; ensure your Google Maps API key has appropriate permissions.
  const googleSatelliteUrl = `https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}&key=${googleMapsKey}`;
  const [showLocationPopup, setShowLocationPopup] = useState(false);
  const [popupMessage, setPopupMessage] = useState<{
    type: PopupMessageType;
    title: string;
    message: string;
  } | null>(null);
  const [userFarmId, setUserFarmId] = useState<string>("");
  const [fieldCoordinates, setFieldCoordinates] = useState<[number, number][]>(
    [],
  );
  const [isSubmitting, setIsSubmitting] = useState(false);

  const normalizeFarmId = (id?: string | null): string => {
    if (!id) return "";
    const trimmed = id.trim();
    if (!trimmed || trimmed === "Farm ID not set" || trimmed === "undefined")
      return "";
    return trimmed;
  };
  const [isMobile, setIsMobile] = useState(false);
  const [currentArea, setCurrentArea] = useState<number>(0);
  const mapRef = useRef<L.Map>(null);

  const showPopup = (
    type: PopupMessageType,
    title: string,
    message: string,
  ) => {
    setPopupMessage({ type, title, message });
  };

  const closePopup = () => {
    setPopupMessage(null);
  };

  const validateForm = () => {
    const errors: string[] = [];

    const normalizedFarmId =
      normalizeFarmId(userFarmId) || normalizeFarmId(authUtils.getFarmId());
    if (!normalizedFarmId) {
      errors.push(
        "Farm ID linked to this user is missing. Please login again.",
      );
    }
    if (!formData.farmName.trim()) {
      errors.push("Please enter the farm name.");
    }
    if (!formData.cropName.trim()) {
      errors.push("Please enter the crop name.");
    }
    if (!formData.variety.trim()) {
      errors.push("Please enter the crop variety.");
    }
    if (!formData.sowingDate.trim()) {
      errors.push("Please select the sowing date.");
    }
    if (!formData.irrigationType.trim()) {
      errors.push("Please choose the irrigation type.");
    }
    if (fieldCoordinates.length < 3 && drawingPoints.length < 3) {
      errors.push("Draw a field boundary with at least 3 points.");
    }
    if (currentArea <= 0) {
      errors.push("The field boundary area must be greater than zero.");
    }

    return errors;
  };

  // Search functionality
  type SearchResult = {
    lat: string;
    lon: string;
    display_name: string;
  };

  const [searchQuery, setSearchQuery] = useState<string>("");
  const [isSearching, setIsSearching] = useState<boolean>(false);
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [showSearchResults, setShowSearchResults] = useState<boolean>(false);

  // Crop form data
  const [formData, setFormData] = useState({
    farmName: "",
    cropName: "",
    variety: "",
    sowingDate: "",
    irrigationType: "",
    soilType: "",
    growthStage: "",
    phLevel: "",
    nitrogen: "",
    phosphorus: "",
    potassium: "",
    organicMatter: "",
    moisture: "",
    cec: "",
  });

  const cropOptions = [
    "Maize",
    "Wheat",
    "Rice",
    "Soybeans",
    "Potatoes",
    "Tomatoes",
    "Cotton",
    "Coffee",
    "Tobbacco",
    "Sugarcane",
  ];
  const irrigationOptions = [
    "Drip Irrigation",
    "Sprinkler System",
    "Flood Irrigation",
    "Center Pivot",
    "Manual Watering",
    "Rain-fed",
  ];

  const soilTypeOptions = [
    "Clay",
    "Loam",
    "Sandy",
    "Silty",
    "Clay Loam",
    "Sandy Loam",
    "Red-brown Clay",
    "Basaltic Clay",
    "Alluvial",
  ];

  const growthStageOptions = [
    "Initial",
    "Development",
    "Mid",
    "Late",
    "Harvest",
  ];

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>,
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const errors = validateForm();
    if (errors.length > 0) {
      showPopup("error", "Validation failed", errors[0]);
      return;
    }

    const farmId =
      normalizeFarmId(userFarmId) || normalizeFarmId(authUtils.getFarmId());
    if (!farmId) {
      showPopup(
        "error",
        "Validation failed",
        "Farm ID linked to this user is missing. Please login again.",
      );
      return;
    }
    if (!userFarmId) {
      setUserFarmId(farmId);
    }

    const finalCoordinates =
      fieldCoordinates.length >= 3 ? fieldCoordinates : drawingPoints;
    const fieldCentroid = calculateFieldCentroid(finalCoordinates);

    const soilData = {
      texture: formData.soilType || null,
      ph_level: formData.phLevel ? parseFloat(formData.phLevel) : null,
      nitrogen: formData.nitrogen ? parseFloat(formData.nitrogen) : null,
      phosphorus: formData.phosphorus ? parseFloat(formData.phosphorus) : null,
      potassium: formData.potassium ? parseFloat(formData.potassium) : null,
      organic_matter: formData.organicMatter
        ? parseFloat(formData.organicMatter)
        : null,
      moisture: formData.moisture ? parseFloat(formData.moisture) : null,
      cec: formData.cec ? parseFloat(formData.cec) : null,
    };

    const fieldData = {
      farm_id: farmId,
      name: formData.farmName,
      crop_name: formData.cropName,
      crop_variety: formData.variety,
      sowing_date: formData.sowingDate,
      irrigation_type: formData.irrigationType,
      growth_stage: formData.growthStage || null,
      field_coordinates: finalCoordinates,
      hectares: currentArea,
      location: fieldCentroid
        ? {
            lat: fieldCentroid.lat,
            lng: fieldCentroid.lng,
            accuracy: 0, // Centroid has no accuracy
            timestamp: Date.now(),
          }
        : userLocation
          ? {
              lat: userLocation.lat,
              lng: userLocation.lng,
              accuracy: userLocation.accuracy,
              timestamp: userLocation.timestamp,
            }
          : null,
      soil_data: soilData,
    };

    try {
      setIsSubmitting(true);
      const API_BASE_URL =
        import.meta.env.VITE_API_BASE_URL || "http://localhost:8000";
      const headers: Record<string, string> = {
        "Content-Type": "application/json",
      };
      const token = authUtils.getToken();
      if (token) {
        headers.Authorization = `Bearer ${token}`;
      }
      const response = await axios.post(
        `${API_BASE_URL}/api/add-field`,
        fieldData,
        { headers },
      );

      if (response.status === 200 || response.status === 201) {
        showPopup(
          "success",
          "Field added",
          response.data?.message || "Field added successfully.",
        );

        setFormData({
          farmName: "",
          cropName: "",
          variety: "",
          sowingDate: "",
          irrigationType: "",
          soilType: "",
          growthStage: "",
          phLevel: "",
          nitrogen: "",
          phosphorus: "",
          potassium: "",
          organicMatter: "",
          moisture: "",
          cec: "",
        });
        setDrawingPoints([]);
        setTempPolyline([]);
        setFieldCoordinates([]);
        setCurrentArea(0);
      } else {
        showPopup(
          "error",
          "Save failed",
          "Unexpected server response. Please try again.",
        );
      }
    } catch (error: unknown) {
      console.error("Error adding field:", error);
      const message = axios.isAxiosError(error)
        ? error.response?.data?.detail ||
          error.response?.data?.message ||
          error.message
        : error instanceof Error
          ? error.message
          : "Error adding field. Please try again.";
      showPopup("error", "Save failed", message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const getUserLocation = useCallback(() => {
    setIsGettingLocation(true);
    setLocationError(null);

    if (!navigator.geolocation) {
      setLocationError("Geolocation is not supported by your browser");
      setIsGettingLocation(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const location: UserLocation = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
          accuracy: position.coords.accuracy,
          timestamp: position.timestamp,
        };
        setUserLocation(location);
        setIsGettingLocation(false);
        setShowLocationPopup(true);

        if (
          centerOnUser &&
          mapRef.current &&
          !isNaN(location.lat) &&
          !isNaN(location.lng)
        ) {
          mapRef.current.flyTo([location.lat, location.lng], 15);
        }

        setTimeout(() => setShowLocationPopup(false), 5000);
      },
      (error) => {
        let errorMessage = "Failed to get your location";
        switch (error.code) {
          case error.PERMISSION_DENIED:
            errorMessage = "Location permission denied";
            break;
          case error.POSITION_UNAVAILABLE:
            errorMessage = "Location unavailable";
            break;
          case error.TIMEOUT:
            errorMessage = "Location request timed out";
            break;
        }
        setLocationError(errorMessage);
        setIsGettingLocation(false);
        setShowLocationPopup(true);
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0,
      },
    );
  }, [centerOnUser]);

  // Check mobile viewport
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  // Get user location on mount
  useEffect(() => {
    const loadFarmId = async () => {
      const farmId = authUtils.getFarmId();
      if (farmId && farmId.trim()) {
        setUserFarmId(farmId);
        return;
      }

      const token = authUtils.getToken();
      if (!token) return;

      const API_BASE_URL =
        import.meta.env.VITE_API_BASE_URL || "http://localhost:8000";
      const currentUser = await authUtils.getCurrentUser(API_BASE_URL);
      if (currentUser?.farm_id) {
        setUserFarmId(currentUser.farm_id);
        authUtils.setAuthData(
          token,
          authUtils.getUserId() || "",
          authUtils.getEmail() || "",
          authUtils.getName() || "",
          currentUser.farm_id,
          currentUser.farm_name || "",
        );
      }
    };

    loadFarmId();
    getUserLocation();
  }, [getUserLocation]);

  // Calculate area whenever drawing points change
  useEffect(() => {
    if (drawingPoints.length >= 3) {
      const area = calculateArea(drawingPoints);
      setCurrentArea(area);
    } else {
      setCurrentArea(0);
    }
  }, [drawingPoints]);

  // Clamp zoom to current base layer limits (Mapbox satellite vs OSM)
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    const ensureMaxZoom = () => {
      if (map.getZoom() > baseMapMaxZoom) {
        map.setZoom(baseMapMaxZoom);
      }
    };

    map.setMaxZoom(baseMapMaxZoom);
    map.options.maxZoom = baseMapMaxZoom;
    map.on("zoomend", ensureMaxZoom);

    return () => {
      map.off("zoomend", ensureMaxZoom);
    };
  }, [baseMapMaxZoom]);

  // Close search results when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as Element;
      if (!target.closest(".search-container")) {
        setShowSearchResults(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const searchPlaces = async (query: string) => {
    if (!query.trim()) return;

    setIsSearching(true);
    setShowSearchResults(true);

    try {
      // Using Nominatim (OpenStreetMap's geocoding service)
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=5&countrycodes=zw`,
      );
      const data = (await response.json()) as SearchResult[];
      setSearchResults(data);
    } catch (error) {
      console.error("Search failed:", error);
      setSearchResults([]);
    } finally {
      setIsSearching(false);
    }
  };

  const selectPlace = (place: SearchResult) => {
    const lat = parseFloat(place.lat);
    const lng = parseFloat(place.lon);

    // Only zoom if coordinates are valid
    if (!isNaN(lat) && !isNaN(lng) && mapRef.current) {
      mapRef.current.flyTo([lat, lng], 15);
    }

    setSearchQuery(place.display_name.split(",")[0]); // Show just the main place name
    setShowSearchResults(false);
    setSearchResults([]);
  };

  const calculateArea = (coordinates: [number, number][]): number => {
    if (coordinates.length < 3) return 0;

    // Use the first point as reference
    const points = [...coordinates];

    // Close the polygon for area calculation
    if (
      points[0][0] !== points[points.length - 1][0] ||
      points[0][1] !== points[points.length - 1][1]
    ) {
      points.push(points[0]);
    }

    let area = 0;
    const earthRadius = 6371000; // meters

    for (let i = 0; i < points.length - 1; i++) {
      const p1 = points[i];
      const p2 = points[i + 1];

      const lat1 = (p1[0] * Math.PI) / 180;
      const lon1 = (p1[1] * Math.PI) / 180;
      const lat2 = (p2[0] * Math.PI) / 180;
      const lon2 = (p2[1] * Math.PI) / 180;

      area += (lon2 - lon1) * (2 + Math.sin(lat1) + Math.sin(lat2));
    }

    area = (area * earthRadius * earthRadius) / 2;

    // Convert to hectares (1 hectare = 10,000 square meters)
    const areaInHectares = Math.abs(area) / 10000;

    return parseFloat(areaInHectares.toFixed(2));
  };

  const calculateFieldCentroid = (
    coordinates: [number, number][],
  ): { lat: number; lng: number } | null => {
    if (!coordinates || coordinates.length === 0) return null;

    let totalLat = 0;
    let totalLng = 0;

    coordinates.forEach(([lat, lng]) => {
      totalLat += lat;
      totalLng += lng;
    });

    return {
      lat: totalLat / coordinates.length,
      lng: totalLng / coordinates.length,
    };
  };

  const handlePointAdd = (lat: number, lng: number) => {
    if (!isDrawing) return;

    const newPoint: [number, number] = [lat, lng];
    const newPoints = [...drawingPoints, newPoint];
    setDrawingPoints(newPoints);
    setTempPolyline(newPoints);
  };

  const removeLastPoint = () => {
    if (drawingPoints.length > 0) {
      const newPoints = drawingPoints.slice(0, -1);
      setDrawingPoints(newPoints);
      setTempPolyline(newPoints);
    }
  };

  const handleDrawingComplete = () => {
    if (drawingPoints.length < 3) return;

    // Close the polygon
    const closedCoordinates = [...drawingPoints];
    if (
      drawingPoints.length > 0 &&
      (drawingPoints[0][0] !== drawingPoints[drawingPoints.length - 1][0] ||
        drawingPoints[0][1] !== drawingPoints[drawingPoints.length - 1][1])
    ) {
      closedCoordinates.push(drawingPoints[0]);
    }

    const area = calculateArea(closedCoordinates);

    const newFarm: FarmBoundary = {
      id: `farm_${Date.now()}`,
      name: formData.farmName || `Farm ${farms.length + 1}`,
      coordinates: closedCoordinates,
      area: area,
      cropType: formData.cropName,
      variety: formData.variety,
      plantingDate: formData.sowingDate,
      irrigationType: formData.irrigationType,
    };

    const farmWithIndices: FarmWithIndices = {
      ...newFarm,
      latestIndices: {
        farmId: newFarm.id,
        date: new Date().toISOString().split("T")[0],
        ndvi: 0.5,
        ndmi: 0.4,
        mndwi: 0.2,
        ndwi: 0.3,
        min: 0.3,
        max: 0.7,
        mean: 0.5,
        std: 0.15,
      },
    };

    setFarms([...farms, farmWithIndices]);
    onBoundaryChange?.(newFarm);
    if (onIndicesUpdate && farmWithIndices.latestIndices) {
      onIndicesUpdate(newFarm.id, farmWithIndices.latestIndices);
    }

    // Preserve completed boundary for submission
    setIsDrawing(false);
    setDrawingPoints(closedCoordinates);
    setTempPolyline([]);
    setFieldCoordinates(closedCoordinates);
    setCurrentArea(area);

    showPopup(
      "success",
      "Boundary created",
      `Farm boundary created! Area: ${area} hectares`,
    );
  };

  const beginDrawing = () => {
    setFieldCoordinates([]);
    setDrawingPoints([]);
    setTempPolyline([]);
    setCurrentArea(0);
    setIsDrawing(true);
  };

  const cancelDrawing = () => {
    setIsDrawing(false);
    setDrawingPoints([]);
    setTempPolyline([]);
    setFieldCoordinates([]);
    setCurrentArea(0);
  };

  const centerOnUserLocation = () => {
    if (userLocation && mapRef.current) {
      mapRef.current.flyTo([userLocation.lat, userLocation.lng], 17);
      setShowLocationPopup(false);
    }
  };

  const getIndexColorSafe = (value: number): string => {
    if (value > 0.6) return "#1a5e1a";
    if (value > 0.4) return "#2e8b2e";
    if (value > 0.3) return "#9acd32";
    if (value > 0.2) return "#ffff00";
    if (value > 0.1) return "#ffa500";
    return "#ff0000";
  };

  return (
    <div className="add-field-container">
      {popupMessage && (
        <PopupMessage
          type={popupMessage.type}
          title={popupMessage.title}
          message={popupMessage.message}
          onClose={closePopup}
          autoClose={false}
        />
      )}
      {/* Left Sidebar - Crop Details Form */}
      <div className="crop-details-sidebar">
        <div className="crop-details-content">
          <div className="crop-details-header">
            <h2>Add New Field</h2>
            <p>Enter crop details and draw boundary on map</p>
          </div>

          <form onSubmit={handleSubmit} className="crop-form">
            <div className="form-section">
              <h3>Field Data</h3>
              <div className="form-group">
                <label htmlFor="farmName">
                  <LucideIcons.MapPin size={16} /> Farm Name
                </label>
                <input
                  type="text"
                  id="farmName"
                  name="farmName"
                  value={formData.farmName}
                  onChange={handleInputChange}
                  placeholder="Enter farm name"
                  required
                />
              </div>

              <div className="form-group">
                <label htmlFor="cropName">
                  <LucideIcons.Sprout size={16} /> Crop Name
                </label>
                <input
                  type="text"
                  id="cropName"
                  name="cropName"
                  value={formData.cropName}
                  onChange={handleInputChange}
                  placeholder="Search or select crop"
                  list="cropOptions"
                  required
                />
                <datalist id="cropOptions">
                  {cropOptions.map((crop) => (
                    <option key={crop} value={crop} />
                  ))}
                </datalist>
              </div>

              <div className="form-group">
                <label htmlFor="variety">
                  <LucideIcons.Sprout size={16} /> Variety
                </label>
                <input
                  type="text"
                  id="variety"
                  name="variety"
                  value={formData.variety}
                  onChange={handleInputChange}
                  placeholder="Enter crop variety"
                  required
                />
              </div>

              <div className="form-group">
                <label htmlFor="sowingDate">
                  <LucideIcons.Calendar size={16} /> Planting Date
                </label>
                <input
                  type="date"
                  id="sowingDate"
                  name="sowingDate"
                  value={formData.sowingDate}
                  onChange={handleInputChange}
                  required
                />
              </div>

              <div className="form-group">
                <label htmlFor="irrigationType">
                  <LucideIcons.Droplets size={16} /> Type of Irrigation
                </label>
                <select
                  id="irrigationType"
                  name="irrigationType"
                  value={formData.irrigationType}
                  onChange={handleInputChange}
                  required
                >
                  <option value="">Select irrigation type</option>
                  {irrigationOptions.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>

              <div className="form-group">
                <label htmlFor="growthStage">
                  <LucideIcons.Sprout size={16} /> Growth Stage
                </label>
                <select
                  id="growthStage"
                  name="growthStage"
                  value={formData.growthStage}
                  onChange={handleInputChange}
                >
                  <option value="">Select growth stage</option>
                  {growthStageOptions.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="form-section">
              <h3>Soil Data</h3>
              <div className="form-group">
                <label htmlFor="soilType">
                  <LucideIcons.Layers size={16} /> Soil Texture
                </label>
                <select
                  id="soilType"
                  name="soilType"
                  value={formData.soilType}
                  onChange={handleInputChange}
                >
                  <option value="">Select soil texture</option>
                  {soilTypeOptions.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>

              <div className="form-group">
                <label htmlFor="phLevel">pH Level</label>
                <input
                  type="number"
                  step="0.1"
                  id="phLevel"
                  name="phLevel"
                  value={formData.phLevel}
                  onChange={handleInputChange}
                  placeholder="Enter pH level"
                />
              </div>

              <div className="form-group">
                <label htmlFor="nitrogen">Nitrogen (N)</label>
                <input
                  type="number"
                  step="0.01"
                  id="nitrogen"
                  name="nitrogen"
                  value={formData.nitrogen}
                  onChange={handleInputChange}
                  placeholder="Enter nitrogen"
                />
              </div>

              <div className="form-group">
                <label htmlFor="phosphorus">Phosphorus (P)</label>
                <input
                  type="number"
                  step="0.01"
                  id="phosphorus"
                  name="phosphorus"
                  value={formData.phosphorus}
                  onChange={handleInputChange}
                  placeholder="Enter phosphorus"
                />
              </div>

              <div className="form-group">
                <label htmlFor="potassium">Potassium (K)</label>
                <input
                  type="number"
                  step="0.01"
                  id="potassium"
                  name="potassium"
                  value={formData.potassium}
                  onChange={handleInputChange}
                  placeholder="Enter potassium"
                />
              </div>

              <div className="form-group">
                <label htmlFor="organicMatter">Organic Matter (%)</label>
                <input
                  type="number"
                  step="0.1"
                  id="organicMatter"
                  name="organicMatter"
                  value={formData.organicMatter}
                  onChange={handleInputChange}
                  placeholder="Enter organic matter"
                />
              </div>

              <div className="form-group">
                <label htmlFor="moisture">Moisture (%)</label>
                <input
                  type="number"
                  step="0.1"
                  id="moisture"
                  name="moisture"
                  value={formData.moisture}
                  onChange={handleInputChange}
                  placeholder="Enter moisture"
                />
              </div>

              <div className="form-group">
                <label htmlFor="cec">CEC</label>
                <input
                  type="number"
                  step="0.1"
                  id="cec"
                  name="cec"
                  value={formData.cec}
                  onChange={handleInputChange}
                  placeholder="Enter CEC"
                />
              </div>
            </div>

            <button
              type="submit"
              className="submit-button"
              disabled={isSubmitting}
            >
              <LucideIcons.Plus size={18} />
              {isSubmitting ? "Saving..." : "Add Field"}
            </button>
          </form>
        </div>
      </div>

      {/* Map Container */}
      <div className="map-wrapper">
        <div className="farm-map-container">
          {/* Map Controls Bar */}
          {showControls && (
            <div className="map-controls-bar">
              {/* Search Input */}
              <div
                className="search-container"
                style={{ position: "relative" }}
              >
                <input
                  type="text"
                  placeholder="Search places..."
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    if (e.target.value.trim()) {
                      searchPlaces(e.target.value);
                    } else {
                      setShowSearchResults(false);
                      setSearchResults([]);
                    }
                  }}
                  onFocus={() => {
                    if (searchResults.length > 0) {
                      setShowSearchResults(true);
                    }
                  }}
                  className="search-input"
                  style={{
                    padding: "8px 12px",
                    border: "1px solid #d1d5db",
                    borderRadius: "6px",
                    fontSize: "14px",
                    width: "200px",
                    marginRight: "8px",
                    outline: "none",
                    backgroundColor: "white",
                  }}
                />
                {isSearching && (
                  <LucideIcons.Loader2
                    size={16}
                    className="animate-spin"
                    style={{
                      position: "absolute",
                      right: "20px",
                      top: "50%",
                      transform: "translateY(-50%)",
                      color: "#6b7280",
                    }}
                  />
                )}
                {!isSearching && (
                  <LucideIcons.Search
                    size={16}
                    style={{
                      position: "absolute",
                      right: "20px",
                      top: "50%",
                      transform: "translateY(-50%)",
                      color: "#6b7280",
                    }}
                  />
                )}

                {/* Search Results Dropdown */}
                {showSearchResults && searchResults.length > 0 && (
                  <div
                    className="search-results"
                    style={{
                      position: "absolute",
                      top: "100%",
                      left: "0",
                      right: "8px",
                      backgroundColor: "white",
                      border: "1px solid #d1d5db",
                      borderRadius: "6px",
                      boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1)",
                      zIndex: 1000,
                      maxHeight: "200px",
                      overflowY: "auto",
                    }}
                  >
                    {searchResults.map((result, index) => (
                      <div
                        key={index}
                        onClick={() => selectPlace(result)}
                        style={{
                          padding: "8px 12px",
                          cursor: "pointer",
                          borderBottom:
                            index < searchResults.length - 1
                              ? "1px solid #e5e7eb"
                              : "none",
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.backgroundColor = "#f3f4f6";
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.backgroundColor = "white";
                        }}
                      >
                        <div style={{ fontWeight: "500", fontSize: "14px" }}>
                          {result.display_name.split(",")[0]}
                        </div>
                        <div style={{ fontSize: "12px", color: "#6b7280" }}>
                          {result.display_name.split(",").slice(1, 3).join(",")}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Location Button */}
              <button
                className={`control-button ${isGettingLocation ? "active" : ""}`}
                onClick={() => {
                  getUserLocation();
                  setShowLocationPopup(true);
                }}
                title="Get Location"
                disabled={isGettingLocation}
              >
                {isGettingLocation ? (
                  <LucideIcons.Loader2 size={20} className="animate-spin" />
                ) : (
                  <LucideIcons.MapPin size={20} />
                )}
              </button>

              {/* Base Map Toggle */}
              <button
                className={`control-button ${baseMap === "osm" ? "active" : ""}`}
                onClick={() => setBaseMap("osm")}
                title="OpenStreetMap"
              >
                <LucideIcons.Map size={20} />
              </button>

              <button
                className={`control-button ${baseMap === "satellite" ? "active" : ""}`}
                onClick={() => setBaseMap("satellite")}
                title="Satellite"
              >
                <LucideIcons.Satellite size={20} />
              </button>

              {/* Drawing Controls */}
              {editable && (
                <button
                  className={`control-button ${isDrawing ? "active" : ""}`}
                  onClick={() => (isDrawing ? cancelDrawing() : beginDrawing())}
                  title={isDrawing ? "Cancel Drawing" : "Draw Boundary"}
                >
                  <LucideIcons.PenTool size={20} />
                </button>
              )}
            </div>
          )}

          {/* Location Status Popup */}
          {showLocationPopup && (
            <div className="location-popup">
              <div className="location-popup-header">
                <span>Location Status</span>
                <button
                  onClick={() => setShowLocationPopup(false)}
                  style={{
                    background: "none",
                    border: "none",
                    cursor: "pointer",
                  }}
                >
                  <LucideIcons.X size={16} />
                </button>
              </div>
              <div className="location-popup-content">
                {locationError ? (
                  <>
                    <div className="location-error">
                      <LucideIcons.AlertCircle size={16} />
                      {locationError}
                    </div>
                    <button
                      onClick={getUserLocation}
                      style={{
                        width: "100%",
                        padding: "10px",
                        background: "#3b82f6",
                        color: "white",
                        border: "none",
                        borderRadius: "8px",
                        cursor: "pointer",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        gap: "8px",
                      }}
                    >
                      <LucideIcons.RefreshCw size={16} />
                      Retry
                    </button>
                  </>
                ) : userLocation ? (
                  <>
                    <div className="location-detail">
                      <span>Latitude:</span>
                      <strong>{userLocation.lat.toFixed(6)}</strong>
                    </div>
                    <div className="location-detail">
                      <span>Longitude:</span>
                      <strong>{userLocation.lng.toFixed(6)}</strong>
                    </div>
                    <div className="location-detail">
                      <span>Accuracy:</span>
                      <strong>±{Math.round(userLocation.accuracy)}m</strong>
                    </div>
                    <button
                      onClick={centerOnUserLocation}
                      style={{
                        width: "100%",
                        marginTop: "12px",
                        padding: "10px",
                        background: "#3b82f6",
                        color: "white",
                        border: "none",
                        borderRadius: "8px",
                        cursor: "pointer",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        gap: "8px",
                      }}
                    >
                      <LucideIcons.Crosshair size={16} />
                      Center on my location
                    </button>
                  </>
                ) : (
                  <button
                    onClick={getUserLocation}
                    style={{
                      width: "100%",
                      padding: "12px",
                      background: "#3b82f6",
                      color: "white",
                      border: "none",
                      borderRadius: "8px",
                      cursor: "pointer",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      gap: "8px",
                    }}
                  >
                    <LucideIcons.MapPin size={16} />
                    Get My Location
                  </button>
                )}
              </div>
            </div>
          )}

          {/* Drawing Status Bar */}
          {isDrawing && (
            <div className="drawing-status">
              <span className="points-badge">
                {drawingPoints.length} points
              </span>
              {currentArea > 0 && (
                <span className="area-badge">
                  <LucideIcons.Square
                    size={14}
                    style={{ marginRight: "4px" }}
                  />
                  {currentArea} ha
                </span>
              )}
              <div className="drawing-actions">
                <button
                  className="remove-button"
                  onClick={removeLastPoint}
                  disabled={drawingPoints.length === 0}
                  title="Remove last point"
                >
                  <LucideIcons.RotateCcw size={16} />
                  {!isMobile && "Remove Last"}
                </button>
                <button
                  className="complete-button"
                  onClick={handleDrawingComplete}
                  disabled={drawingPoints.length < 3}
                >
                  <LucideIcons.Check size={16} />
                  {!isMobile &&
                    (drawingPoints.length < 3 ? "Need 3+ points" : "Complete")}
                </button>
                <button className="cancel-button" onClick={cancelDrawing}>
                  <LucideIcons.X size={16} />
                  {!isMobile && "Cancel"}
                </button>
              </div>
            </div>
          )}

          {/* Map */}
          <Leaflet.MapContainer
            center={
              userLocation
                ? [userLocation.lat, userLocation.lng]
                : [40.7128, -74.006]
            }
            zoom={userLocation ? 15 : 13}
            minZoom={2}
            maxZoom={baseMapMaxZoom}
            className="h-full w-full"
            ref={mapRef}
          >
            {/* Base Layers */}
            {baseMap === "osm" ? (
              <Leaflet.TileLayer
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                maxZoom={19}
                maxNativeZoom={19}
              />
            ) : (
              <Leaflet.TileLayer
                url={googleSatelliteUrl}
                attribution='&copy; <a href="https://www.google.com/maps">Google Maps</a>'
                maxZoom={19}
                maxNativeZoom={19}
              />
            )}

            <MapClickHandler
              isDrawing={isDrawing}
              onPointAdd={handlePointAdd}
            />

            {userLocation && (
              <UserLocationMarker
                position={[userLocation.lat, userLocation.lng]}
                accuracy={userLocation.accuracy}
              />
            )}

            <Leaflet.FeatureGroup>
              {/* Existing Farms */}
              {farms.map((farm) => (
                <Leaflet.Polygon
                  key={farm.id}
                  positions={farm.coordinates}
                  pathOptions={{
                    color: farm.latestIndices
                      ? getIndexColorSafe(farm.latestIndices[selectedIndex])
                      : "#808080",
                    fillColor: farm.latestIndices
                      ? getIndexColorSafe(farm.latestIndices[selectedIndex])
                      : "#808080",
                    fillOpacity: 0.3,
                    weight: 2,
                  }}
                >
                  <Leaflet.Popup>
                    <div className="p-2" style={{ minWidth: "200px" }}>
                      <h3 className="font-semibold">{farm.name}</h3>
                      <p className="text-sm">Area: {farm.area} ha</p>
                      {farm.cropType && (
                        <p className="text-sm mt-1">Crop: {farm.cropType}</p>
                      )}
                      {farm.latestIndices && (
                        <p className="text-sm mt-2">
                          NDVI: {farm.latestIndices.ndvi.toFixed(3)}
                        </p>
                      )}
                    </div>
                  </Leaflet.Popup>
                </Leaflet.Polygon>
              ))}

              {/* Drawing Elements */}
              {isDrawing && drawingPoints.length > 0 && (
                <>
                  {drawingPoints.map((point, index) => (
                    <Leaflet.Circle
                      key={`point-${index}`}
                      center={point}
                      radius={8}
                      pathOptions={{
                        color: index === 0 ? "#10b981" : "#ef4444",
                        fillColor: index === 0 ? "#10b981" : "#ef4444",
                        fillOpacity: 0.7,
                        weight: 2,
                      }}
                    />
                  ))}

                  {tempPolyline.length > 1 && (
                    <Leaflet.Polyline
                      positions={tempPolyline}
                      pathOptions={{
                        color: "#3b82f6",
                        weight: 3,
                        dashArray: "5, 5",
                        opacity: 0.8,
                      }}
                    />
                  )}

                  {drawingPoints.length >= 2 && (
                    <Leaflet.Polyline
                      positions={[
                        drawingPoints[drawingPoints.length - 1],
                        drawingPoints[0],
                      ]}
                      pathOptions={{
                        color: "#ef4444",
                        weight: 2,
                        dashArray: "3, 3",
                        opacity: 0.6,
                      }}
                    />
                  )}
                </>
              )}
            </Leaflet.FeatureGroup>
          </Leaflet.MapContainer>
        </div>
      </div>
    </div>
  );
};

export default AddField;
