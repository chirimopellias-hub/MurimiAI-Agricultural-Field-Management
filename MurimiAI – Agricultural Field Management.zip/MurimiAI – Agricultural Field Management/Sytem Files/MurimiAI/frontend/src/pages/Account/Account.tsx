// Account.tsx
import React, { useEffect, useState } from "react";
import * as LucideIcons from "lucide-react";
import authUtils from "../../utils/authUtils";
import "./Account.css";

interface UserAccountData {
  fullName: string;
  email: string;
  phone: string;
  preferredLanguage: string;
}

const getInitialUserData = (): UserAccountData => {
  return {
    fullName: localStorage.getItem("userName") || "John Doe",
    email: localStorage.getItem("userEmail") || "john.doe@example.com",
    phone: localStorage.getItem("userPhone") || "+254 712 345 678",
    preferredLanguage: localStorage.getItem("preferredLanguage") || "English",
  };
};

const Account: React.FC = () => {
  const [accountData, setAccountData] =
    useState<UserAccountData>(getInitialUserData());
  const [passwordData, setPasswordData] = useState({
    oldPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isFetching, setIsFetching] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string>("");
  const [showPasswordForm, setShowPasswordForm] = useState<boolean>(false);
  const [notification, setNotification] = useState<{
    type: "success" | "error";
    message: string;
  } | null>(null);
  const [profileStatus, setProfileStatus] = useState<{
    type: "success" | "error";
    message: string;
  } | null>(null);
  const [passwordStatus, setPasswordStatus] = useState<{
    type: "success" | "error";
    message: string;
  } | null>(null);
  const [showSuccessCheckmark, setShowSuccessCheckmark] =
    useState<boolean>(false);

  const API_BASE_URL =
    import.meta.env.VITE_API_BASE_URL || "http://localhost:8000";

  const showNotification = (type: "success" | "error", message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 3000);
  };

  const showSuccessAnimation = () => {
    setShowSuccessCheckmark(true);
    setTimeout(() => setShowSuccessCheckmark(false), 2000);
  };

  const isPasswordMismatch =
    passwordData.confirmPassword.length > 0 &&
    passwordData.newPassword !== passwordData.confirmPassword;

  useEffect(() => {
    const loadCurrentUser = async () => {
      setIsFetching(true);
      setStatusMessage("Loading account details...");

      const currentUser = await authUtils.getCurrentUser(API_BASE_URL);
      if (currentUser) {
        setAccountData({
          fullName: currentUser.name || getInitialUserData().fullName,
          email: currentUser.email || getInitialUserData().email,
          phone: currentUser.phone || getInitialUserData().phone,
          preferredLanguage:
            currentUser.language || getInitialUserData().preferredLanguage,
        });
      }

      setIsFetching(false);
      setStatusMessage("");
    };

    loadCurrentUser();
  }, [API_BASE_URL]);

  const handleAccountUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setProfileStatus(null);
    setIsLoading(true);
    setStatusMessage("Updating profile...");

    try {
      const response = await authUtils.authenticatedFetch(
        `${API_BASE_URL}/api/auth/user`,
        {
          method: "PATCH",
          body: JSON.stringify({
            name: accountData.fullName,
            email: accountData.email,
            phone: accountData.phone,
            language: accountData.preferredLanguage,
          }),
        },
      );

      if (!response.ok) {
        const errorData = await response.json().catch(() => null);
        throw new Error(errorData?.detail || "Unable to update profile");
      }

      localStorage.setItem("userName", accountData.fullName);
      localStorage.setItem("userEmail", accountData.email);
      localStorage.setItem("userPhone", accountData.phone);
      localStorage.setItem("preferredLanguage", accountData.preferredLanguage);

      const token = authUtils.getToken();
      const userId = authUtils.getUserId();
      const farmId = authUtils.getFarmId() || "";
      const farmName = authUtils.getFarmName() || "";
      if (token && userId) {
        authUtils.setAuthData(
          token,
          userId,
          accountData.email,
          accountData.fullName,
          farmId,
          farmName,
        );
      }

      showNotification("success", "Account details updated successfully!");
      setProfileStatus({
        type: "success",
        message: "Profile updated successfully.",
      });
      showSuccessAnimation();
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to update profile";
      showNotification("error", message);
      setProfileStatus({ type: "error", message });
    } finally {
      setIsLoading(false);
      setStatusMessage("");
    }
  };

  const handlePasswordUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordStatus(null);

    if (!passwordData.oldPassword) {
      showNotification("error", "Current password is required");
      return;
    }

    if (passwordData.newPassword !== passwordData.confirmPassword) {
      showNotification(
        "error",
        "New password and confirm password do not match!",
      );
      return;
    }

    if (passwordData.newPassword.length < 6) {
      showNotification("error", "Password must be at least 6 characters long!");
      return;
    }

    setIsLoading(true);
    setStatusMessage("Updating password...");

    try {
      const response = await authUtils.authenticatedFetch(
        `${API_BASE_URL}/api/auth/user/password`,
        {
          method: "POST",
          body: JSON.stringify({
            old_password: passwordData.oldPassword,
            new_password: passwordData.newPassword,
            confirm_password: passwordData.confirmPassword,
          }),
        },
      );

      if (!response.ok) {
        const errorData = await response.json().catch(() => null);
        throw new Error(errorData?.detail || "Unable to update password");
      }

      setPasswordData({
        oldPassword: "",
        newPassword: "",
        confirmPassword: "",
      });
      setShowPasswordForm(false);
      showNotification("success", "Password updated successfully!");
      setPasswordStatus({
        type: "success",
        message: "Password updated successfully.",
      });
      showSuccessAnimation();
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to update password";
      showNotification("error", message);
      setPasswordStatus({ type: "error", message });
    } finally {
      setIsLoading(false);
      setStatusMessage("");
    }
  };

  const languages = [
    "English",
    "Swahili",
    "Kikuyu",
    "Luo",
    "Kalenjin",
    "French",
  ];

  return (
    <div className="account-page">
      {(isFetching || isLoading) && statusMessage && (
        <div className="account-loading-overlay">
          <div className="account-loading-card">
            <div className="account-loading-spinner" />
            <p>{statusMessage}</p>
          </div>
        </div>
      )}

      {notification && (
        <div
          className={`account-notification account-notification-${notification.type}`}
        >
          <span>{notification.message}</span>
          <button onClick={() => setNotification(null)}>×</button>
        </div>
      )}

      {showSuccessCheckmark && (
        <div className="account-success-overlay">
          <div className="account-success-animation">
            <LucideIcons.CheckCircle size={48} />
          </div>
        </div>
      )}

      <div className="account-container">
        {/* Main Content Grid */}
        <div className="account-grid">
          {/* Account Information Section */}
          <div className="account-section">
            <div className="account-section-header">
              <div className="account-section-title-wrapper">
                <LucideIcons.User size={20} strokeWidth={2} />
                <h2 className="account-section-title">Profile Information</h2>
              </div>
              <p className="account-section-description">
                Update your personal details and contact information
              </p>
            </div>

            <form onSubmit={handleAccountUpdate} className="account-form">
              <div className="account-form-group">
                <label className="account-label">
                  <LucideIcons.User size={16} />
                  Full Name
                </label>
                <input
                  type="text"
                  className="account-input"
                  value={accountData.fullName}
                  onChange={(e) =>
                    setAccountData({ ...accountData, fullName: e.target.value })
                  }
                  placeholder="Enter your full name"
                  required
                />
              </div>

              <div className="account-form-group">
                <label className="account-label">
                  <LucideIcons.Mail size={16} />
                  Email Address
                </label>
                <input
                  type="email"
                  className="account-input"
                  value={accountData.email}
                  onChange={(e) =>
                    setAccountData({ ...accountData, email: e.target.value })
                  }
                  placeholder="Enter your email address"
                  required
                />
              </div>

              <div className="account-form-group">
                <label className="account-label">
                  <LucideIcons.Phone size={16} />
                  Phone Number
                </label>
                <input
                  type="tel"
                  className="account-input"
                  value={accountData.phone}
                  onChange={(e) =>
                    setAccountData({ ...accountData, phone: e.target.value })
                  }
                  placeholder="Enter your phone number"
                />
              </div>

              <div className="account-form-group">
                <label className="account-label">
                  <LucideIcons.Globe size={16} />
                  Preferred Language
                </label>
                <div className="account-select-wrapper">
                  <select
                    className="account-select"
                    value={accountData.preferredLanguage}
                    onChange={(e) =>
                      setAccountData({
                        ...accountData,
                        preferredLanguage: e.target.value,
                      })
                    }
                  >
                    {languages.map((lang) => (
                      <option key={lang} value={lang}>
                        {lang}
                      </option>
                    ))}
                  </select>
                  <LucideIcons.ChevronDown
                    size={16}
                    className="account-select-icon"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="account-update-btn"
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <div className="account-spinner"></div>
                    Updating...
                  </>
                ) : (
                  <>
                    <LucideIcons.Save size={18} />
                    Update Profile
                  </>
                )}
              </button>
              {profileStatus && (
                <div
                  className={`account-form-status account-form-status-${profileStatus.type}`}
                >
                  {profileStatus.message}
                </div>
              )}
            </form>
          </div>

          {/* Security Section */}
          <div className="account-section">
            <div className="account-section-header">
              <div className="account-section-title-wrapper">
                <LucideIcons.Lock size={20} strokeWidth={2} />
                <h2 className="account-section-title">Security</h2>
              </div>
              <p className="account-section-description">
                Manage your password and security settings
              </p>
            </div>

            {!showPasswordForm ? (
              <div className="account-security-info">
                <div className="account-info-row">
                  <div className="account-info-icon">
                    <LucideIcons.Shield size={20} />
                  </div>
                  <div className="account-info-content">
                    <h4>Password Protection</h4>
                    <p>Last updated: {new Date().toLocaleDateString()}</p>
                  </div>
                  <button
                    onClick={() => {
                      setShowPasswordForm(true);
                      setPasswordStatus(null);
                    }}
                    className="account-change-password-btn"
                  >
                    <LucideIcons.Edit2 size={14} />
                    Change
                  </button>
                </div>

                <div className="account-security-tips">
                  <div className="account-tip">
                    <LucideIcons.CheckCircle size={14} />
                    <span>Use at least 8 characters</span>
                  </div>
                  <div className="account-tip">
                    <LucideIcons.CheckCircle size={14} />
                    <span>Include numbers and special characters</span>
                  </div>
                  <div className="account-tip">
                    <LucideIcons.CheckCircle size={14} />
                    <span>Avoid common passwords</span>
                  </div>
                </div>
              </div>
            ) : (
              <form onSubmit={handlePasswordUpdate} className="account-form">
                <div className="account-form-group">
                  <label className="account-label">Current Password</label>
                  <input
                    type="password"
                    className="account-input"
                    value={passwordData.oldPassword}
                    onChange={(e) =>
                      setPasswordData({
                        ...passwordData,
                        oldPassword: e.target.value,
                      })
                    }
                    placeholder="Enter current password"
                    required
                  />
                </div>

                <div className="account-form-group">
                  <label className="account-label">New Password</label>
                  <input
                    type="password"
                    className="account-input"
                    value={passwordData.newPassword}
                    onChange={(e) =>
                      setPasswordData({
                        ...passwordData,
                        newPassword: e.target.value,
                      })
                    }
                    placeholder="Enter new password"
                    required
                  />
                </div>

                <div className="account-form-group">
                  <label className="account-label">Confirm New Password</label>
                  <input
                    type="password"
                    className={`account-input ${
                      isPasswordMismatch ? "account-input-error" : ""
                    }`}
                    value={passwordData.confirmPassword}
                    onChange={(e) =>
                      setPasswordData({
                        ...passwordData,
                        confirmPassword: e.target.value,
                      })
                    }
                    placeholder="Confirm new password"
                    required
                  />
                  {isPasswordMismatch && (
                    <p className="account-field-error">
                      Passwords do not match.
                    </p>
                  )}
                </div>

                <div className="account-password-actions">
                  <button
                    type="button"
                    onClick={() => setShowPasswordForm(false)}
                    className="account-cancel-btn"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="account-update-btn"
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <>
                        <div className="account-spinner"></div>
                        Updating...
                      </>
                    ) : (
                      <>
                        <LucideIcons.Lock size={18} />
                        Update Password
                      </>
                    )}
                  </button>
                </div>
                {passwordStatus && (
                  <div
                    className={`account-form-status account-form-status-${passwordStatus.type}`}
                  >
                    {passwordStatus.message}
                  </div>
                )}
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Account;
