import React, { useState, useEffect, useMemo, useRef } from "react";
import {
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
} from "recharts";
import {
  MapContainer,
  Marker,
  Popup,
  TileLayer,
  useMap,
  Polygon,
} from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";
import * as LucideIcons from "lucide-react";
import "./MurimiAIAnalytics.css";
import { authUtils } from "../../utils/authUtils"; // Adjust import path as needed

// @ts-expect-error - Leaflet type issue with icon loading
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl:
    "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png",
  iconUrl:
    "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png",
  shadowUrl:
    "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png",
});

// ==================== Types ====================
interface FieldListItem {
  id: string;
  name: string;
  crop_name?: string;
  hectares?: number;
  latitude?: number | null;
  longitude?: number | null;
  field_coordinates?: [number, number][] | null;
}

interface FieldDetail {
  field_id: string;
  name: string;
  crop_name: string;
  crop_variety: string;
  hectares: number;
  sowing_date: string;
  growth_stage: string;
  field_coordinates?: [number, number][] | null;
  location?: { latitude: number; longitude: number } | null;
}

interface SoilData {
  nitrogen: number | null;
  phosphorus: number | null;
  potassium: number | null;
  ph_level: number | null;
  organic_matter: number | null;
}

interface FieldDetailResponse {
  field: FieldDetail;
  soil: SoilData;
  ndvi?: NDVIAnalysis;
}

interface NDVIHistoryPoint {
  date: string;
  ndvi: number;
}

interface NDVIAnalysis {
  average: number | null;
  status: string;
  color: string;
  ndvi_tile_url: string | null;
  sentinel_tile_url: string | null;
  history: NDVIHistoryPoint[];
  alerts: string[];
  recommendation?: string;
}

interface NPKData {
  available: { n: number; p: number; k: number };
  required: { n: number; p: number; k: number };
  expectedYield: number;
}

interface NDVIDataPoint {
  date: string;
  ndvi: number;
  evi: number;
  ndwi: number;
}

interface TooltipPayload {
  name: string;
  value: number;
  color: string;
  dataKey?: string;
}

// ==================== Helper Functions ====================
const calculateAgeDays = (plantingDate: string, currentDate: Date): number => {
  return Math.floor(
    (currentDate.getTime() - new Date(plantingDate).getTime()) /
      (1000 * 60 * 60 * 24),
  );
};

// ==================== Sub‑Components (original styling) ====================
const CustomTooltip: React.FC<{
  active?: boolean;
  payload?: TooltipPayload[];
  label?: string;
}> = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="ma-tooltip">
        <p className="ma-tooltip-label">{label}</p>
        {payload.map((entry, index) => (
          <div key={index} className="ma-tooltip-item">
            <div
              className="ma-tooltip-dot"
              style={{ backgroundColor: entry.color }}
            />
            <span>{entry.name}:</span>
            <span className="ma-tooltip-value">{entry.value}</span>
          </div>
        ))}
      </div>
    );
  }
  return null;
};

const FieldSelector: React.FC<{
  fields: FieldListItem[];
  selectedField: string;
  onSelectField: (id: string) => void;
}> = ({ fields, selectedField, onSelectField }) => (
  <div className="ma-field-selector">
    <label className="ma-field-label">Select Field</label>
    <select
      value={selectedField}
      onChange={(e) => onSelectField(e.target.value)}
      className="ma-field-select"
    >
      {fields.map((field) => (
        <option key={field.id} value={field.id}>
          {field.name} - {field.crop_name || "N/A"} ({field.hectares ?? "?"}{" "}
          acres)
        </option>
      ))}
    </select>
  </div>
);

const MapSection: React.FC<{
  fields: FieldListItem[];
  selectedField: string;
  onSelectField: (id: string) => void;
  currentNdvi: number;
  ndviTileUrl?: string | null;
  sentinelTileUrl?: string | null;
}> = ({ fields, selectedField, onSelectField, currentNdvi, ndviTileUrl }) => {
  const baseMap = "satellite";
  const baseMapMaxZoom = 18;
  const googleMapsKey = import.meta.env.VITE_GOOGLE_MAPS_KEY as string;
  const googleSatelliteUrl = googleMapsKey
    ? `https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}&key=${googleMapsKey}`
    : "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}";

  const selectedEntry = fields.find((field) => field.id === selectedField);
  const center: [number, number] =
    selectedEntry?.field_coordinates &&
    selectedEntry.field_coordinates.length > 0
      ? [
          selectedEntry.field_coordinates[0][0],
          selectedEntry.field_coordinates[0][1],
        ]
      : selectedEntry?.latitude != null && selectedEntry?.longitude != null
        ? [selectedEntry.latitude, selectedEntry.longitude]
        : [-1.291389, 36.821223];

  const visibleFields = selectedField
    ? fields.filter((f) => f.id === selectedField)
    : fields;

  const getNdviColor = (ndvi: number) =>
    ndvi >= 0.7
      ? "#10b981"
      : ndvi >= 0.5
        ? "#f59e0b"
        : ndvi >= 0.3
          ? "#ef4444"
          : "#b91c1c";

  // Diagnostics: help confirm what's being rendered
  console.log("MapSection visibleFields:", visibleFields);

  // Helper component: invalidates map size after mount/update to ensure tiles render
  const MapResizer: React.FC<{ trigger: string | number }> = ({ trigger }) => {
    const map = useMap();
    useEffect(() => {
      // allow layout to settle
      const t = setTimeout(() => {
        try {
          map.invalidateSize();
        } catch (e) {
          console.warn("Map invalidateSize failed:", e);
        }
      }, 200);
      return () => clearTimeout(t);
    }, [map, trigger]);
    return null;
  };

  const mapRef = useRef<L.Map | null>(null);

  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    map.setMaxZoom(baseMapMaxZoom);

    const handleZoom = () => {
      if (map.getZoom() > baseMapMaxZoom) {
        map.setZoom(baseMapMaxZoom);
      }
    };

    map.on("zoom", handleZoom);
    return () => {
      map.off("zoom", handleZoom);
    };
  }, [baseMapMaxZoom]);

  // When selectedField changes, center/fly the map to that field's coordinates
  useEffect(() => {
    if (!mapRef.current) return;
    const target = visibleFields.length > 0 ? visibleFields[0] : null;
    if (target && target.latitude != null && target.longitude != null) {
      try {
        mapRef.current.flyTo([target.latitude, target.longitude], 13);
      } catch (e) {
        console.warn("Map flyTo failed:", e);
      }
    }
    // update map info when selection changes
    try {
      const size = mapRef.current.getSize();
      const centerNow = mapRef.current.getCenter();
      console.log("Map created size:", size, "center:", centerNow);
    } catch (e) {
      console.warn("Failed to read map size/center:", e);
    }
  }, [selectedField, visibleFields]);

  return (
    <div className="ma-map-container">
      <MapContainer
        center={center}
        zoom={13}
        maxZoom={baseMapMaxZoom}
        zoomControl={true}
        className="ma-map"
        style={{ height: "400px" }}
        ref={mapRef}
      >
        <MapResizer
          trigger={`${visibleFields.length}-${selectedField || ""}-${baseMap}`}
        />
        <TileLayer
          key={`google-${baseMap}`}
          url={googleSatelliteUrl}
          attribution='&copy; <a href="https://www.google.com/maps">Google Maps</a>'
          maxZoom={baseMapMaxZoom}
          maxNativeZoom={18}
          crossOrigin="anonymous"
        />
        {ndviTileUrl && (
          <TileLayer
            key={`ndvi-${ndviTileUrl}`}
            url={ndviTileUrl}
            opacity={0.55}
            zIndex={650}
            crossOrigin="anonymous"
          />
        )}
        {visibleFields.map((field) => {
          if (field.latitude == null || field.longitude == null) return null;

          return (
            <React.Fragment key={field.id}>
              <Marker
                position={[field.latitude, field.longitude]}
                eventHandlers={{ click: () => onSelectField(field.id) }}
              >
                <Popup>
                  <div className="ma-popup">
                    <h3>{field.name}</h3>
                    <p>{field.crop_name || "Unknown crop"}</p>
                    <div>Area: {field.hectares ?? "?"} ac</div>
                  </div>
                </Popup>
              </Marker>
              {field.field_coordinates &&
                field.field_coordinates.length > 2 && (
                  <Polygon
                    pathOptions={{
                      color:
                        field.id === selectedField
                          ? getNdviColor(currentNdvi)
                          : "#6b7280",
                      fillColor:
                        field.id === selectedField
                          ? getNdviColor(currentNdvi)
                          : "#9ca3af",
                      fillOpacity: field.id === selectedField ? 0.25 : 0.12,
                      weight: 2,
                    }}
                    positions={field.field_coordinates}
                  />
                )}
            </React.Fragment>
          );
        })}
      </MapContainer>
    </div>
  );
};

const CropSoilCard: React.FC<{
  fieldDetail: FieldDetail;
  soilData: SoilData;
}> = ({ fieldDetail, soilData }) => {
  const ageDays = useMemo(
    () =>
      fieldDetail.sowing_date
        ? calculateAgeDays(fieldDetail.sowing_date, new Date())
        : 0,
    [fieldDetail.sowing_date],
  );

  const npkData: NPKData = {
    available: {
      n: soilData.nitrogen ?? 0,
      p: soilData.phosphorus ?? 0,
      k: soilData.potassium ?? 0,
    },
    required: { n: 20, p: 10, k: 10 }, // still hardcoded; you can fetch or compute later
    expectedYield: 5,
  };

  return (
    <div className="ma-card ma-full-width">
      <div className="ma-card-header">
        <LucideIcons.Sprout className="ma-card-icon" />
        <h3>Crop & Soil Nutrition Data - {fieldDetail.name}</h3>
      </div>

      <div className="ma-crop-soil-grid">
        {/* Crop Health Section */}
        <div className="ma-crop-health-section">
          <h4 className="ma-sub-section-title">Crop Data</h4>
          <div className="ma-stats-grid">
            <div>
              <span>Crop:</span>
              <strong>{fieldDetail.crop_name}</strong>
            </div>
            <div>
              <span>Variety:</span>
              <strong>{fieldDetail.crop_variety}</strong>
            </div>
            <div>
              <span>Age:</span>
              <strong>{ageDays} days</strong>
            </div>
            <div>
              <span>Area:</span>
              <strong>{fieldDetail.hectares} acres</strong>
            </div>
            <div>
              <span>Planting:</span>
              <strong>{fieldDetail.sowing_date}</strong>
            </div>
            <div>
              <span>Growth Stage:</span>
              <strong>{fieldDetail.growth_stage}</strong>
            </div>
          </div>
        </div>

        {/* Soil Nutrition Section */}
        <div className="ma-soil-nutrition-section">
          <h4 className="ma-sub-section-title">Soil Nutrition</h4>
          <div className="ma-npk-grid">
            <div className="ma-npk-item">
              <span>Nitrogen (N)</span>
              <strong>{npkData.available.n} kg</strong>
              <small>/ {npkData.required.n} kg required</small>
              <div className="ma-npk-bar">
                <div
                  className="ma-npk-fill"
                  style={{
                    width: `${Math.min(100, (npkData.available.n / npkData.required.n) * 100)}%`,
                    backgroundColor: "#10b981",
                  }}
                />
              </div>
            </div>
            <div className="ma-npk-item">
              <span>Phosphorus (P)</span>
              <strong>{npkData.available.p} kg</strong>
              <small>/ {npkData.required.p} kg required</small>
              <div className="ma-npk-bar">
                <div
                  className="ma-npk-fill"
                  style={{
                    width: `${Math.min(100, (npkData.available.p / npkData.required.p) * 100)}%`,
                    backgroundColor: "#3b82f6",
                  }}
                />
              </div>
            </div>
            <div className="ma-npk-item">
              <span>Potassium (K)</span>
              <strong>{npkData.available.k} kg</strong>
              <small>/ {npkData.required.k} kg required</small>
              <div className="ma-npk-bar">
                <div
                  className="ma-npk-fill"
                  style={{
                    width: `${Math.min(100, (npkData.available.k / npkData.required.k) * 100)}%`,
                    backgroundColor: "#f59e0b",
                  }}
                />
              </div>
            </div>
          </div>
          <div className="ma-soil-details">
            <div className="ma-soil-detail-item">
              <span>pH Level:</span>
              <strong>{soilData.ph_level ?? "N/A"}</strong>
            </div>
            <div className="ma-soil-detail-item">
              <span>Organic Matter:</span>
              <strong>
                {soilData.organic_matter != null
                  ? `${soilData.organic_matter}%`
                  : "N/A"}
              </strong>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const NDVICard: React.FC<{ analysis: NDVIAnalysis | null }> = ({
  analysis,
}) => {
  const chartData = analysis?.history ?? [];
  const latestNDVI =
    chartData[chartData.length - 1] ??
    ({ date: "", ndvi: 0, evi: 0, ndwi: 0 } as NDVIDataPoint);
  const averageNDVI = analysis?.average ?? latestNDVI.ndvi;
  const ndviColor =
    averageNDVI >= 0.7
      ? "#10b981"
      : averageNDVI >= 0.5
        ? "#f59e0b"
        : averageNDVI >= 0.3
          ? "#ef4444"
          : "#b91c1c";

  const ndviStatus =
    analysis?.status ??
    (latestNDVI.ndvi >= 0.7
      ? "Excellent"
      : latestNDVI.ndvi >= 0.5
        ? "Good"
        : latestNDVI.ndvi >= 0.3
          ? "Moderate"
          : "Poor");

  return (
    <div className="ma-card ma-full-width">
      <div className="ma-card-header">
        <LucideIcons.Leaf className="ma-card-icon" />
        <h3>Vegetation Health (NDVI)</h3>
      </div>

      <ResponsiveContainer width="100%" height={250}>
        <AreaChart data={chartData}>
          <defs>
            <linearGradient id="colorNDVI" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor={ndviColor} stopOpacity={0.8} />
              <stop offset="95%" stopColor={ndviColor} stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
          <XAxis dataKey="date" tick={{ fill: "#9ca3af", fontSize: 12 }} />
          <YAxis domain={[0, 1]} tick={{ fill: "#9ca3af", fontSize: 12 }} />
          <Tooltip content={<CustomTooltip />} />
          <Area
            type="monotone"
            dataKey="ndvi"
            stroke={ndviColor}
            fill="url(#colorNDVI)"
            strokeWidth={2}
          />
        </AreaChart>
      </ResponsiveContainer>

      <div className="ma-current-values">
        <h4 className="ma-values-title">NDVI Summary</h4>
        <div className="ma-values-grid">
          <div className="ma-value-item">
            <label className="ma-value-label">Average NDVI</label>
            <input
              type="text"
              value={averageNDVI.toFixed(2)}
              readOnly
              className="ma-value-input"
            />
          </div>
          <div className="ma-value-item">
            <label className="ma-value-label">Latest NDVI</label>
            <input
              type="text"
              value={latestNDVI.ndvi.toFixed(2)}
              readOnly
              className="ma-value-input"
            />
          </div>
          <div className="ma-value-item">
            <span
              className={`ma-value-status ${
                ndviStatus === "Excellent"
                  ? "excellent"
                  : ndviStatus === "Good"
                    ? "good"
                    : ndviStatus === "Moderate"
                      ? "moderate"
                      : "poor"
              }`}
            >
              {ndviStatus}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

const RecommendationSection: React.FC<{
  analysis: NDVIAnalysis | null;
  fieldDetail: FieldDetail;
}> = ({ analysis, fieldDetail }) => {
  const history = analysis?.history ?? [];
  const latestNDVI =
    history[history.length - 1] ??
    ({ date: "", ndvi: 0, evi: 0, ndwi: 0 } as NDVIDataPoint);
  const status =
    analysis?.status ??
    (latestNDVI.ndvi >= 0.7
      ? "Excellent"
      : latestNDVI.ndvi >= 0.5
        ? "Good"
        : latestNDVI.ndvi >= 0.3
          ? "Moderate"
          : "Poor");
  const averageNDVI = analysis?.average ?? latestNDVI.ndvi;
  const ageDays = fieldDetail.sowing_date
    ? calculateAgeDays(fieldDetail.sowing_date, new Date())
    : 0;

  const getNDVIRecommendation = () => {
    const cropInfo = fieldDetail.crop_name
      ? `${fieldDetail.crop_name} crop, age ${ageDays} days`
      : `Field age ${ageDays} days`;
    const alertsText = analysis?.alerts?.length
      ? ` Alerts: ${analysis.alerts.join(" ")}`
      : "";

    if (status === "Excellent") {
      return `Excellent canopy condition for ${cropInfo}. Average NDVI is ${averageNDVI.toFixed(2)} and the latest NDVI is ${latestNDVI.ndvi.toFixed(2)}.${alertsText} Keep current management practices and continue weekly monitoring.`;
    } else if (status === "Good") {
      return `Good crop performance for ${cropInfo}. Average NDVI is ${averageNDVI.toFixed(2)} and latest NDVI is ${latestNDVI.ndvi.toFixed(2)}.${alertsText} Slight irrigation or nutrient tuning is recommended.`;
    } else if (status === "Moderate") {
      return `Moderate vegetative health for ${cropInfo}. Average NDVI is ${averageNDVI.toFixed(2)} and latest NDVI is ${latestNDVI.ndvi.toFixed(2)}.${alertsText} Inspect for stress, pests, or nutrient deficiencies and act quickly.`;
    }
    return `Poor crop health detected for ${cropInfo}. Average NDVI is ${averageNDVI.toFixed(2)} and latest NDVI is ${latestNDVI.ndvi.toFixed(2)}.${alertsText} Perform a field inspection immediately and prioritize corrective action.`;
  };

  return (
    <div className="ma-card ma-full-width ma-overlay-card">
      <div className="ma-card-header">
        <LucideIcons.TrendingUp className="ma-card-icon" />
        <h3>Farm Analysis & Recommendations</h3>
      </div>

      <div className="ma-recommendation-paragraph">
        <h4 className="ma-section-title">
          <LucideIcons.Leaf size={18} className="ma-section-icon" />
          NDVI Analysis - Vegetation Health
        </h4>
        <div className="ma-metrics">
          <span className="ma-metric-badge">
            Average NDVI: {averageNDVI.toFixed(2)}
          </span>
          <span className={`ma-status-${status.toLowerCase()}`}>
            Status: {status}
          </span>
        </div>
        {analysis?.alerts?.length ? (
          <div className="ma-alerts-summary">
            <strong>Alerts:</strong>
            <ul className="ma-alert-list">
              {analysis.alerts.map((alert, index) => (
                <li key={index} className="ma-alert-item">
                  {alert}
                </li>
              ))}
            </ul>
          </div>
        ) : null}
        <p className="ma-recommendation-text">{getNDVIRecommendation()}</p>
      </div>

      <div className="ma-recommendation-paragraph">
        <h4 className="ma-section-title">
          <LucideIcons.Leaf size={18} className="ma-section-icon" />
          Smart Recommendations
        </h4>
        <p className="ma-recommendation-text">
          {analysis?.recommendation ?? getNDVIRecommendation()}
        </p>
      </div>
    </div>
  );
};

// ==================== Main Component ====================
const API_BASE = "http://localhost:8000";

export default function MurimiAIAnalytics() {
  const [fields, setFields] = useState<FieldListItem[]>([]);
  const [selectedField, setSelectedField] = useState<string>("");
  const [fieldDetail, setFieldDetail] = useState<FieldDetail | null>(null);
  const [soilData, setSoilData] = useState<SoilData | null>(null);
  const [ndviAnalysis, setNdviAnalysis] = useState<NDVIAnalysis | null>(null);
  const [loading, setLoading] = useState(false);
  const [fieldsLoading, setFieldsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Debug token existence
  useEffect(() => {
    console.log("Token exists:", !!authUtils.getToken());
  }, []);

  // Fetch fields list on mount
  useEffect(() => {
    const fetchFields = async () => {
      try {
        console.log("Fetching fields from", API_BASE + "/api/fields");
        const res = await authUtils.authenticatedFetch(
          `${API_BASE}/api/fields`,
        );
        console.log("Fields response status:", res.status);
        const data = await res.json();
        console.log("Fields data:", data);
        if (Array.isArray(data)) {
          if (data.length > 0 && data[0]?.error) {
            setError("Backend error: " + data[0].error);
          } else {
            setFields(data);
            if (data.length > 0) {
              setSelectedField((prev) => prev || data[0].id);
            } else {
              setError("No fields found for your farm.");
            }
          }
        } else {
          setError("Unexpected fields response format.");
        }
      } catch (e) {
        console.error("Fields fetch failed:", e);
        setError("Failed to load fields: " + String(e));
      } finally {
        setFieldsLoading(false);
      }
    };
    fetchFields();
  }, []);

  // Fetch field detail and soil when a field is selected
  useEffect(() => {
    if (!selectedField) {
      setFieldDetail(null);
      setSoilData(null);
      setNdviAnalysis(null);
      return;
    }
    const fetchDetail = async () => {
      setLoading(true);
      setError(null);
      try {
        const url = `${API_BASE}/api/field-detail/${selectedField}`;
        console.log("Fetching detail from", url);
        const res = await authUtils.authenticatedFetch(url);
        console.log("Detail response status:", res.status);
        if (!res.ok) {
          const errText = await res.text();
          setError(`Failed to load field details: ${res.status} - ${errText}`);
          setLoading(false);
          return;
        }
        const data: FieldDetailResponse = await res.json();
        console.log("Detail data:", data);
        setFieldDetail(data.field);
        setSoilData(data.soil);
        setNdviAnalysis(data.ndvi ?? null);
      } catch (e) {
        console.error("Detail fetch failed:", e);
        setError("Failed to load field details: " + String(e));
      } finally {
        setLoading(false);
      }
    };
    fetchDetail();
  }, [selectedField]);

  const displayFieldDetail: FieldDetail = fieldDetail ?? {
    field_id: selectedField,
    name: "N/A",
    crop_name: "N/A",
    crop_variety: "N/A",
    hectares: 0,
    sowing_date: "",
    growth_stage: "N/A",
  };

  const displaySoilData: SoilData = soilData ?? {
    nitrogen: null,
    phosphorus: null,
    potassium: null,
    ph_level: null,
    organic_matter: null,
  };

  const selectedHistory = ndviAnalysis?.history?.length
    ? ndviAnalysis.history
    : [];
  const currentNdvi =
    ndviAnalysis?.average ??
    selectedHistory[selectedHistory.length - 1]?.ndvi ??
    0;

  const overlayVisible = fieldsLoading || loading;
  const overlayTitle = fieldsLoading
    ? "Loading field data…"
    : loading
      ? "Analyzing field data…"
      : "Processing…";

  return (
    <div className="ma-container">
      {overlayVisible && (
        <div className="smart-advisory-overlay">
          <div className="smart-advisory-loading-card">
            <p className="smart-advisory-loading-title">{overlayTitle}</p>
            <div className="typing-wrapper smart-advisory-loading-typing">
              <div className="typing-indicator">
                <div className="typing-dot"></div>
                <div className="typing-dot delay-200"></div>
                <div className="typing-dot delay-400"></div>
              </div>
            </div>
          </div>
        </div>
      )}
      <main className="ma-main">
        <div className="ma-content">
          {/* Error banner */}
          {error && (
            <div
              style={{
                background: "#fee",
                color: "red",
                padding: "8px",
                marginBottom: "10px",
              }}
            >
              {error}
            </div>
          )}

          {fieldsLoading ? (
            <div
              className="ma-placeholder"
              style={{ marginTop: "20px", textAlign: "center" }}
            >
              Loading fields...
            </div>
          ) : fields.length === 0 ? (
            <div
              className="ma-placeholder"
              style={{ marginTop: "20px", textAlign: "center" }}
            >
              No fields found for your farm.
            </div>
          ) : (
            <FieldSelector
              fields={fields}
              selectedField={selectedField}
              onSelectField={setSelectedField}
            />
          )}

          {selectedField && loading && (
            <div
              className="ma-loading"
              style={{ marginTop: "20px", textAlign: "center" }}
            >
              Loading field data...
            </div>
          )}

          {selectedField && !loading && (
            <>
              <CropSoilCard
                fieldDetail={displayFieldDetail}
                soilData={displaySoilData}
              />
              <MapSection
                fields={fields}
                selectedField={selectedField}
                onSelectField={setSelectedField}
                currentNdvi={currentNdvi}
                sentinelTileUrl={ndviAnalysis?.sentinel_tile_url ?? null}
                ndviTileUrl={ndviAnalysis?.ndvi_tile_url ?? null}
              />
              <NDVICard analysis={ndviAnalysis} />
              <RecommendationSection
                analysis={ndviAnalysis}
                fieldDetail={displayFieldDetail}
              />
            </>
          )}
        </div>
      </main>
    </div>
  );
}
