import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import * as LucideIcons from "lucide-react";
import "./Sign.css";
import type { SignInData, SignUpData } from "../../types/Sign";
import authUtils from "../../utils/authUtils";
import WelcomeCard from "../../components/Sign/WelcomeCard";
import Highlight from "../../components/Sign/HighlightGroup";
import Alert from "../../components/Sign/Alert";
import logo from "../../assets/logo.png";

const Sign: React.FC = () => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [mobileActiveTab, setMobileActiveTab] = useState<"welcome" | "auth">(
    "welcome",
  );
  const [formData, setFormData] = useState<SignUpData | SignInData>({
    identifier: "",
    password: "",
    name: "",
    phone: "",
    email: "",
    language: "en",
    farm: {
      name: "",
      hecters: 0,
      district: "",
      province: "",
      main_crop: "",
      type: "",
    },
  });
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const navigate = useNavigate();

  const welcome = [
    {
      icon: LucideIcons.Satellite,
      title: "Satellite Crop Monitoring",
      description:
        "Web-based application integrating satellite-based crop monitoring via NDVI technology, providing real-time vegetation health analysis, early stress detection, and yield prediction across your entire farm operation.",
    },
    {
      icon: LucideIcons.Microscope,
      title: "CNN Disease Detection",
      description:
        "CNN-based deep learning model specifically trained to detect and diagnose diseases in maize, tomato, and potato crops from uploaded images, delivering accurate identification and treatment recommendations.",
    },
    {
      icon: LucideIcons.MessageCircle,
      title: "AI Chatbot Advisory",
      description:
        "AI-driven conversational chatbot providing automated agricultural advisory services, answering farmer queries about crop management, pest control, fertilization, and sustainable farming practices 24/7.",
    },
    {
      icon: LucideIcons.Waves,
      title: "Smart Irrigation Advisory",
      description:
        "Irrigation advisory module using real-time evapotranspiration (ET₀) rates combined with localized rainfall data to optimize watering schedules, reduce water waste, and maximize crop yield potential.",
    },
  ];

  const highlights = [
    {
      text: "Satellite NDVI Monitoring",
      icon: LucideIcons.Satellite,
      variant: "default" as const,
    },
    {
      text: "CNN Disease Detection",
      icon: LucideIcons.Microscope,
      variant: "default" as const,
    },
    {
      text: "AI Chatbot Advisory",
      icon: LucideIcons.MessageCircle,
      variant: "default" as const,
    },
    {
      text: "Smart Irrigation",
      icon: LucideIcons.Waves,
      variant: "default" as const,
    },
  ];

  const handleInputChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement
    >,
  ) => {
    const { name, value } = e.target;

    if (isSignUp) {
      if (name.startsWith("farm.")) {
        const farmField = name.split(".")[1];
        setFormData((prev) => ({
          ...(prev as SignUpData),
          farm: {
            ...(prev as SignUpData).farm,
            [farmField]: value,
          },
        }));
      } else {
        setFormData((prev) => ({
          ...(prev as SignUpData),
          [name]: value,
        }));
      }
    } else {
      setFormData((prev) => ({
        ...(prev as SignInData),
        [name]: value,
      }));
    }

    // Clear error when user starts typing
    if (error) {
      setError(null);
    }
  };

  const validateSignIn = (data: SignInData): string | null => {
    if (!data.identifier || data.identifier.trim() === "") {
      return "Email or User ID is required";
    }
    if (!data.password || data.password.trim() === "") {
      return "Password is required";
    }
    return null;
  };

  const validateSignUp = (data: SignUpData): string | null => {
    const missingFields: string[] = [];

    // Personal Information validation
    if (!data.name || data.name.trim() === "") missingFields.push("Full Name");
    if (!data.email || data.email.trim() === "") missingFields.push("Email");
    if (!data.phone || data.phone.trim() === "") missingFields.push("Phone");
    if (!data.password || data.password.trim() === "")
      missingFields.push("Password");

    // Farm Information validation
    if (!data.farm.name || data.farm.name.trim() === "") {
      missingFields.push("Farm Name");
    }

    if (missingFields.length > 0) {
      const fieldList = missingFields.join(", ");
      return `Missing required fields: ${fieldList}. Please fill in all marked with *`;
    }

    // Email format validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      return "Please enter a valid email address";
    }

    // Password strength validation
    if (data.password.length < 6) {
      return "Password must be at least 6 characters long";
    }

    // Phone validation (basic - at least 10 digits)
    const phoneDigits = data.phone.replace(/\D/g, "");
    if (phoneDigits.length < 10) {
      return "Phone number must contain at least 10 digits";
    }

    return null;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    setSuccess(null);

    try {
      const API_BASE_URL =
        import.meta.env.VITE_API_BASE_URL || "http://localhost:8000";

      if (isSignUp) {
        const signUpData = formData as SignUpData;

        // Validate form data
        const validationError = validateSignUp(signUpData);
        if (validationError) {
          throw new Error(validationError);
        }

        const response = await fetch(`${API_BASE_URL}/api/auth/signup`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(signUpData),
        });

        const data = await response.json();

        if (!response.ok) {
          throw new Error(data.detail || "Sign up failed");
        }

        // Store user_id
        localStorage.setItem("user_id", data.user_id);

        setSuccess(
          data.message || "Account created successfully! Please sign in.",
        );
        setTimeout(() => {
          setIsSignUp(false);
          setFormData({
            identifier: "",
            password: "",
            name: "",
            phone: "",
            email: "",
            language: "en",
            farm: {
              name: "",
              hecters: 0,
              district: "",
              province: "",
              main_crop: "",
              type: "",
            },
          });
        }, 2000);
      } else {
        const signInData = formData as SignInData;
        const trimmedSignInData = {
          identifier: signInData.identifier.trim(),
          password: signInData.password,
        };

        // Validate sign in data
        const validationError = validateSignIn(trimmedSignInData);
        if (validationError) {
          throw new Error(validationError);
        }

        const response = await fetch(`${API_BASE_URL}/api/auth/signin`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(trimmedSignInData),
        });

        const data = await response.json();

        if (!response.ok) {
          throw new Error(data.detail || "Sign in failed");
        }

        // Store token and user data
        authUtils.setAuthData(
          data.token,
          data.user_id,
          data.email,
          data.name || "",
          data.farm_id || "",
          data.farm_name || "",
        );

        setSuccess("Signed in successfully!");

        // Redirect to Murimi dashboard after success
        setTimeout(() => {
          navigate("/dashboard");
        }, 1500);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred");
    } finally {
      setIsLoading(false);
    }
  };

  const closeAlert = () => {
    setError(null);
    setSuccess(null);
  };

  return (
    <div className="sign-container">
      {/* Mobile Tab Navigation */}
      <div className="sign-mobile-tabs">
        <button
          className={`sign-mobile-tab ${mobileActiveTab === "welcome" ? "active" : ""}`}
          onClick={() => setMobileActiveTab("welcome")}
        >
          <LucideIcons.Sprout size={18} />
          <span>Welcome</span>
        </button>
        <button
          className={`sign-mobile-tab ${mobileActiveTab === "auth" ? "active" : ""}`}
          onClick={() => setMobileActiveTab("auth")}
        >
          <LucideIcons.User size={18} />
          <span>{isSignUp ? "Sign Up" : "Sign In"}</span>
        </button>
      </div>

      {/* Left Side - Welcoming Page (Green Theme) */}
      <div
        className={`sign-welcome-side ${mobileActiveTab === "welcome" ? "sign-mobile-active" : "sign-mobile-hidden"}`}
      >
        <div className="sign-welcome-content">
          <div className="sign-features-grid">
            {welcome.map((feature, index) => (
              <WelcomeCard
                key={index}
                icon={feature.icon}
                title={feature.title}
                description={feature.description}
                delay={index * 100}
              />
            ))}
          </div>

          <div className="sign-what-is-murimi">
            <div className="sign-info-header">
              <LucideIcons.Info className="sign-info-icon" />
              <h2>What is MurimiAI?</h2>
            </div>
            <p className="sign-info-text">
              MurimiAI is an innovative AI-powered agricultural assistant
              designed to help farmers make data-driven decisions. By
              integrating satellite-based crop monitoring, advanced disease
              detection algorithms, and intelligent advisory systems, MurimiAI
              provides comprehensive farm management solutions that maximize
              productivity while minimizing resource usage.
            </p>
            <Highlight highlights={highlights} size="md" layout="wrap" />
          </div>
        </div>
      </div>

      {/* Right Side - Authentication Forms (Dark Theme) */}
      <div
        className={`sign-auth-side ${mobileActiveTab === "auth" ? "sign-mobile-active" : "sign-mobile-hidden"}`}
      >
        {/* Fixed Header */}
        <div className="sign-auth-header">
          <div className="sign-auth-logo">
            <img
              src={logo}
              alt="MurimiAI Logo"
              className="sign-auth-logo-icon"
            />
          </div>
          <div className="sign-hd">
            <h1>MurimiAI</h1>
            <p className="sign-auth-subtitle">
              {isSignUp
                ? "Create your farming account"
                : "Welcome back to your farm"}
            </p>
          </div>
        </div>

        {/* Scrollable Form Container */}
        <div className="sign-auth-form-container">
          {error && (
            <Alert
              type="error"
              message={error}
              onClose={closeAlert}
              autoClose={true}
              autoCloseDelay={5000}
            />
          )}
          {success && (
            <Alert
              type="success"
              message={success}
              onClose={closeAlert}
              autoClose={true}
              autoCloseDelay={5000}
            />
          )}

          <form onSubmit={handleSubmit} className="sign-auth-form">
            {!isSignUp ? (
              // Sign In Form
              <>
                <div className="sign-form-group">
                  <label htmlFor="identifier">Email or User ID</label>
                  <div className="sign-input-wrapper">
                    <LucideIcons.User className="sign-input-icon" />
                    <input
                      type="text"
                      id="identifier"
                      name="identifier"
                      value={(formData as SignInData).identifier}
                      onChange={handleInputChange}
                      placeholder="Enter your email or user ID"
                      disabled={isLoading}
                    />
                  </div>
                </div>

                <div className="sign-form-group">
                  <label htmlFor="password">Password</label>
                  <div className="sign-input-wrapper">
                    <LucideIcons.Lock className="sign-input-icon" />
                    <input
                      type={showPassword ? "text" : "password"}
                      id="password"
                      name="password"
                      value={(formData as SignInData).password}
                      onChange={handleInputChange}
                      placeholder="Enter your password"
                      disabled={isLoading}
                    />
                    <button
                      type="button"
                      className="sign-password-toggle"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? (
                        <LucideIcons.EyeOff size={18} />
                      ) : (
                        <LucideIcons.Eye size={18} />
                      )}
                    </button>
                  </div>
                </div>
              </>
            ) : (
              // Sign Up Form
              <>
                <div className="sign-form-section">
                  <h3>Personal Information</h3>

                  <div className="sign-form-group">
                    <label htmlFor="name">Full Name *</label>
                    <div className="sign-input-wrapper">
                      <LucideIcons.User className="sign-input-icon" />
                      <input
                        type="text"
                        id="name"
                        name="name"
                        value={(formData as SignUpData).name}
                        onChange={handleInputChange}
                        placeholder="Enter your full name"
                        disabled={isLoading}
                      />
                    </div>
                  </div>

                  <div className="sign-form-row">
                    <div className="sign-form-group">
                      <label htmlFor="email">Email *</label>
                      <div className="sign-input-wrapper">
                        <LucideIcons.Mail className="sign-input-icon" />
                        <input
                          type="email"
                          id="email"
                          name="email"
                          value={(formData as SignUpData).email}
                          onChange={handleInputChange}
                          placeholder="Enter your email"
                          disabled={isLoading}
                        />
                      </div>
                    </div>

                    <div className="sign-form-group">
                      <label htmlFor="phone">Phone *</label>
                      <div className="sign-input-wrapper">
                        <LucideIcons.Phone className="sign-input-icon" />
                        <input
                          type="tel"
                          id="phone"
                          name="phone"
                          value={(formData as SignUpData).phone}
                          onChange={handleInputChange}
                          placeholder="Enter your phone number"
                          disabled={isLoading}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="sign-form-row">
                    <div className="sign-form-group">
                      <label htmlFor="password">Password *</label>
                      <div className="sign-input-wrapper">
                        <LucideIcons.Lock className="sign-input-icon" />
                        <input
                          type={showPassword ? "text" : "password"}
                          id="password"
                          name="password"
                          value={(formData as SignUpData).password}
                          onChange={handleInputChange}
                          placeholder="Create a password"
                          disabled={isLoading}
                        />
                        <button
                          type="button"
                          className="sign-password-toggle"
                          onClick={() => setShowPassword(!showPassword)}
                        >
                          {showPassword ? (
                            <LucideIcons.EyeOff size={18} />
                          ) : (
                            <LucideIcons.Eye size={18} />
                          )}
                        </button>
                      </div>
                    </div>

                    <div className="sign-form-group">
                      <label htmlFor="language">Preferred Language</label>
                      <div className="sign-input-wrapper">
                        <LucideIcons.Globe className="sign-input-icon" />
                        <select
                          id="language"
                          name="language"
                          value={(formData as SignUpData).language}
                          onChange={handleInputChange}
                          disabled={isLoading}
                        >
                          <option value="en">English</option>
                          <option value="nd">Ndebele</option>
                          <option value="sn">Shona</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="sign-form-section">
                  <h3>Farm Information</h3>

                  <div className="sign-form-group">
                    <label htmlFor="farm.name">Farm Name *</label>
                    <div className="sign-input-wrapper">
                      <LucideIcons.Tractor className="sign-input-icon" />
                      <input
                        type="text"
                        id="farm.name"
                        name="farm.name"
                        value={(formData as SignUpData).farm.name}
                        onChange={handleInputChange}
                        placeholder="Enter your farm name"
                        disabled={isLoading}
                      />
                    </div>
                  </div>

                  <div className="sign-form-row">
                    <div className="sign-form-group">
                      <label htmlFor="farm.hecters">Farm Size (hectares)</label>
                      <input
                        type="number"
                        id="farm.hecters"
                        name="farm.hecters"
                        value={(formData as SignUpData).farm.hecters}
                        onChange={handleInputChange}
                        placeholder="Size in hectares"
                        disabled={isLoading}
                        className="sign-no-icon-input"
                      />
                    </div>

                    <div className="sign-form-group">
                      <label htmlFor="farm.district">District</label>
                      <div className="sign-input-wrapper">
                        <LucideIcons.MapPin className="sign-input-icon" />
                        <input
                          type="text"
                          id="farm.district"
                          name="farm.district"
                          value={(formData as SignUpData).farm.district}
                          onChange={handleInputChange}
                          placeholder="Enter district"
                          disabled={isLoading}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="sign-form-row">
                    <div className="sign-form-group">
                      <label htmlFor="farm.province">Province</label>
                      <div className="sign-input-wrapper">
                        <LucideIcons.MapPin className="sign-input-icon" />
                        <input
                          type="text"
                          id="farm.province"
                          name="farm.province"
                          value={(formData as SignUpData).farm.province}
                          onChange={handleInputChange}
                          placeholder="Enter province"
                          disabled={isLoading}
                        />
                      </div>
                    </div>

                    <div className="sign-form-group">
                      <label htmlFor="farm.main_crop">Main Crops</label>
                      <div className="sign-input-wrapper">
                        <LucideIcons.Sprout className="sign-input-icon" />
                        <input
                          type="text"
                          id="farm.main_crop"
                          name="farm.main_crop"
                          value={(formData as SignUpData).farm.main_crop}
                          onChange={handleInputChange}
                          placeholder="e.g., Maize, Wheat, Coffee"
                          disabled={isLoading}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="sign-form-row">
                    <div className="sign-form-group">
                      <label htmlFor="farm.type">Farming Type</label>
                      <div className="sign-input-wrapper">
                        <LucideIcons.Tractor className="sign-input-icon" />
                        <select
                          id="farm.type"
                          name="farm.type"
                          value={(formData as SignUpData).farm.type}
                          onChange={handleInputChange}
                          disabled={isLoading}
                        >
                          <option value="">Select farming type</option>
                          <option value="subsistence">Subsistence</option>
                          <option value="commercial">Commercial</option>
                          <option value="organic">Organic</option>
                          <option value="mixed">Mixed</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
              </>
            )}

            <button
              type="submit"
              className="sign-submit-btn"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <LucideIcons.Loader2 className="sign-spinner" />
                  Processing...
                </>
              ) : (
                <>
                  {isSignUp ? "Create Account" : "Sign In"}
                  {isSignUp ? (
                    <LucideIcons.UserPlus size={20} />
                  ) : (
                    <LucideIcons.LogIn size={20} />
                  )}
                </>
              )}
            </button>
          </form>

          <div className="sign-toggle-auth">
            <p>
              {isSignUp ? "Already have an account?" : "Don't have an account?"}
              <button
                type="button"
                onClick={() => {
                  setIsSignUp(!isSignUp);
                  setError(null);
                  setSuccess(null);
                }}
                className="sign-toggle-btn"
              >
                {isSignUp ? "Sign In" : "Sign Up"}
              </button>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sign;
