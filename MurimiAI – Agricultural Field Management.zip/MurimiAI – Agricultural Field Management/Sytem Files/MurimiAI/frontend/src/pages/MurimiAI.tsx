import React, { useState, useEffect, useRef } from "react";
import * as LucideIcons from "lucide-react";
import { useNavigate } from "react-router-dom";
import "./murimi.tailwind.css";
import logo from "../assets/logo.png";
import AddField from "../pages/AddField/AddField.tsx";
import SmartAdvisory from "../pages/SmartAdvisory/SmartAdvisory.tsx";
import MurimiAIAnalytics from "../pages/MurimiAI_Analytics/MurimiAnalytics.tsx";
import SoilAnalysis from "../pages/SoilAnalysis/SoilAnalysis.tsx";
import Farm from "../pages/Farm/Farm.tsx";
import Account from "../pages/Account/Account.tsx";

import authUtils from "../utils/authUtils";

// Type for menu items
interface MenuItem {
  id: string;
  icon: React.ReactNode;
  label: string;
}

interface UserData {
  name: string;
  email: string;
  initials: string;
  farmId: string;
  farmName: string;
  userId: string;
}

const MurimiAI: React.FC = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<string>("add-field");
  const [sidebarOpen, setSidebarOpen] = useState<boolean>(false);
  const [isMobile, setIsMobile] = useState<boolean>(false);
  const [profileMenuOpen, setProfileMenuOpen] = useState<boolean>(false);
  const profileMenuRef = useRef<HTMLDivElement>(null);
  const [showAccount, setShowAccount] = useState<boolean>(false);
  const [userData, setUserData] = useState<UserData>({
    name: "Name not set",
    email: "Email not set",
    initials: "None",
    farmId: "Farm ID not set",
    farmName: "Farm Name not set",
    userId: "User ID not set",
  });

  useEffect(() => {
    const initializeUserData = async (): Promise<void> => {
      const name = authUtils.getName() || "Name not set";
      const email = authUtils.getEmail() || "Email not set";
      const storedFarmId = authUtils.getFarmId();
      const storedFarmName = authUtils.getFarmName();
      const storedUserId = authUtils.getUserId();
      const farmId =
        storedFarmId && storedFarmId.trim() ? storedFarmId : "Farm ID not set";
      const farmName =
        storedFarmName && storedFarmName.trim()
          ? storedFarmName
          : "Farm Name not set";
      const userId =
        storedUserId && storedUserId.trim() ? storedUserId : "User ID not set";
      const initials = name.trim() ? name.trim().charAt(0).toUpperCase() : "T";
      setUserData({ name, email, initials, farmId, farmName, userId });

      const token = authUtils.getToken();
      if (!token) {
        return;
      }

      try {
        const API_BASE_URL =
          import.meta.env.VITE_API_BASE_URL || "http://localhost:8000";
        const currentUser = await authUtils.getCurrentUser(API_BASE_URL);
        if (currentUser) {
          const signedInUserId =
            currentUser.user_id || authUtils.getUserId() || "";
          const signedInName = currentUser.name || name;
          const signedInEmail = currentUser.email || email;
          const currentUserFarmId =
            currentUser.farm_id && currentUser.farm_id.trim()
              ? currentUser.farm_id
              : "";
          const currentUserFarmName =
            currentUser.farm_name && currentUser.farm_name.trim()
              ? currentUser.farm_name
              : "";
          const finalFarmId = currentUserFarmId || storedFarmId || "";
          const finalFarmName = currentUserFarmName || storedFarmName || "";

          authUtils.setAuthData(
            token,
            signedInUserId,
            signedInEmail,
            signedInName,
            finalFarmId,
            finalFarmName,
          );

          const initialsFromUser = signedInName.trim()
            ? signedInName.trim().charAt(0).toUpperCase()
            : "T";
          setUserData({
            name: signedInName,
            email: signedInEmail,
            initials: initialsFromUser,
            farmId:
              finalFarmId && finalFarmId.trim()
                ? finalFarmId
                : "Farm ID not set",
            farmName:
              finalFarmName && finalFarmName.trim()
                ? finalFarmName
                : "Farm Name not set",
            userId:
              signedInUserId && signedInUserId.trim()
                ? signedInUserId
                : "User ID not set",
          });
        }
      } catch (error) {
        console.error("Failed to load signed-in user:", error);
      }
    };

    initializeUserData();
  }, []);

  // Check screen size for responsive behavior
  useEffect(() => {
    const checkScreenSize = (): void => {
      const mobile = window.innerWidth < 1024;
      setIsMobile(mobile);
      if (!mobile) {
        setSidebarOpen(true);
      } else {
        setSidebarOpen(false);
      }
    };

    checkScreenSize();
    window.addEventListener("resize", checkScreenSize);

    return () => window.removeEventListener("resize", checkScreenSize);
  }, []);

  // Handle click outside to close profile menu
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        profileMenuRef.current &&
        !profileMenuRef.current.contains(event.target as Node)
      ) {
        setProfileMenuOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const menuItems: MenuItem[] = [
      {
      id: "add-field",
      icon: <LucideIcons.PlusCircle size={20} strokeWidth={2.5} />,
      label: "Add Field",
    },
    {
      id: "analytics",
      icon: <LucideIcons.BarChart3 size={20} strokeWidth={2.5} />,
      label: "Crop Monitoring",
    },
  
    {
      id: "soil",
      icon: <LucideIcons.ChartScatterIcon size={20} strokeWidth={2.5} />,
      label: "Soil Analysis",
    },
    {
      id: "advisory",
      icon: <LucideIcons.Lightbulb size={20} strokeWidth={2.5} />,
      label: "Smart Advisor",
    },
    {
      id: "farm",
      icon: <LucideIcons.FileArchive size={20} strokeWidth={2.5} />,
      label: "My Farm",
    },
  ];

  const renderContent = (): React.ReactNode => {
    if (showAccount) {
      return (
        <div className="w-full h-full">
          <Account />
        </div>
      );
    }
    switch (activeTab) {
      case "add-field":
        return (
          <div className="w-full h-full">
            <AddField />
          </div>
        );
        
      case "analytics":
        return (
          <div className="w-full h-full">
            <MurimiAIAnalytics />
          </div>
        );

      case "soil":
        return (
          <div className="w-full h-full">
            <SoilAnalysis />
          </div>
        );

      case "advisory":
        return (
          <div className="w-full h-full">
            <SmartAdvisory />
          </div>
        );

      case "farm":
        return (
          <div className="w-full h-full">
            <Farm />
          </div>
        );

      default:
        return (
          <div className="w-full h-full">
            <AddField />
          </div>
        );
    }
  };

  const handleMenuClick = (id: string): void => {
    setShowAccount(false);
    setActiveTab(id);
    if (isMobile) {
      setSidebarOpen(false);
    }
  };

  const handleProfileMenuToggle = () => {
    setProfileMenuOpen(!profileMenuOpen);
  };

  const handleLogout = () => {
    // Clear all auth data using the clearAuth method
    authUtils.clearAuth();

    // Navigate to sign page
    navigate("/sign");
    setProfileMenuOpen(false);
  };

  const handleAccount = () => {
    setShowAccount(true);
    setActiveTab("");
    setProfileMenuOpen(false);
  };

  // Get the current page title
  const getPageTitle = (): string => {
    if (showAccount) {
      return "My Account";
    }
    return (
      menuItems.find((item) => item.id === activeTab)?.label || "Dashboard"
    );
  };

  return (
    <div className="zoom-80">
      <div className="app-container">
        {/* Mobile menu button */}
        {isMobile && !sidebarOpen && (
          <button
            onClick={() => setSidebarOpen(true)}
            className="mobile-menu-btn"
            aria-label="Open menu"
            type="button"
          >
            <LucideIcons.Menu size={22} strokeWidth={2.5} />
          </button>
        )}

        {/* Mobile close button */}
        {isMobile && sidebarOpen && (
          <button
            onClick={() => setSidebarOpen(false)}
            className="mobile-menu-btn"
            aria-label="Close menu"
            type="button"
          >
            <LucideIcons.X size={22} strokeWidth={2.5} />
          </button>
        )}

        {/* Mobile overlay */}
        {isMobile && sidebarOpen && (
          <div
            className="mobile-overlay"
            onClick={() => setSidebarOpen(false)}
            aria-hidden="true"
          />
        )}

        {/* Sidebar */}
        <aside
          className={`sidebar ${sidebarOpen ? "open" : ""}`}
          aria-label="Sidebar navigation"
        >
          <div className="sidebar-container">
            {/* Logo/Header */}
            <div className="sidebar-header">
              <div className="header-content">
                <div className="logo-container">
                  <img src={logo} alt="MurimiAI Logo" className="logo" />
                </div>
                <div className="title-section">
                  <div className="title-row">
                    <h1 className="app-title">
                      Murimi<span>AI</span>
                    </h1>
                    <span className="status-dot">
                      <span className="ping-dot"></span>
                      <span className="static-dot"></span>
                    </span>
                  </div>
                  <p className="subtitle">
                    {" "}
                    <span className="subtitle-text">
                      Smart Farming Assistant
                    </span>
                  </p>
                </div>
              </div>
            </div>

            {/* Navigation Menu - Flex and Centered */}
            <nav className="nav-menu-centered">
              <ul className="nav-list-centered">
                {menuItems.map((item) => (
                  <li key={item.id} className="nav-item-centered">
                    <button
                      onClick={() => handleMenuClick(item.id)}
                      className={`nav-button-centered ${activeTab === item.id ? "active" : ""}`}
                      type="button"
                      aria-current={activeTab === item.id ? "page" : undefined}
                    >
                      <span className="nav-icon-centered">{item.icon}</span>
                      <span className="nav-label-centered">{item.label}</span>
                    </button>
                  </li>
                ))}
              </ul>
            </nav>
          </div>
        </aside>

        {/* Main Content */}
        <main
          className={`main-content ${isMobile && sidebarOpen ? "mobile-sidebar-open" : ""}`}
        >
          {/* Top bar */}
          <header
            className={`top-bar ${isMobile && sidebarOpen ? "mobile-sidebar-open" : ""}`}
          >
            <div className="top-bar-container">
              {/* Spacer for mobile menu button */}
              {isMobile && !sidebarOpen && <div className="mobile-spacer" />}

              <h2 className="page-title">{getPageTitle()}</h2>

              <div className="top-bar-actions">
                {/* Profile Dropdown */}
                <div className="profile-container" ref={profileMenuRef}>
                  <button
                    onClick={handleProfileMenuToggle}
                    className="profile-btn"
                    type="button"
                    aria-label="Profile menu"
                    aria-expanded={profileMenuOpen}
                  >
                    <div className="profile-avatar">
                      <span className="avatar-initials">
                        {userData.initials}
                      </span>
                    </div>
                    <div className="profile-info">
                      <p className="profile-name">{userData.name}</p>
                      <p className="profile-email">{userData.email}</p>
                    </div>
                    <LucideIcons.ChevronDown
                      size={14}
                      className={`chevron-icon ${profileMenuOpen ? "open" : ""}`}
                    />
                  </button>

                  {/* Dropdown Menu */}
                  {profileMenuOpen && (
                    <div
                      className="dropdown-menu"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <div className="dropdown-header">
                        <p className="dropdown-name">{userData.name}</p>
                        <p className="dropdown-email">
                          User ID: {userData.userId}
                        </p>
                        <p className="dropdown-email">
                          Farm Name: {userData.farmName}
                        </p>
                        <p className="dropdown-email">
                          Farm ID: {userData.farmId}
                        </p>
                      </div>

                      <button onClick={handleAccount} className="dropdown-item">
                        <LucideIcons.User size={20} className="text-gray-500" />
                        <span>My Account</span>
                      </button>
                      <div className="dropdown-divider"></div>
                      <button
                        onClick={handleLogout}
                        className="dropdown-item logout"
                      >
                        <LucideIcons.LogOut size={16} />
                        <span>Logout</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </header>

          {/* Page Content */}
          <section
            className={`content-section ${isMobile && sidebarOpen ? "mobile-sidebar-open" : ""}`}
          >
            {renderContent()}
          </section>
        </main>
      </div>
    </div>
  );
};

export default MurimiAI;
