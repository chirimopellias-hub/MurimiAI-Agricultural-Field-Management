import React, {
  useState,
  useEffect,
  useRef,
  useCallback,
  useMemo,
} from "react";
import "./SmartAdvisory.css";
import * as LucideIcons from "lucide-react";
import { authUtils } from "../../utils/authUtils";

interface ChatMessage {
  id: string;
  text: string;
  sender: "user" | "bot";
  timestamp: Date;
}

interface Conversation {
  id: string;
  title: string;
  lastMessage: string;
  timestamp: Date;
  messageCount: number;
  messages: ChatMessage[];
}

// ==================== CHAT UTILITIES ====================

const TITLE_KEYWORDS = [
  "maize",
  "rice",
  "wheat",
  "vegetable",
  "soil",
  "irrigation",
  "fertilizer",
  "pest",
  "disease",
  "weather",
  "harvest",
  "livestock",
  "crop",
  "farm",
  "garden",
];

const getConversationTitle = (messages: ChatMessage[]): string => {
  const userText = messages
    .filter((message) => message.sender === "user")
    .map((message) => message.text)
    .join(" ");

  const lowerText = userText.toLowerCase();
  const matchedKeyword = TITLE_KEYWORDS.find((keyword) =>
    lowerText.includes(keyword),
  );

  if (matchedKeyword) {
    return matchedKeyword.charAt(0).toUpperCase() + matchedKeyword.slice(1);
  }

  const fallbackWords = userText
    .trim()
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 4);
  return fallbackWords.length > 0
    ? fallbackWords.join(" ")
    : "Agriculture Chat";
};

const getChatResponse = async (message: string): Promise<string> => {
  try {
    const response = await fetch(
      "http://localhost:8000/api/smart-advisory/chat",
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message, history: [] }),
      },
    );

    const data = await response.json();

    if (!response.ok) {
      throw new Error(
        data.detail || "Unable to reach the SmartAdvisory backend",
      );
    }

    return data.reply || "I’m here to help with your agriculture questions.";
  } catch (error) {
    console.error("SmartAdvisory backend error:", error);
    return "Sorry, I could not reach the agriculture assistant right now. Please try again in a moment.";
  }
};

// ==================== COMPONENT ====================

const SmartAdvisory: React.FC = () => {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [draftConversation, setDraftConversation] = useState<Conversation>({
    id: "new-chat",
    title: "New Conversation",
    lastMessage: "",
    timestamp: new Date(),
    messageCount: 0,
    messages: [],
  });
  const [activeConversationId, setActiveConversationId] =
    useState<string>("new-chat");
  const [currentMessage, setCurrentMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [isLoadingHistory, setIsLoadingHistory] = useState(true);
  const [isSavingConversation, setIsSavingConversation] = useState(false);
  const [isDeletingConversation, setIsDeletingConversation] = useState(false);
  const [showSaveConfirmation, setShowSaveConfirmation] = useState(false);
  const [windowWidth, setWindowWidth] = useState(window.innerWidth);
  const [isSidebarOpen, setIsSidebarOpen] = useState(() => {
    // Initialize based on screen size
    return window.innerWidth >= 1024;
  });

  const currentConversation =
    activeConversationId === "new-chat"
      ? draftConversation
      : conversations.find((c) => c.id === activeConversationId) ||
        draftConversation;
  const chatMessages = useMemo(
    () => currentConversation?.messages || [],
    [currentConversation],
  );

  const chatEndRef = useRef<HTMLDivElement>(null);
  const chatInputRef = useRef<HTMLInputElement>(null);

  const isMobile = windowWidth < 768;
  const isTablet = windowWidth >= 768 && windowWidth < 1024;
  const isDesktop = windowWidth >= 1024;

  // Handle window resize - update sidebar state based on screen size changes
  useEffect(() => {
    const handleResize = () => {
      const newWidth = window.innerWidth;
      setWindowWidth(newWidth);

      // Auto-close sidebar on mobile when resizing from desktop to mobile
      if (newWidth < 1024 && isSidebarOpen) {
        setIsSidebarOpen(false);
      }
      // Auto-open sidebar on desktop when resizing from mobile to desktop
      if (newWidth >= 1024 && !isSidebarOpen) {
        setIsSidebarOpen(true);
      }
    };

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, [isSidebarOpen]);

  // Scroll to bottom of chat
  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [chatMessages]);

  useEffect(() => {
    const loadSavedConversations = async () => {
      if (!authUtils.getToken()) return;

      try {
        setIsLoadingHistory(true);
        const response = await authUtils.authenticatedFetch(
          "http://localhost:8000/api/smart-advisory/conversations",
        );
        if (!response.ok) return;

        const data = await response.json();
        if (!Array.isArray(data) || data.length === 0) return;

        type SavedConversation = {
          id: string;
          title?: string;
          lastMessage?: string;
          timestamp?: string;
          messageCount?: number;
          messages?: ChatMessage[];
        };

        setConversations(
          data.map((item: SavedConversation) => ({
            id: item.id,
            title: item.title || "Conversation",
            lastMessage: item.lastMessage || "",
            timestamp: new Date(item.timestamp || Date.now()),
            messageCount: item.messageCount || 0,
            messages: (item.messages || []).map((msg) => ({
              ...msg,
              timestamp: new Date(msg.timestamp || Date.now()),
            })),
          })),
        );
      } catch (error) {
        console.error("Failed to load saved conversations", error);
      } finally {
        setIsLoadingHistory(false);
      }
    };

    loadSavedConversations();
  }, []);

  const saveCurrentConversation = useCallback(async () => {
    const conversation = currentConversation;
    if (!conversation || conversation.messages.length === 0) return null;

    if (!authUtils.getToken()) {
      return null;
    }

    setIsSavingConversation(true);

    try {
      const title = getConversationTitle(conversation.messages);
      const response = await authUtils.authenticatedFetch(
        "http://localhost:8000/api/smart-advisory/conversations/save",
        {
          method: "POST",
          body: JSON.stringify({
            conversation_id: conversation.id,
            title,
            messages: conversation.messages.map((msg) => ({
              text: msg.text,
              sender: msg.sender,
              timestamp: msg.timestamp.toISOString(),
            })),
          }),
        },
      );

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.detail || "Failed to save conversation");
      }

      if (data.id) {
        if (conversation.id === "new-chat") {
          const savedConversation: Conversation = {
            id: data.id,
            title: getConversationTitle(conversation.messages),
            lastMessage:
              conversation.messages[conversation.messages.length - 1]?.text ||
              "",
            timestamp: new Date(),
            messageCount: conversation.messages.length,
            messages: conversation.messages,
          };
          setConversations((prev) => [savedConversation, ...prev]);
          setActiveConversationId(data.id);
          setDraftConversation({
            ...draftConversation,
            id: data.id,
            title: savedConversation.title,
          });
        } else {
          setConversations((prev) =>
            prev.map((item) =>
              item.id === conversation.id
                ? {
                    ...item,
                    title: getConversationTitle(conversation.messages),
                    messageCount: conversation.messages.length,
                    lastMessage:
                      conversation.messages[conversation.messages.length - 1]
                        ?.text || "",
                  }
                : item,
            ),
          );
        }
      }

      return data;
    } finally {
      setIsSavingConversation(false);
    }
  }, [currentConversation, draftConversation]);

  const handleSendMessage = useCallback(async () => {
    const text = currentMessage.trim();
    if (!text) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      text,
      sender: "user",
      timestamp: new Date(),
    };

    if (activeConversationId === "new-chat") {
      setDraftConversation((prev) => ({
        ...prev,
        title: getConversationTitle([...prev.messages, userMessage]),
        messages: [...prev.messages, userMessage],
        messageCount: prev.messageCount + 1,
        lastMessage: text,
        timestamp: new Date(),
      }));
    } else {
      setConversations((prev) =>
        prev.map((conv) =>
          conv.id === activeConversationId
            ? {
                ...conv,
                title: getConversationTitle([...conv.messages, userMessage]),
                messages: [...conv.messages, userMessage],
                messageCount: conv.messageCount + 1,
                lastMessage: text,
                timestamp: new Date(),
              }
            : conv,
        ),
      );
    }

    setCurrentMessage("");
    setIsTyping(true);

    setTimeout(async () => {
      const botText = await getChatResponse(text);
      const botResponse: ChatMessage = {
        id: (Date.now() + 1).toString(),
        text: botText,
        sender: "bot",
        timestamp: new Date(),
      };

      if (activeConversationId === "new-chat") {
        setDraftConversation((prev) => ({
          ...prev,
          messages: [...prev.messages, botResponse],
          messageCount: prev.messageCount + 1,
          lastMessage:
            botResponse.text.slice(0, 50) +
            (botResponse.text.length > 50 ? "..." : ""),
          timestamp: new Date(),
        }));
      } else {
        setConversations((prev) => {
          const updated = prev.map((conv) =>
            conv.id === activeConversationId
              ? {
                  ...conv,
                  messages: [...conv.messages, botResponse],
                  messageCount: conv.messageCount + 1,
                  lastMessage:
                    botResponse.text.slice(0, 50) +
                    (botResponse.text.length > 50 ? "..." : ""),
                  timestamp: new Date(),
                }
              : conv,
          );
          return updated;
        });
      }

      setIsTyping(false);
    }, 1000);
  }, [currentMessage, activeConversationId]);

  const handleKeyPress = useCallback(
    (e: React.KeyboardEvent) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        handleSendMessage();
      }
    },
    [handleSendMessage],
  );

  const resetDraftConversation = useCallback(() => {
    setDraftConversation({
      id: "new-chat",
      title: "New Conversation",
      lastMessage: "",
      timestamp: new Date(),
      messageCount: 0,
      messages: [],
    });
    setActiveConversationId("new-chat");

    if (isMobile) {
      setIsSidebarOpen(false);
    }
  }, [isMobile]);

  const handleNewConversation = useCallback(async () => {
    if (draftConversation.messages.length > 0) {
      setShowSaveConfirmation(true);
      return;
    }

    resetDraftConversation();
  }, [draftConversation.messages, resetDraftConversation]);

  const confirmSaveAndStartNew = useCallback(async () => {
    setShowSaveConfirmation(false);

    try {
      await saveCurrentConversation();
    } catch (error) {
      console.error(
        "Unable to save current conversation before starting a new one",
        error,
      );
    }

    resetDraftConversation();
  }, [resetDraftConversation, saveCurrentConversation]);

  const handleSelectConversation = useCallback(
    async (conversationId: string) => {
      try {
        const response = await authUtils.authenticatedFetch(
          `http://localhost:8000/api/smart-advisory/conversations/${conversationId}`,
        );
        if (!response.ok) return;

        const data = await response.json();
        setConversations((prev) =>
          prev.map((item) =>
            item.id === conversationId
              ? {
                  ...item,
                  title: data.title || item.title,
                  lastMessage: data.lastMessage || item.lastMessage,
                  timestamp: new Date(data.timestamp || item.timestamp),
                  messageCount: data.messageCount || item.messageCount,
                  messages: (data.messages || item.messages || []).map(
                    (msg: ChatMessage) => ({
                      ...msg,
                      timestamp: new Date(msg.timestamp || Date.now()),
                    }),
                  ),
                }
              : item,
          ),
        );
      } catch (error) {
        console.error("Failed to load conversation details", error);
      }

      setActiveConversationId(conversationId);
      // Close sidebar on mobile when selecting a conversation
      if (isMobile) {
        setIsSidebarOpen(false);
      }
    },
    [isMobile],
  );

  const handleSaveConversation = useCallback(async () => {
    try {
      await saveCurrentConversation();
    } catch (error) {
      console.error("Failed to save conversation", error);
    }
  }, [saveCurrentConversation]);

  const handleDeleteConversation = useCallback(
    async (conversationId: string, e: React.MouseEvent) => {
      e.stopPropagation();

      setIsDeletingConversation(true);

      try {
        const response = await authUtils.authenticatedFetch(
          `http://localhost:8000/api/smart-advisory/conversations/${conversationId}`,
          {
            method: "DELETE",
          },
        );

        if (!response.ok) {
          const data = await response.json().catch(() => ({}));
          throw new Error(data.detail || "Failed to delete conversation");
        }

        setConversations((prev) =>
          prev.filter((conv) => conv.id !== conversationId),
        );

        if (activeConversationId === conversationId) {
          setActiveConversationId("new-chat");
          setDraftConversation({
            id: "new-chat",
            title: "New Conversation",
            lastMessage: "",
            timestamp: new Date(),
            messageCount: 0,
            messages: [],
          });
        }
      } catch (error) {
        console.error("Failed to delete conversation", error);
      } finally {
        setIsDeletingConversation(false);
      }
    },
    [activeConversationId],
  );

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  const closeSidebar = () => {
    setIsSidebarOpen(false);
  };

  return (
    <div className="smart-advisory-unique-container">
      {(isLoadingHistory || isSavingConversation || isDeletingConversation) && (
        <div className="smart-advisory-overlay">
          <div className="smart-advisory-loading-card">
            <p className="smart-advisory-loading-title">
              {isSavingConversation
                ? "Saving conversation…"
                : isDeletingConversation
                  ? "Deleting conversation…"
                  : "Loading saved conversations…"}
            </p>
            <div className="typing-wrapper smart-advisory-loading-typing">
              <div className="typing-indicator">
                <div className="typing-dot"></div>
                <div className="typing-dot delay-200"></div>
                <div className="typing-dot delay-400"></div>
              </div>
            </div>
          </div>
        </div>
      )}

      {showSaveConfirmation && (
        <div
          className="smart-advisory-overlay"
          role="dialog"
          aria-modal="true"
          aria-label="Save conversation confirmation"
        >
          <div className="smart-advisory-confirm-card">
            <div className="smart-advisory-confirm-icon">
              <LucideIcons.AlertCircle className="w-6 h-6" />
            </div>
            <h3 className="smart-advisory-confirm-title">
              Save this conversation first?
            </h3>
            <p className="smart-advisory-confirm-text">
              Would you like to save your current chat before starting a new
              one?
            </p>
            <div className="smart-advisory-confirm-actions">
              <button
                className="smart-advisory-confirm-btn smart-advisory-confirm-btn-yes"
                onClick={confirmSaveAndStartNew}
              >
                Yes, save it
              </button>
              <button
                className="smart-advisory-confirm-btn smart-advisory-confirm-btn-no"
                onClick={() => {
                  setShowSaveConfirmation(false);
                  resetDraftConversation();
                }}
              >
                No, start fresh
              </button>
            </div>
          </div>
        </div>
      )}
      <div className="advisory-layout">
        {/* Left Sidebar - Conversation History */}
        <div
          className={`conversation-sidebar ${isSidebarOpen ? "open" : "closed"} ${isDesktop ? "desktop" : ""}`}
        >
          <div className="sidebar-header">
            <div className="sidebar-title">
              <LucideIcons.MessageSquare className="w-5 h-5" />
              <h3>Conversations</h3>
            </div>
            <div className="sidebar-header-actions">
              <button
                onClick={handleNewConversation}
                className="new-chat-button"
                title="New conversation"
              >
                <LucideIcons.Plus className="w-4 h-4" />
                <span>New</span>
              </button>
              {/* Close button for mobile/tablet */}
              {(isMobile || isTablet) && isSidebarOpen && (
                <button
                  onClick={closeSidebar}
                  className="close-sidebar-button"
                  title="Close sidebar"
                >
                  <LucideIcons.X className="w-5 h-5" />
                </button>
              )}
            </div>
          </div>

          {/* Conversation List */}
          <div className="conversation-list">
            <h4 className="section-title">
              <LucideIcons.History className="w-4 h-4" />
              Chat History
            </h4>
            <div className="conversations-container">
              {conversations.map((conv) => (
                <div
                  key={conv.id}
                  onClick={() => handleSelectConversation(conv.id)}
                  className={`conversation-item ${activeConversationId === conv.id ? "active" : ""}`}
                >
                  <div className="conversation-icon">
                    <LucideIcons.MessageCircle className="w-4 h-4" />
                  </div>
                  <div className="conversation-details">
                    <div className="conversation-title">{conv.title}</div>
                    <div className="conversation-preview">
                      {conv.lastMessage}
                    </div>
                    <div className="conversation-time">
                      {conv.timestamp.toLocaleDateString()} •{" "}
                      {conv.messageCount} messages
                    </div>
                  </div>
                  {conversations.length > 1 && (
                    <button
                      onClick={(e) => handleDeleteConversation(conv.id, e)}
                      className="delete-conversation"
                      title="Delete conversation"
                    >
                      <LucideIcons.Trash2 className="w-7 h-7" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Overlay for mobile when sidebar is open */}
        {(isMobile || isTablet) && isSidebarOpen && (
          <div className="sidebar-overlay" onClick={closeSidebar} />
        )}

        {/* Main Chat Area */}
        <div className="chat-main-area">
          {/* Chat Header */}
          <div className="chat-header">
            {/* Menu button - show on mobile/tablet, and on desktop when sidebar is closed */}
            {(isMobile || isTablet || (isDesktop && !isSidebarOpen)) && (
              <button
                onClick={toggleSidebar}
                className="sidebar-toggle"
                title={isSidebarOpen ? "Hide sidebar" : "Show sidebar"}
              >
                <LucideIcons.Menu className="w-5 h-5" />
              </button>
            )}

            <div className="chat-header-info">
              <div className="assistant-avatar">
                <LucideIcons.Bot className="w-6 h-6 text-emerald-600" />
              </div>
              <div>
                <h3 className="assistant-name">MurimiAI Assistant</h3>
                <p className="assistant-context">General Agriculture Expert</p>
              </div>
            </div>

            <div className="chat-header-actions">
              <button
                onClick={handleSaveConversation}
                className="header-action-button"
                title="Save conversation"
              >
                <LucideIcons.Save className="w-5 h-5" />
              </button>
              <button
                onClick={handleNewConversation}
                className="header-action-button"
                title="New conversation"
              >
                <LucideIcons.Plus className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Chat Messages */}
          <div className="chat-area">
            {chatMessages.map((msg) => (
              <div
                key={msg.id}
                className={`chat-message-wrapper ${msg.sender}`}
              >
                <div className={`chat-message-bubble ${msg.sender}`}>
                  <p className="chat-message-text">{msg.text}</p>

                  <time className={`chat-message-time ${msg.sender}`}>
                    {msg.timestamp.toLocaleTimeString([], {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </time>
                </div>
              </div>
            ))}

            {isTyping && (
              <div className="typing-wrapper">
                <div className="typing-indicator">
                  <div className="typing-dot"></div>
                  <div className="typing-dot delay-200"></div>
                  <div className="typing-dot delay-400"></div>
                </div>
              </div>
            )}

            <div ref={chatEndRef} />
          </div>

          {/* Chat Input */}
          <div className="chat-input-area">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage();
              }}
            >
              <div className="chat-input-wrapper">
                <input
                  ref={chatInputRef}
                  type="text"
                  value={currentMessage}
                  onChange={(e) => setCurrentMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Ask me anything about agriculture... "
                  className="chat-input-field"
                  aria-label="Chat message"
                />
                <button
                  type="submit"
                  disabled={!currentMessage.trim()}
                  className="send-message-button"
                >
                  <LucideIcons.Send className="w-4 h-4" />
                  <span className="send-message-label">Send</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SmartAdvisory;
