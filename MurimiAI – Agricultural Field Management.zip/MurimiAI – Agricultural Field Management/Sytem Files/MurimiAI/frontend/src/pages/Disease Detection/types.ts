export interface DiseaseResult {
  disease: string;
  confidence: number;
  predictedCrop?: CropType;
  cropConfidence?: number;
  treatment?: string;
  description?: string;
  affectedCrops?: string[];
  prevention?: string[];
  symptoms?: string[];
}

export interface DetectionState {
  isLoading: boolean;
  result: DiseaseResult | null;
  error: string | null;
}

export type CropType = "tomato" | "potato" | "corn" | null;

export const CROP_OPTIONS: Array<{ label: string; value: CropType }> = [
  { label: "Select a Crop", value: null },
  { label: "Tomato", value: "tomato" },
  { label: "Potato", value: "potato" },
  { label: "Corn", value: "corn" },
];