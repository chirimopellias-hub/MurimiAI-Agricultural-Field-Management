import React, { useState, useCallback, useEffect } from "react";
import { useDropzone } from "react-dropzone";
import * as LucideIcons from "lucide-react";
import { CROP_OPTIONS } from "./types";
import type { DiseaseResult, DetectionState, CropType } from "./types";
import "./CropDiseaseDetection.css";

const CropDiseaseDetection: React.FC = () => {
  const [selectedCrop, setSelectedCrop] = useState<CropType>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [detectionState, setDetectionState] = useState<DetectionState>({
    isLoading: false,
    result: null,
    error: null,
  });
  const [isTipsOpen, setIsTipsOpen] = useState<boolean>(false);
  const [windowWidth, setWindowWidth] = useState<number>(window.innerWidth);

  useEffect(() => {
    const handleResize = () => setWindowWidth(window.innerWidth);
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      setSelectedImage(reader.result as string);
      setDetectionState({ isLoading: false, result: null, error: null });
    };
    reader.readAsDataURL(file);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      "image/*": [".jpeg", ".jpg", ".png", ".webp"],
    },
    maxFiles: 1,
    maxSize: 5242880,
  });

  const detectDisease = async () => {
    if (!selectedCrop || !selectedImage) return;

    setDetectionState((prev) => ({ ...prev, isLoading: true, error: null }));

    try {
      const base64Image = selectedImage.split(",")[1] || "";
      const binaryData = atob(base64Image);
      const bytes = new Uint8Array(binaryData.length);
      for (let i = 0; i < binaryData.length; i += 1) {
        bytes[i] = binaryData.charCodeAt(i);
      }
      const blob = new Blob([bytes], { type: "image/jpeg" });
      const formData = new FormData();
      formData.append("file", blob, "image.jpg");

      const backendUrl =
        import.meta.env.VITE_BACKEND_URL || "http://127.0.0.1:8000";

      const classifierResponse = await fetch(`${backendUrl}/predict/crop`, {
        method: "POST",
        body: formData,
      });

      if (!classifierResponse.ok) {
        const data = await classifierResponse.json();
        throw new Error(
          data.detail || data.message || "Crop classification failed",
        );
      }

      const classifierResult = await classifierResponse.json();
      const predictedCrop = classifierResult.predicted_crop as CropType;
      const cropConfidence = classifierResult.confidence || 0;

      if (predictedCrop !== selectedCrop) {
        throw new Error(
          `Image mismatch: detected '${predictedCrop}' instead of '${selectedCrop}'. Please select the correct crop or upload an image of ${selectedCrop}.`,
        );
      }

      const diseaseFormData = new FormData();
      diseaseFormData.append("file", blob, "image.jpg");
      const diseaseResponse = await fetch(
        `${backendUrl}/predict/${selectedCrop}`,
        {
          method: "POST",
          body: diseaseFormData,
        },
      );

      if (!diseaseResponse.ok) {
        const errorData = await diseaseResponse.json();
        throw new Error(
          String(errorData.detail || errorData.message || "Prediction failed"),
        );
      }

      const predictions = await diseaseResponse.json();
      const result: DiseaseResult = {
        disease: predictions.class || "Unknown Disease",
        confidence: predictions.confidence || 0,
        predictedCrop,
        cropConfidence,
        treatment: "Consult agricultural expert for treatment recommendations.",
        description: `Disease detected: ${predictions.class}`,
        affectedCrops: [
          selectedCrop.charAt(0).toUpperCase() + selectedCrop.slice(1),
        ],
        prevention: [
          "Use resistant varieties",
          "Practice crop rotation",
          "Maintain proper spacing",
          "Regular monitoring",
        ],
        symptoms: ["Visible lesions", "Color changes", "Wilting signs"],
      };

      setDetectionState({ isLoading: false, result, error: null });
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : "Failed to detect disease. Please try again.";
      setDetectionState({ isLoading: false, result: null, error: message });
    }
  };

  const resetDetection = () => {
    setSelectedImage(null);
    setDetectionState({ isLoading: false, result: null, error: null });
  };

  const getResponsivePadding = () => {
    if (windowWidth < 640) return "p-4";
    if (windowWidth < 768) return "p-6";
    return "p-8";
  };

  const getUploadZoneClass = () => {
    if (!selectedCrop) return "upload-zone disabled";
    if (isDragActive) return "upload-zone drag-active";
    return "upload-zone active";
  };

  return (
    <div className={`crop-disease-unique-container ${getResponsivePadding()}`}>
      <div className="main-layout-grid">
        {/* Tips Sidebar */}
        <aside className="tips-section">
          <div className="tips-card">
            <div className="tips-header">
              <h3 className="tips-title">Tips for Best Results</h3>
              <button
                type="button"
                className="tips-toggle-button"
                onClick={() => setIsTipsOpen((state) => !state)}
                aria-expanded={isTipsOpen}
              >
                {isTipsOpen ? (
                  <LucideIcons.ChevronUp className="icon-small" />
                ) : (
                  <LucideIcons.ChevronDown className="icon-small" />
                )}
              </button>
            </div>
            <div
              className={`tips-content ${windowWidth >= 1024 || isTipsOpen ? "tips-visible" : "tips-hidden"}`}
            >
              <ul className="tips-list">
                <li className="tips-item">
                  <LucideIcons.Camera className="tips-icon" />
                  <span>Good lighting to capture symptoms clearly.</span>
                </li>
                <li className="tips-item">
                  <LucideIcons.Target className="tips-icon" />
                  <span>Focus on affected areas for better detection.</span>
                </li>
                <li className="tips-item">
                  <LucideIcons.ImageIcon className="tips-icon" />
                  <span>Use a high-resolution image without blur.</span>
                </li>
                <li className="tips-item">
                  <LucideIcons.CheckCircle2 className="tips-icon" />
                  <span>Select the crop type before uploading.</span>
                </li>
                <li className="tips-item">
                  <LucideIcons.Upload className="tips-icon" />
                  <span>Upload the image once the crop is selected.</span>
                </li>
              </ul>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <section className="main-content">
          <div className="card-container">
            {/* Card Header */}
            <div className="card-header">
              <div className="card-header-content">
                <h2 className="card-title">Choose your crop & upload image</h2>
                <div className="crop-select-wrapper">
                  <select
                    id="crop-select"
                    value={selectedCrop ?? ""}
                    onChange={(event) =>
                      setSelectedCrop(event.target.value as CropType)
                    }
                    className={`crop-select ${selectedCrop ? "has-value" : "no-value"}`}
                  >
                    <option value="" disabled className="text-gray-500">
                      Select a Crop
                    </option>
                    {CROP_OPTIONS.filter((option) => option.value !== null).map(
                      (option) => (
                        <option key={option.value} value={option.value || ""}>
                          {option.label}
                        </option>
                      ),
                    )}
                  </select>
                  <LucideIcons.ChevronDown className="select-icon" />
                </div>
              </div>
              {selectedCrop && (
                <p className="selected-crop-label">
                  {selectedCrop.charAt(0).toUpperCase() + selectedCrop.slice(1)}{" "}
                  Crop Selected
                </p>
              )}
            </div>

            {/* Card Body */}
            <div className="card-body">
              <div className="scroll-container">
                {!selectedImage ? (
                  <div
                    {...(selectedCrop ? getRootProps() : {})}
                    className={getUploadZoneClass()}
                  >
                    {selectedCrop && <input {...getInputProps()} />}
                    <div className="upload-content">
                      {!selectedCrop && (
                        <div className="upload-prompt">
                          Please select a crop type first
                        </div>
                      )}
                      {selectedCrop && (
                        <>
                          <div className="upload-icon">
                            {isDragActive ? (
                              <LucideIcons.Camera
                                className={
                                  windowWidth < 640
                                    ? "icon-large"
                                    : "icon-xlarge"
                                }
                              />
                            ) : (
                              <LucideIcons.Upload
                                className={
                                  windowWidth < 640
                                    ? "icon-large"
                                    : "icon-xlarge"
                                }
                              />
                            )}
                          </div>
                          <div
                            className={`upload-text ${windowWidth < 640 ? "text-base" : "text-xl"}`}
                          >
                            {isDragActive
                              ? "Drop your crop image here"
                              : windowWidth < 640
                                ? "Tap to upload"
                                : "Drag & drop or click to upload"}
                          </div>
                          <p className="upload-formats">
                            <LucideIcons.ImageIcon className="icon-small" />
                            Supports JPG, PNG, WEBP (Max 5MB)
                          </p>
                        </>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="preview-section">
                    {/* Image Preview */}
                    <div className="preview-container">
                      <img
                        src={selectedImage}
                        alt="Crop preview"
                        className={`preview-image ${
                          windowWidth < 640
                            ? "preview-small"
                            : windowWidth < 768
                              ? "preview-medium"
                              : "preview-large"
                        }`}
                      />
                      <button
                        onClick={resetDetection}
                        className="remove-button"
                        title="Change image"
                      >
                        <LucideIcons.X className="icon-small" />
                      </button>
                    </div>

                    {/* Detect Button */}
                    {!detectionState.result && !detectionState.isLoading && (
                      <button onClick={detectDisease} className="detect-button">
                        <LucideIcons.Search className="icon-small" />
                        Detect Disease
                      </button>
                    )}

                    {/* Loading State */}
                    {detectionState.isLoading && (
                      <div className="loading-state">
                        <LucideIcons.Loader2 className="loading-spinner" />
                        <p className="loading-text">
                          Analyzing your crop image...
                        </p>
                      </div>
                    )}

                    {/* Error State */}
                    {detectionState.error && (
                      <div className="error-state">
                        <div className="error-header">
                          <LucideIcons.AlertCircle className="icon-small text-red-500" />
                          <p className="error-title">Error</p>
                        </div>
                        <p className="error-message">{detectionState.error}</p>
                      </div>
                    )}

                    {/* Results */}
                    {detectionState.result && (
                      <div className="results-section">
                        <div className="results-header">
                          <h2 className="results-title">
                            <LucideIcons.CheckCircle2 className="icon-medium text-emerald-600" />
                            Detection Results
                          </h2>
                        </div>

                        <div className="results-card">
                          {/* Disease Name & Confidence */}
                          <div className="disease-info">
                            <div className="disease-name">
                              <LucideIcons.AlertTriangle className="icon-small text-amber-600" />
                              <h3>{detectionState.result.disease}</h3>
                            </div>
                            <span className="confidence-badge">
                              <LucideIcons.Target className="icon-xs" />
                              {(detectionState.result.confidence * 100).toFixed(
                                1,
                              )}
                              % Confidence
                            </span>
                          </div>

                          {/* Details */}
                          <div className="details-section">
                            {/* Symptoms */}
                            {detectionState.result.symptoms && (
                              <div>
                                <h4 className="section-title">
                                  <LucideIcons.AlertCircle className="icon-small" />
                                  Common Symptoms
                                </h4>
                                <ul className="section-list">
                                  {detectionState.result.symptoms.map(
                                    (symptom, index) => (
                                      <li key={index} className="list-item">
                                        <span className="bullet">•</span>
                                        <span>{symptom}</span>
                                      </li>
                                    ),
                                  )}
                                </ul>
                              </div>
                            )}

                            {/* Description */}
                            <div>
                              <h4 className="section-title">
                                <LucideIcons.Info className="icon-small" />
                                Description
                              </h4>
                              <p className="section-content">
                                {detectionState.result.description}
                              </p>
                            </div>

                            {/* Prevention */}
                            {detectionState.result.prevention && (
                              <div>
                                <h4 className="section-title">
                                  <LucideIcons.Shield className="icon-small" />
                                  Prevention Methods
                                </h4>
                                <ul className="section-list">
                                  {detectionState.result.prevention.map(
                                    (item, index) => (
                                      <li key={index} className="list-item">
                                        <LucideIcons.CheckCheck className="icon-small text-emerald-500 flex-shrink-0" />
                                        <span>{item}</span>
                                      </li>
                                    ),
                                  )}
                                </ul>
                              </div>
                            )}

                            {/* Treatment */}
                            <div>
                              <h4 className="section-title">
                                <LucideIcons.Beaker className="icon-small" />
                                Treatment Recommendations
                              </h4>
                              <p className="section-content">
                                {detectionState.result.treatment}
                              </p>
                            </div>
                          </div>
                        </div>

                        {/* Action Buttons */}
                        <div className="action-buttons">
                          <button
                            type="button"
                            onClick={resetDetection}
                            className="upload-new-button"
                          >
                            <LucideIcons.Upload className="icon-small" />
                            Upload New Image
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Mobile Tip */}
          {windowWidth < 640 && !selectedImage && (
            <div className="mobile-tip-text">
              <LucideIcons.Camera className="icon-xs" />
              <p>Tap anywhere to select an image from your gallery</p>
            </div>
          )}
        </section>
      </div>
    </div>
  );
};

export default CropDiseaseDetection;
