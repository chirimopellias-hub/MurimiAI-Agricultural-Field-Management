import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Sign from './pages/Sign/Sign.tsx';
import MurimiAI from './pages/MurimiAI.tsx';

const AppRoutes: React.FC = () => {
  return (
    <Routes>
      <Route path="/" element={<Sign />} />
      <Route path="/sign" element={<Sign />} />
      <Route path="/dashboard" element={<MurimiAI />} />
      <Route path="/murimi" element={<MurimiAI />} />
      <Route path="*" element={<Sign />} />
    </Routes>
  );
};

export default AppRoutes;
