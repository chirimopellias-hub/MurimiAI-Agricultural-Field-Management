import React, { useEffect } from 'react';
import * as LucideIcons from 'lucide-react';
import './Alert.css';

export type AlertType = 'success' | 'error' | 'info' | 'warning';

interface AlertProps {
  type: AlertType;
  message: string;
  onClose?: () => void;
  autoClose?: boolean;
  autoCloseDelay?: number;
  showIcon?: boolean;
  className?: string;
}

const Alert: React.FC<AlertProps> = ({
  type,
  message,
  onClose,
  autoClose = false,
  autoCloseDelay = 5000,
  showIcon = true,
  className = ''
}) => {
  useEffect(() => {
    if (autoClose && onClose) {
      const timer = setTimeout(() => {
        onClose();
      }, autoCloseDelay);
      
      return () => clearTimeout(timer);
    }
  }, [autoClose, autoCloseDelay, onClose]);

  const getIcon = () => {
    switch (type) {
      case 'success':
        return <LucideIcons.CheckCircle className="alert-icon" />;
      case 'error':
        return <LucideIcons.AlertCircle className="alert-icon" />;
      case 'warning':
        return <LucideIcons.AlertTriangle className="alert-icon" />;
      case 'info':
        return <LucideIcons.Info className="alert-icon" />;
      default:
        return <LucideIcons.Info className="alert-icon" />;
    }
  };

  const getTypeClass = () => {
    switch (type) {
      case 'success':
        return 'alert-success';
      case 'error':
        return 'alert-error';
      case 'warning':
        return 'alert-warning';
      case 'info':
        return 'alert-info';
      default:
        return 'alert-info';
    }
  };

  return (
    <div className={`alert ${getTypeClass()} ${className}`} role="alert">
      {showIcon && getIcon()}
      <span className="alert-message">{message}</span>
      {onClose && (
        <button onClick={onClose} className="alert-close" aria-label="Close alert">
          <LucideIcons.X size={16} />
        </button>
      )}
    </div>
  );
};

export default Alert;