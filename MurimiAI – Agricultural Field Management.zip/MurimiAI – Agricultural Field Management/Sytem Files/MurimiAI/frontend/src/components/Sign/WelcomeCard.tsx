// WelcomeCard.tsx
import React, { useState } from 'react';
import './WelcomeCard.css';

interface FeatureCardProps {
  icon: React.ElementType;
  title: string;
  description: string;
  delay?: number;
}

const WelcomeCard: React.FC<FeatureCardProps> = ({ icon: Icon, title, description, delay = 0 }) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div 
      className="welcome-card"
      style={{ animationDelay: `${delay}ms` }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      tabIndex={0}
      role="article"
    >
      <div className={`welcome-card-icon-wrapper ${isHovered ? 'hovered' : ''}`}>
        <div className="welcome-card-icon-bg">
          <div className="welcome-card-icon-glow"></div>
          <div className="welcome-card-icon">
            <Icon />
          </div>
        </div>
      </div>
      <h3>{title}</h3>
      <p>{description}</p>
      <div className="welcome-card-hover-line"></div>
    </div>
  );
};

export default WelcomeCard;