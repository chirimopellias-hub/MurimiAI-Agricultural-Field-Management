import React from 'react';
import * as LucideIcons from 'lucide-react';
import './HighlightItem.css';

interface HighlightItemProps {
  text: string;
  icon?: React.ElementType;
  variant?: 'default' | 'success' | 'warning' | 'info';
  size?: 'sm' | 'md' | 'lg';
}

const HighlightItem: React.FC<HighlightItemProps> = ({ 
  text, 
  icon: Icon = LucideIcons.CheckCircle,
  variant = 'default',
  size = 'md'
}) => {
  const getVariantClass = () => {
    switch (variant) {
      case 'success':
        return 'highlight-success';
      case 'warning':
        return 'highlight-warning';
      case 'info':
        return 'highlight-info';
      default:
        return 'highlight-default';
    }
  };

  const getSizeClass = () => {
    switch (size) {
      case 'sm':
        return 'highlight-sm';
      case 'lg':
        return 'highlight-lg';
      default:
        return 'highlight-md';
    }
  };

  return (
    <div className={`highlight-item ${getVariantClass()} ${getSizeClass()}`}>
      <Icon className="highlight-icon" />
      <span>{text}</span>
    </div>
  );
};

export default HighlightItem;