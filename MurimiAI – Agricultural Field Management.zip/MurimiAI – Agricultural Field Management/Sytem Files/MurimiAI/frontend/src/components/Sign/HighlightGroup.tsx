import React from 'react';
import HighlightItem from './HighlightItem';
import './HighlightGroup.css';

interface Highlight {
  text: string;
  icon?: React.ElementType;
  variant?: 'default' | 'success' | 'warning' | 'info';
}

interface HighlightGroupProps {
  highlights: Highlight[];
  size?: 'sm' | 'md' | 'lg';
  layout?: 'horizontal' | 'vertical' | 'wrap';
  className?: string;
}

const HighlightGroup: React.FC<HighlightGroupProps> = ({ 
  highlights, 
  size = 'md',
  layout = 'wrap',
  className = ''
}) => {
  const getLayoutClass = () => {
    switch (layout) {
      case 'horizontal':
        return 'highlight-group-horizontal';
      case 'vertical':
        return 'highlight-group-vertical';
      default:
        return 'highlight-group-wrap';
    }
  };

  return (
    <div className={`highlight-group ${getLayoutClass()} ${className}`}>
      {highlights.map((highlight, index) => (
        <HighlightItem
          key={index}
          text={highlight.text}
          icon={highlight.icon}
          variant={highlight.variant}
          size={size}
        />
      ))}
    </div>
  );
};

export default HighlightGroup;