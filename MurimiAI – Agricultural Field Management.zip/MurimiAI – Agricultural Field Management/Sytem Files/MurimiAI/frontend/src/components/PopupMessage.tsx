import React, { useEffect } from 'react';
import * as LucideIcons from 'lucide-react';
import './PopupMessage.css';

export type PopupMessageType = 'success' | 'error' | 'warning' | 'info';

interface PopupMessageProps {
  type: PopupMessageType;
  title: string;
  message: string;
  onClose?: () => void;
  autoClose?: boolean;
  autoCloseDelay?: number;
}

const PopupMessage: React.FC<PopupMessageProps> = ({
  type,
  title,
  message,
  onClose,
  autoClose = true,
  autoCloseDelay = 5000,
}) => {
  useEffect(() => {
    if (!autoClose || !onClose) return;
    const timer = window.setTimeout(() => {
      onClose();
    }, autoCloseDelay);
    return () => window.clearTimeout(timer);
  }, [autoClose, autoCloseDelay, onClose]);

  const getIcon = () => {
    switch (type) {
      case 'success':
        return <LucideIcons.CheckCircle size={20} />;
      case 'error':
        return <LucideIcons.AlertCircle size={20} />;
      case 'warning':
        return <LucideIcons.AlertTriangle size={20} />;
      case 'info':
      default:
        return <LucideIcons.Info size={20} />;
    }
  };

  return (
    <div className={`popup-message popup-${type}`} role="alert">
      <div className="popup-message-icon">{getIcon()}</div>
      <div className="popup-message-main">
        <div className="popup-message-title">{title}</div>
        <div className="popup-message-text">{message}</div>
      </div>
      {onClose && (
        <button
          type="button"
          className="popup-message-close"
          onClick={onClose}
          aria-label="Close notification"
        >
          <LucideIcons.X size={16} />
        </button>
      )}
    </div>
  );
};

export default PopupMessage;
