import React from 'react';
import { Navigate } from 'react-router-dom';
import authUtils from '../utils/authUtils';

interface ProtectedRouteProps {
  children: React.ReactNode;
}

/**
 * ProtectedRoute component - redirects to sign page if user not authenticated
 */
const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children }) => {
  const isAuthenticated = authUtils.isAuthenticated();

  if (!isAuthenticated) {
    return <Navigate to="/sign" replace />;
  }

  return <>{children}</>;
};

export default ProtectedRoute;
