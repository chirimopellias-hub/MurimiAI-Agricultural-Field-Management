from pathlib import Path

path = Path('src/pages/WeatherIrrigation/WeatherIrrigation.tsx')
text = path.read_text(encoding='utf-8')
lines = text.splitlines()
start = 234
paren = 0
brace = 0
for i, line in enumerate(lines[start:], start + 1):
    for ch in line:
        if ch == '(':
            paren += 1
        elif ch == ')':
            paren -= 1
        elif ch == '{':
            brace += 1
        elif ch == '}':
            brace -= 1
    if 250 < i < 340:
        print(i, line, 'paren', paren, 'brace', brace)
print('final', paren, brace)
